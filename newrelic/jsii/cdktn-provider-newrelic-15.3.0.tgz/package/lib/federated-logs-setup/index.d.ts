/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FederatedLogsSetupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where the federated logs setup will live. Defaults to the provider's account_id. Changing this after creation is rejected by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#account_id FederatedLogsSetup#account_id}
    */
    readonly accountId?: number;
    /**
    * Whether the setup is active. When false, log routing to this setup is turned off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#active FederatedLogsSetup#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * The description of the federated log setup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#description FederatedLogsSetup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#id FederatedLogsSetup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the federated log setup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#name FederatedLogsSetup#name}
    */
    readonly name: string;
    /**
    * default_partition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#default_partition FederatedLogsSetup#default_partition}
    */
    readonly defaultPartition: FederatedLogsSetupDefaultPartition;
    /**
    * forwarder block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#forwarder FederatedLogsSetup#forwarder}
    */
    readonly forwarder?: FederatedLogsSetupForwarder;
    /**
    * storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#storage FederatedLogsSetup#storage}
    */
    readonly storage: FederatedLogsSetupStorage;
}
export interface FederatedLogsSetupHealthCheckEnd2EndDataFlow {
}
export declare function federatedLogsSetupHealthCheckEnd2EndDataFlowToTerraform(struct?: FederatedLogsSetupHealthCheckEnd2EndDataFlow): any;
export declare function federatedLogsSetupHealthCheckEnd2EndDataFlowToHclTerraform(struct?: FederatedLogsSetupHealthCheckEnd2EndDataFlow): any;
export declare class FederatedLogsSetupHealthCheckEnd2EndDataFlowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FederatedLogsSetupHealthCheckEnd2EndDataFlow | undefined;
    set internalValue(value: FederatedLogsSetupHealthCheckEnd2EndDataFlow | undefined);
    get lastUpdatedAt(): string;
    get message(): string;
    get status(): string;
}
export declare class FederatedLogsSetupHealthCheckEnd2EndDataFlowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FederatedLogsSetupHealthCheckEnd2EndDataFlowOutputReference;
}
export interface FederatedLogsSetupHealthCheckQueryConnection {
}
export declare function federatedLogsSetupHealthCheckQueryConnectionToTerraform(struct?: FederatedLogsSetupHealthCheckQueryConnection): any;
export declare function federatedLogsSetupHealthCheckQueryConnectionToHclTerraform(struct?: FederatedLogsSetupHealthCheckQueryConnection): any;
export declare class FederatedLogsSetupHealthCheckQueryConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FederatedLogsSetupHealthCheckQueryConnection | undefined;
    set internalValue(value: FederatedLogsSetupHealthCheckQueryConnection | undefined);
    get lastUpdatedAt(): string;
    get message(): string;
    get status(): string;
}
export declare class FederatedLogsSetupHealthCheckQueryConnectionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FederatedLogsSetupHealthCheckQueryConnectionOutputReference;
}
export interface FederatedLogsSetupHealthCheck {
}
export declare function federatedLogsSetupHealthCheckToTerraform(struct?: FederatedLogsSetupHealthCheck): any;
export declare function federatedLogsSetupHealthCheckToHclTerraform(struct?: FederatedLogsSetupHealthCheck): any;
export declare class FederatedLogsSetupHealthCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FederatedLogsSetupHealthCheck | undefined;
    set internalValue(value: FederatedLogsSetupHealthCheck | undefined);
    private _end2EndDataFlow;
    get end2EndDataFlow(): FederatedLogsSetupHealthCheckEnd2EndDataFlowList;
    get lastUpdatedAt(): string;
    private _queryConnection;
    get queryConnection(): FederatedLogsSetupHealthCheckQueryConnectionList;
}
export declare class FederatedLogsSetupHealthCheckList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FederatedLogsSetupHealthCheckOutputReference;
}
export interface FederatedLogsSetupLifecycleStatus {
}
export declare function federatedLogsSetupLifecycleStatusToTerraform(struct?: FederatedLogsSetupLifecycleStatus): any;
export declare function federatedLogsSetupLifecycleStatusToHclTerraform(struct?: FederatedLogsSetupLifecycleStatus): any;
export declare class FederatedLogsSetupLifecycleStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FederatedLogsSetupLifecycleStatus | undefined;
    set internalValue(value: FederatedLogsSetupLifecycleStatus | undefined);
    get lastUpdatedAt(): string;
    get message(): string;
    get status(): string;
}
export declare class FederatedLogsSetupLifecycleStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FederatedLogsSetupLifecycleStatusOutputReference;
}
export interface FederatedLogsSetupDefaultPartitionDataRetentionPolicy {
    /**
    * The duration value for retention.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#duration FederatedLogsSetup#duration}
    */
    readonly duration: number;
    /**
    * The time unit for the retention duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#unit FederatedLogsSetup#unit}
    */
    readonly unit: string;
}
export declare function federatedLogsSetupDefaultPartitionDataRetentionPolicyToTerraform(struct?: FederatedLogsSetupDefaultPartitionDataRetentionPolicyOutputReference | FederatedLogsSetupDefaultPartitionDataRetentionPolicy): any;
export declare function federatedLogsSetupDefaultPartitionDataRetentionPolicyToHclTerraform(struct?: FederatedLogsSetupDefaultPartitionDataRetentionPolicyOutputReference | FederatedLogsSetupDefaultPartitionDataRetentionPolicy): any;
export declare class FederatedLogsSetupDefaultPartitionDataRetentionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsSetupDefaultPartitionDataRetentionPolicy | undefined;
    set internalValue(value: FederatedLogsSetupDefaultPartitionDataRetentionPolicy | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    get durationInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
}
export interface FederatedLogsSetupDefaultPartitionStorage {
    /**
    * The URI location of the partition in object storage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#data_location_uri FederatedLogsSetup#data_location_uri}
    */
    readonly dataLocationUri: string;
    /**
    * The table name associated with the default partition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#table FederatedLogsSetup#table}
    */
    readonly table: string;
}
export declare function federatedLogsSetupDefaultPartitionStorageToTerraform(struct?: FederatedLogsSetupDefaultPartitionStorageOutputReference | FederatedLogsSetupDefaultPartitionStorage): any;
export declare function federatedLogsSetupDefaultPartitionStorageToHclTerraform(struct?: FederatedLogsSetupDefaultPartitionStorageOutputReference | FederatedLogsSetupDefaultPartitionStorage): any;
export declare class FederatedLogsSetupDefaultPartitionStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsSetupDefaultPartitionStorage | undefined;
    set internalValue(value: FederatedLogsSetupDefaultPartitionStorage | undefined);
    private _dataLocationUri?;
    get dataLocationUri(): string;
    set dataLocationUri(value: string);
    get dataLocationUriInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    get tableInput(): string | undefined;
}
export interface FederatedLogsSetupDefaultPartition {
    /**
    * data_retention_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#data_retention_policy FederatedLogsSetup#data_retention_policy}
    */
    readonly dataRetentionPolicy?: FederatedLogsSetupDefaultPartitionDataRetentionPolicy;
    /**
    * storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#storage FederatedLogsSetup#storage}
    */
    readonly storage: FederatedLogsSetupDefaultPartitionStorage;
}
export declare function federatedLogsSetupDefaultPartitionToTerraform(struct?: FederatedLogsSetupDefaultPartitionOutputReference | FederatedLogsSetupDefaultPartition): any;
export declare function federatedLogsSetupDefaultPartitionToHclTerraform(struct?: FederatedLogsSetupDefaultPartitionOutputReference | FederatedLogsSetupDefaultPartition): any;
export declare class FederatedLogsSetupDefaultPartitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsSetupDefaultPartition | undefined;
    set internalValue(value: FederatedLogsSetupDefaultPartition | undefined);
    private _dataRetentionPolicy;
    get dataRetentionPolicy(): FederatedLogsSetupDefaultPartitionDataRetentionPolicyOutputReference;
    putDataRetentionPolicy(value: FederatedLogsSetupDefaultPartitionDataRetentionPolicy): void;
    resetDataRetentionPolicy(): void;
    get dataRetentionPolicyInput(): FederatedLogsSetupDefaultPartitionDataRetentionPolicy | undefined;
    private _storage;
    get storage(): FederatedLogsSetupDefaultPartitionStorageOutputReference;
    putStorage(value: FederatedLogsSetupDefaultPartitionStorage): void;
    get storageInput(): FederatedLogsSetupDefaultPartitionStorage | undefined;
}
export interface FederatedLogsSetupForwarderPipelineControlRoutingRule {
    /**
    * OTTL expression for routing logs to this setup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#expression FederatedLogsSetup#expression}
    */
    readonly expression: string;
}
export declare function federatedLogsSetupForwarderPipelineControlRoutingRuleToTerraform(struct?: FederatedLogsSetupForwarderPipelineControlRoutingRuleOutputReference | FederatedLogsSetupForwarderPipelineControlRoutingRule): any;
export declare function federatedLogsSetupForwarderPipelineControlRoutingRuleToHclTerraform(struct?: FederatedLogsSetupForwarderPipelineControlRoutingRuleOutputReference | FederatedLogsSetupForwarderPipelineControlRoutingRule): any;
export declare class FederatedLogsSetupForwarderPipelineControlRoutingRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsSetupForwarderPipelineControlRoutingRule | undefined;
    set internalValue(value: FederatedLogsSetupForwarderPipelineControlRoutingRule | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface FederatedLogsSetupForwarderPipelineControl {
    /**
    * The fleet entity GUID used for deploying the pipeline configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#fleet_id FederatedLogsSetup#fleet_id}
    */
    readonly fleetId: string;
    /**
    * routing_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#routing_rule FederatedLogsSetup#routing_rule}
    */
    readonly routingRule?: FederatedLogsSetupForwarderPipelineControlRoutingRule;
}
export declare function federatedLogsSetupForwarderPipelineControlToTerraform(struct?: FederatedLogsSetupForwarderPipelineControlOutputReference | FederatedLogsSetupForwarderPipelineControl): any;
export declare function federatedLogsSetupForwarderPipelineControlToHclTerraform(struct?: FederatedLogsSetupForwarderPipelineControlOutputReference | FederatedLogsSetupForwarderPipelineControl): any;
export declare class FederatedLogsSetupForwarderPipelineControlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsSetupForwarderPipelineControl | undefined;
    set internalValue(value: FederatedLogsSetupForwarderPipelineControl | undefined);
    private _fleetId?;
    get fleetId(): string;
    set fleetId(value: string);
    get fleetIdInput(): string | undefined;
    private _routingRule;
    get routingRule(): FederatedLogsSetupForwarderPipelineControlRoutingRuleOutputReference;
    putRoutingRule(value: FederatedLogsSetupForwarderPipelineControlRoutingRule): void;
    resetRoutingRule(): void;
    get routingRuleInput(): FederatedLogsSetupForwarderPipelineControlRoutingRule | undefined;
}
export interface FederatedLogsSetupForwarder {
    /**
    * The type of forwarder. Currently only PIPELINE_CONTROL is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#type FederatedLogsSetup#type}
    */
    readonly type: string;
    /**
    * pipeline_control block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#pipeline_control FederatedLogsSetup#pipeline_control}
    */
    readonly pipelineControl?: FederatedLogsSetupForwarderPipelineControl;
}
export declare function federatedLogsSetupForwarderToTerraform(struct?: FederatedLogsSetupForwarderOutputReference | FederatedLogsSetupForwarder): any;
export declare function federatedLogsSetupForwarderToHclTerraform(struct?: FederatedLogsSetupForwarderOutputReference | FederatedLogsSetupForwarder): any;
export declare class FederatedLogsSetupForwarderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsSetupForwarder | undefined;
    set internalValue(value: FederatedLogsSetupForwarder | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _pipelineControl;
    get pipelineControl(): FederatedLogsSetupForwarderPipelineControlOutputReference;
    putPipelineControl(value: FederatedLogsSetupForwarderPipelineControl): void;
    resetPipelineControl(): void;
    get pipelineControlInput(): FederatedLogsSetupForwarderPipelineControl | undefined;
}
export interface FederatedLogsSetupStorageCloudProviderConfiguration {
    /**
    * The cloud provider. Currently only AWS is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#provider FederatedLogsSetup#provider}
    */
    readonly provider: string;
    /**
    * The cloud provider region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#region FederatedLogsSetup#region}
    */
    readonly region: string;
}
export declare function federatedLogsSetupStorageCloudProviderConfigurationToTerraform(struct?: FederatedLogsSetupStorageCloudProviderConfigurationOutputReference | FederatedLogsSetupStorageCloudProviderConfiguration): any;
export declare function federatedLogsSetupStorageCloudProviderConfigurationToHclTerraform(struct?: FederatedLogsSetupStorageCloudProviderConfigurationOutputReference | FederatedLogsSetupStorageCloudProviderConfiguration): any;
export declare class FederatedLogsSetupStorageCloudProviderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsSetupStorageCloudProviderConfiguration | undefined;
    set internalValue(value: FederatedLogsSetupStorageCloudProviderConfiguration | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export interface FederatedLogsSetupStorage {
    /**
    * The connection manager entity GUID used for writing data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#data_ingest_connection_id FederatedLogsSetup#data_ingest_connection_id}
    */
    readonly dataIngestConnectionId: string;
    /**
    * The object storage bucket where log data is stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#data_location_bucket FederatedLogsSetup#data_location_bucket}
    */
    readonly dataLocationBucket: string;
    /**
    * The database name associated with the federated log setup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#database FederatedLogsSetup#database}
    */
    readonly database: string;
    /**
    * The connection manager entity GUID used by query workers for reading data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#query_connection_id FederatedLogsSetup#query_connection_id}
    */
    readonly queryConnectionId: string;
    /**
    * cloud_provider_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#cloud_provider_configuration FederatedLogsSetup#cloud_provider_configuration}
    */
    readonly cloudProviderConfiguration: FederatedLogsSetupStorageCloudProviderConfiguration;
}
export declare function federatedLogsSetupStorageToTerraform(struct?: FederatedLogsSetupStorageOutputReference | FederatedLogsSetupStorage): any;
export declare function federatedLogsSetupStorageToHclTerraform(struct?: FederatedLogsSetupStorageOutputReference | FederatedLogsSetupStorage): any;
export declare class FederatedLogsSetupStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsSetupStorage | undefined;
    set internalValue(value: FederatedLogsSetupStorage | undefined);
    private _dataIngestConnectionId?;
    get dataIngestConnectionId(): string;
    set dataIngestConnectionId(value: string);
    get dataIngestConnectionIdInput(): string | undefined;
    private _dataLocationBucket?;
    get dataLocationBucket(): string;
    set dataLocationBucket(value: string);
    get dataLocationBucketInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _queryConnectionId?;
    get queryConnectionId(): string;
    set queryConnectionId(value: string);
    get queryConnectionIdInput(): string | undefined;
    private _cloudProviderConfiguration;
    get cloudProviderConfiguration(): FederatedLogsSetupStorageCloudProviderConfigurationOutputReference;
    putCloudProviderConfiguration(value: FederatedLogsSetupStorageCloudProviderConfiguration): void;
    get cloudProviderConfigurationInput(): FederatedLogsSetupStorageCloudProviderConfiguration | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup newrelic_federated_logs_setup}
*/
export declare class FederatedLogsSetup extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_federated_logs_setup";
    /**
    * Generates CDKTN code for importing a FederatedLogsSetup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FederatedLogsSetup to import
    * @param importFromId The id of the existing FederatedLogsSetup that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FederatedLogsSetup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/federated_logs_setup newrelic_federated_logs_setup} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FederatedLogsSetupConfig
    */
    constructor(scope: Construct, id: string, config: FederatedLogsSetupConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    get createdAt(): string;
    get defaultPartitionId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _healthCheck;
    get healthCheck(): FederatedLogsSetupHealthCheckList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lifecycleStatus;
    get lifecycleStatus(): FederatedLogsSetupLifecycleStatusList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _defaultPartition;
    get defaultPartition(): FederatedLogsSetupDefaultPartitionOutputReference;
    putDefaultPartition(value: FederatedLogsSetupDefaultPartition): void;
    get defaultPartitionInput(): FederatedLogsSetupDefaultPartition | undefined;
    private _forwarder;
    get forwarder(): FederatedLogsSetupForwarderOutputReference;
    putForwarder(value: FederatedLogsSetupForwarder): void;
    resetForwarder(): void;
    get forwarderInput(): FederatedLogsSetupForwarder | undefined;
    private _storage;
    get storage(): FederatedLogsSetupStorageOutputReference;
    putStorage(value: FederatedLogsSetupStorage): void;
    get storageInput(): FederatedLogsSetupStorage | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
