/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertPolicyChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where you want to link the channel to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/alert_policy_channel#account_id AlertPolicyChannel#account_id}
    */
    readonly accountId?: number;
    /**
    * Array of channel IDs to apply to the specified policy. We recommended sorting channel IDs in ascending order to avoid drift your Terraform state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/alert_policy_channel#channel_ids AlertPolicyChannel#channel_ids}
    */
    readonly channelIds: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/alert_policy_channel#id AlertPolicyChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/alert_policy_channel#policy_id AlertPolicyChannel#policy_id}
    */
    readonly policyId: number;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/alert_policy_channel#timeouts AlertPolicyChannel#timeouts}
    */
    readonly timeouts?: AlertPolicyChannelTimeouts;
}
export interface AlertPolicyChannelTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/alert_policy_channel#create AlertPolicyChannel#create}
    */
    readonly create?: string;
}
export declare function alertPolicyChannelTimeoutsToTerraform(struct?: AlertPolicyChannelTimeouts | cdktn.IResolvable): any;
export declare function alertPolicyChannelTimeoutsToHclTerraform(struct?: AlertPolicyChannelTimeouts | cdktn.IResolvable): any;
export declare class AlertPolicyChannelTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertPolicyChannelTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AlertPolicyChannelTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/alert_policy_channel newrelic_alert_policy_channel}
*/
export declare class AlertPolicyChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_alert_policy_channel";
    /**
    * Generates CDKTN code for importing a AlertPolicyChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertPolicyChannel to import
    * @param importFromId The id of the existing AlertPolicyChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/alert_policy_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertPolicyChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.0/docs/resources/alert_policy_channel newrelic_alert_policy_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertPolicyChannelConfig
    */
    constructor(scope: Construct, id: string, config: AlertPolicyChannelConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _channelIds?;
    get channelIds(): number[];
    set channelIds(value: number[]);
    get channelIdsInput(): number[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyId?;
    get policyId(): number;
    set policyId(value: number);
    get policyIdInput(): number | undefined;
    private _timeouts;
    get timeouts(): AlertPolicyChannelTimeoutsOutputReference;
    putTimeouts(value: AlertPolicyChannelTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AlertPolicyChannelTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
