/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPartitionRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id associated with the data partition rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#account_id DataPartitionRule#account_id}
    */
    readonly accountId?: number;
    /**
    * The description of the data partition rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#description DataPartitionRule#description}
    */
    readonly description?: string;
    /**
    * Whether or not this data partition rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#enabled DataPartitionRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#id DataPartitionRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The NRQL to match events for this data partition rule. Logs matching this criteria will be routed to the specified data partition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#nrql DataPartitionRule#nrql}
    */
    readonly nrql: string;
    /**
    * The retention policy of the data partition data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#retention_policy DataPartitionRule#retention_policy}
    */
    readonly retentionPolicy: string;
    /**
    * The name of the data partition where logs will be allocated once the rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#target_data_partition DataPartitionRule#target_data_partition}
    */
    readonly targetDataPartition: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#timeouts DataPartitionRule#timeouts}
    */
    readonly timeouts?: DataPartitionRuleTimeouts;
}
export interface DataPartitionRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#create DataPartitionRule#create}
    */
    readonly create?: string;
}
export declare function dataPartitionRuleTimeoutsToTerraform(struct?: DataPartitionRuleTimeouts | cdktn.IResolvable): any;
export declare function dataPartitionRuleTimeoutsToHclTerraform(struct?: DataPartitionRuleTimeouts | cdktn.IResolvable): any;
export declare class DataPartitionRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataPartitionRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataPartitionRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule newrelic_data_partition_rule}
*/
export declare class DataPartitionRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_data_partition_rule";
    /**
    * Generates CDKTN code for importing a DataPartitionRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPartitionRule to import
    * @param importFromId The id of the existing DataPartitionRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPartitionRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.2/docs/resources/data_partition_rule newrelic_data_partition_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPartitionRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataPartitionRuleConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    get deleted(): cdktn.IResolvable;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
    private _retentionPolicy?;
    get retentionPolicy(): string;
    set retentionPolicy(value: string);
    get retentionPolicyInput(): string | undefined;
    private _targetDataPartition?;
    get targetDataPartition(): string;
    set targetDataPartition(value: string);
    get targetDataPartitionInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataPartitionRuleTimeoutsOutputReference;
    putTimeouts(value: DataPartitionRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataPartitionRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
