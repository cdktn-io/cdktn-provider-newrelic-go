/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertMutingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id of the MutingRule..
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#account_id AlertMutingRule#account_id}
    */
    readonly accountId?: number;
    /**
    * The action when the muting rule window is ended or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#action_on_muting_rule_window_ended AlertMutingRule#action_on_muting_rule_window_ended}
    */
    readonly actionOnMutingRuleWindowEnded?: string;
    /**
    * The description of the MutingRule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#description AlertMutingRule#description}
    */
    readonly description?: string;
    /**
    * Whether the MutingRule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#enabled AlertMutingRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#id AlertMutingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the MutingRule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#name AlertMutingRule#name}
    */
    readonly name: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#condition AlertMutingRule#condition}
    */
    readonly condition: AlertMutingRuleCondition;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#schedule AlertMutingRule#schedule}
    */
    readonly schedule?: AlertMutingRuleSchedule;
}
export interface AlertMutingRuleConditionConditions {
    /**
    * The attribute on an incident.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#attribute AlertMutingRule#attribute}
    */
    readonly attribute: string;
    /**
    * The operator used to compare the attribute's value with the supplied value(s).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#operator AlertMutingRule#operator}
    */
    readonly operator: string;
    /**
    * The value(s) to compare against the attribute's value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#values AlertMutingRule#values}
    */
    readonly values: string[];
}
export declare function alertMutingRuleConditionConditionsToTerraform(struct?: AlertMutingRuleConditionConditions | cdktn.IResolvable): any;
export declare function alertMutingRuleConditionConditionsToHclTerraform(struct?: AlertMutingRuleConditionConditions | cdktn.IResolvable): any;
export declare class AlertMutingRuleConditionConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertMutingRuleConditionConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertMutingRuleConditionConditions | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    get attributeInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class AlertMutingRuleConditionConditionsList extends cdktn.ComplexList {
    internalValue?: AlertMutingRuleConditionConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertMutingRuleConditionConditionsOutputReference;
}
export interface AlertMutingRuleCondition {
    /**
    * The operator used to combine all the MutingRuleConditions within the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#operator AlertMutingRule#operator}
    */
    readonly operator: string;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#conditions AlertMutingRule#conditions}
    */
    readonly conditions: AlertMutingRuleConditionConditions[] | cdktn.IResolvable;
}
export declare function alertMutingRuleConditionToTerraform(struct?: AlertMutingRuleConditionOutputReference | AlertMutingRuleCondition): any;
export declare function alertMutingRuleConditionToHclTerraform(struct?: AlertMutingRuleConditionOutputReference | AlertMutingRuleCondition): any;
export declare class AlertMutingRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertMutingRuleCondition | undefined;
    set internalValue(value: AlertMutingRuleCondition | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _conditions;
    get conditions(): AlertMutingRuleConditionConditionsList;
    putConditions(value: AlertMutingRuleConditionConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | AlertMutingRuleConditionConditions[] | undefined;
}
export interface AlertMutingRuleSchedule {
    /**
    * The datetime stamp when the MutingRule schedule should stop repeating.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#end_repeat AlertMutingRule#end_repeat}
    */
    readonly endRepeat?: string;
    /**
    * The datetime stamp representing when the MutingRule should end.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#end_time AlertMutingRule#end_time}
    */
    readonly endTime?: string;
    /**
    * The frequency the MutingRule schedule repeats. One of [DAILY, WEEKLY, MONTHLY]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#repeat AlertMutingRule#repeat}
    */
    readonly repeat?: string;
    /**
    * The number of times the MutingRule schedule should repeat.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#repeat_count AlertMutingRule#repeat_count}
    */
    readonly repeatCount?: number;
    /**
    * The datetime stamp representing when the MutingRule should start.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#start_time AlertMutingRule#start_time}
    */
    readonly startTime?: string;
    /**
    * The time zone that applies to the MutingRule schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#time_zone AlertMutingRule#time_zone}
    */
    readonly timeZone: string;
    /**
    * The day(s) of the week that a MutingRule should repeat when the repeat field is set to WEEKLY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#weekly_repeat_days AlertMutingRule#weekly_repeat_days}
    */
    readonly weeklyRepeatDays?: string[];
}
export declare function alertMutingRuleScheduleToTerraform(struct?: AlertMutingRuleScheduleOutputReference | AlertMutingRuleSchedule): any;
export declare function alertMutingRuleScheduleToHclTerraform(struct?: AlertMutingRuleScheduleOutputReference | AlertMutingRuleSchedule): any;
export declare class AlertMutingRuleScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertMutingRuleSchedule | undefined;
    set internalValue(value: AlertMutingRuleSchedule | undefined);
    private _endRepeat?;
    get endRepeat(): string;
    set endRepeat(value: string);
    resetEndRepeat(): void;
    get endRepeatInput(): string | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _repeat?;
    get repeat(): string;
    set repeat(value: string);
    resetRepeat(): void;
    get repeatInput(): string | undefined;
    private _repeatCount?;
    get repeatCount(): number;
    set repeatCount(value: number);
    resetRepeatCount(): void;
    get repeatCountInput(): number | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    private _weeklyRepeatDays?;
    get weeklyRepeatDays(): string[];
    set weeklyRepeatDays(value: string[]);
    resetWeeklyRepeatDays(): void;
    get weeklyRepeatDaysInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule newrelic_alert_muting_rule}
*/
export declare class AlertMutingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_alert_muting_rule";
    /**
    * Generates CDKTN code for importing a AlertMutingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertMutingRule to import
    * @param importFromId The id of the existing AlertMutingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertMutingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/alert_muting_rule newrelic_alert_muting_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertMutingRuleConfig
    */
    constructor(scope: Construct, id: string, config: AlertMutingRuleConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _actionOnMutingRuleWindowEnded?;
    get actionOnMutingRuleWindowEnded(): string;
    set actionOnMutingRuleWindowEnded(value: string);
    resetActionOnMutingRuleWindowEnded(): void;
    get actionOnMutingRuleWindowEndedInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _condition;
    get condition(): AlertMutingRuleConditionOutputReference;
    putCondition(value: AlertMutingRuleCondition): void;
    get conditionInput(): AlertMutingRuleCondition | undefined;
    private _schedule;
    get schedule(): AlertMutingRuleScheduleOutputReference;
    putSchedule(value: AlertMutingRuleSchedule): void;
    resetSchedule(): void;
    get scheduleInput(): AlertMutingRuleSchedule | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
