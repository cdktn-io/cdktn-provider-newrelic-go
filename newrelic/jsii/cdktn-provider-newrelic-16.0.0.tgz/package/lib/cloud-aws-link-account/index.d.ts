/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudAwsLinkAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where you want to link the AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/cloud_aws_link_account#account_id CloudAwsLinkAccount#account_id}
    */
    readonly accountId?: number;
    /**
    * The AWS role ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/cloud_aws_link_account#arn CloudAwsLinkAccount#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/cloud_aws_link_account#id CloudAwsLinkAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * How metrics will be collected. Defaults to `PULL` if empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/cloud_aws_link_account#metric_collection_mode CloudAwsLinkAccount#metric_collection_mode}
    */
    readonly metricCollectionMode?: string;
    /**
    * The name of the linked account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/cloud_aws_link_account#name CloudAwsLinkAccount#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/cloud_aws_link_account newrelic_cloud_aws_link_account}
*/
export declare class CloudAwsLinkAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_cloud_aws_link_account";
    /**
    * Generates CDKTN code for importing a CloudAwsLinkAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudAwsLinkAccount to import
    * @param importFromId The id of the existing CloudAwsLinkAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/cloud_aws_link_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudAwsLinkAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.1/docs/resources/cloud_aws_link_account newrelic_cloud_aws_link_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudAwsLinkAccountConfig
    */
    constructor(scope: Construct, id: string, config: CloudAwsLinkAccountConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricCollectionMode?;
    get metricCollectionMode(): string;
    set metricCollectionMode(value: string);
    resetMetricCollectionMode(): void;
    get metricCollectionModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
