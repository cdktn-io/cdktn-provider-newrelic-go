/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkloadConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where you want to create the workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#account_id Workload#account_id}
    */
    readonly accountId?: number;
    /**
    * Relevant information about the workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#description Workload#description}
    */
    readonly description?: string;
    /**
    * A list of entity GUIDs manually assigned to this workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#entity_guids Workload#entity_guids}
    */
    readonly entityGuids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#id Workload#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The workload's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#name Workload#name}
    */
    readonly name: string;
    /**
    * A list of account IDs that will be used to get entities from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#scope_account_ids Workload#scope_account_ids}
    */
    readonly scopeAccountIds?: number[];
    /**
    * entity_search_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#entity_search_query Workload#entity_search_query}
    */
    readonly entitySearchQuery?: WorkloadEntitySearchQuery[] | cdktn.IResolvable;
    /**
    * status_config_automatic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#status_config_automatic Workload#status_config_automatic}
    */
    readonly statusConfigAutomatic?: WorkloadStatusConfigAutomatic;
    /**
    * status_config_static block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#status_config_static Workload#status_config_static}
    */
    readonly statusConfigStatic?: WorkloadStatusConfigStatic;
}
export interface WorkloadEntitySearchQuery {
    /**
    * A valid entity search query; empty, and null values are considered invalid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#query Workload#query}
    */
    readonly query: string;
}
export declare function workloadEntitySearchQueryToTerraform(struct?: WorkloadEntitySearchQuery | cdktn.IResolvable): any;
export declare function workloadEntitySearchQueryToHclTerraform(struct?: WorkloadEntitySearchQuery | cdktn.IResolvable): any;
export declare class WorkloadEntitySearchQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkloadEntitySearchQuery | cdktn.IResolvable | undefined;
    set internalValue(value: WorkloadEntitySearchQuery | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class WorkloadEntitySearchQueryList extends cdktn.ComplexList {
    internalValue?: WorkloadEntitySearchQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkloadEntitySearchQueryOutputReference;
}
export interface WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup {
    /**
    * The grouping to be applied to the remaining entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#group_by Workload#group_by}
    */
    readonly groupBy: string;
    /**
    * The rollup strategy that is applied to a group of entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#strategy Workload#strategy}
    */
    readonly strategy: string;
    /**
    * Type of threshold defined for the rule. This is an optional field that only applies when strategy is WORST_STATUS_WINS. Use a threshold to roll up the worst status only after a certain amount of entities are not operational.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#threshold_type Workload#threshold_type}
    */
    readonly thresholdType?: string;
    /**
    * Threshold value defined for the rule. This optional field is used in combination with thresholdType. If the threshold type is null, the threshold value will be ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#threshold_value Workload#threshold_value}
    */
    readonly thresholdValue?: number;
}
export declare function workloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupToTerraform(struct?: WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupOutputReference | WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup): any;
export declare function workloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupToHclTerraform(struct?: WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupOutputReference | WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup): any;
export declare class WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup | undefined;
    set internalValue(value: WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup | undefined);
    private _groupBy?;
    get groupBy(): string;
    set groupBy(value: string);
    get groupByInput(): string | undefined;
    private _strategy?;
    get strategy(): string;
    set strategy(value: string);
    get strategyInput(): string | undefined;
    private _thresholdType?;
    get thresholdType(): string;
    set thresholdType(value: string);
    resetThresholdType(): void;
    get thresholdTypeInput(): string | undefined;
    private _thresholdValue?;
    get thresholdValue(): number;
    set thresholdValue(value: number);
    resetThresholdValue(): void;
    get thresholdValueInput(): number | undefined;
}
export interface WorkloadStatusConfigAutomaticRemainingEntitiesRule {
    /**
    * remaining_entities_rule_rollup block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#remaining_entities_rule_rollup Workload#remaining_entities_rule_rollup}
    */
    readonly remainingEntitiesRuleRollup: WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup;
}
export declare function workloadStatusConfigAutomaticRemainingEntitiesRuleToTerraform(struct?: WorkloadStatusConfigAutomaticRemainingEntitiesRuleOutputReference | WorkloadStatusConfigAutomaticRemainingEntitiesRule): any;
export declare function workloadStatusConfigAutomaticRemainingEntitiesRuleToHclTerraform(struct?: WorkloadStatusConfigAutomaticRemainingEntitiesRuleOutputReference | WorkloadStatusConfigAutomaticRemainingEntitiesRule): any;
export declare class WorkloadStatusConfigAutomaticRemainingEntitiesRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkloadStatusConfigAutomaticRemainingEntitiesRule | undefined;
    set internalValue(value: WorkloadStatusConfigAutomaticRemainingEntitiesRule | undefined);
    private _remainingEntitiesRuleRollup;
    get remainingEntitiesRuleRollup(): WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollupOutputReference;
    putRemainingEntitiesRuleRollup(value: WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup): void;
    get remainingEntitiesRuleRollupInput(): WorkloadStatusConfigAutomaticRemainingEntitiesRuleRemainingEntitiesRuleRollup | undefined;
}
export interface WorkloadStatusConfigAutomaticRuleNrqlQuery {
    /**
    * The entity search query that is used to perform the search of a group of entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#query Workload#query}
    */
    readonly query: string;
}
export declare function workloadStatusConfigAutomaticRuleNrqlQueryToTerraform(struct?: WorkloadStatusConfigAutomaticRuleNrqlQuery | cdktn.IResolvable): any;
export declare function workloadStatusConfigAutomaticRuleNrqlQueryToHclTerraform(struct?: WorkloadStatusConfigAutomaticRuleNrqlQuery | cdktn.IResolvable): any;
export declare class WorkloadStatusConfigAutomaticRuleNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkloadStatusConfigAutomaticRuleNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: WorkloadStatusConfigAutomaticRuleNrqlQuery | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class WorkloadStatusConfigAutomaticRuleNrqlQueryList extends cdktn.ComplexList {
    internalValue?: WorkloadStatusConfigAutomaticRuleNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkloadStatusConfigAutomaticRuleNrqlQueryOutputReference;
}
export interface WorkloadStatusConfigAutomaticRuleRollup {
    /**
    * The rollup strategy that is applied to a group of entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#strategy Workload#strategy}
    */
    readonly strategy: string;
    /**
    * Type of threshold defined for the rule. This is an optional field that only applies when strategy is WORST_STATUS_WINS. Use a threshold to roll up the worst status only after a certain amount of entities are not operational.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#threshold_type Workload#threshold_type}
    */
    readonly thresholdType?: string;
    /**
    * Threshold value defined for the rule. This optional field is used in combination with thresholdType. If the threshold type is null, the threshold value will be ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#threshold_value Workload#threshold_value}
    */
    readonly thresholdValue?: number;
}
export declare function workloadStatusConfigAutomaticRuleRollupToTerraform(struct?: WorkloadStatusConfigAutomaticRuleRollupOutputReference | WorkloadStatusConfigAutomaticRuleRollup): any;
export declare function workloadStatusConfigAutomaticRuleRollupToHclTerraform(struct?: WorkloadStatusConfigAutomaticRuleRollupOutputReference | WorkloadStatusConfigAutomaticRuleRollup): any;
export declare class WorkloadStatusConfigAutomaticRuleRollupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkloadStatusConfigAutomaticRuleRollup | undefined;
    set internalValue(value: WorkloadStatusConfigAutomaticRuleRollup | undefined);
    private _strategy?;
    get strategy(): string;
    set strategy(value: string);
    get strategyInput(): string | undefined;
    private _thresholdType?;
    get thresholdType(): string;
    set thresholdType(value: string);
    resetThresholdType(): void;
    get thresholdTypeInput(): string | undefined;
    private _thresholdValue?;
    get thresholdValue(): number;
    set thresholdValue(value: number);
    resetThresholdValue(): void;
    get thresholdValueInput(): number | undefined;
}
export interface WorkloadStatusConfigAutomaticRule {
    /**
    * A list of entity GUIDs composing the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#entity_guids Workload#entity_guids}
    */
    readonly entityGuids?: string[];
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#nrql_query Workload#nrql_query}
    */
    readonly nrqlQuery?: WorkloadStatusConfigAutomaticRuleNrqlQuery[] | cdktn.IResolvable;
    /**
    * rollup block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#rollup Workload#rollup}
    */
    readonly rollup: WorkloadStatusConfigAutomaticRuleRollup;
}
export declare function workloadStatusConfigAutomaticRuleToTerraform(struct?: WorkloadStatusConfigAutomaticRule | cdktn.IResolvable): any;
export declare function workloadStatusConfigAutomaticRuleToHclTerraform(struct?: WorkloadStatusConfigAutomaticRule | cdktn.IResolvable): any;
export declare class WorkloadStatusConfigAutomaticRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkloadStatusConfigAutomaticRule | cdktn.IResolvable | undefined;
    set internalValue(value: WorkloadStatusConfigAutomaticRule | cdktn.IResolvable | undefined);
    private _entityGuids?;
    get entityGuids(): string[];
    set entityGuids(value: string[]);
    resetEntityGuids(): void;
    get entityGuidsInput(): string[] | undefined;
    private _nrqlQuery;
    get nrqlQuery(): WorkloadStatusConfigAutomaticRuleNrqlQueryList;
    putNrqlQuery(value: WorkloadStatusConfigAutomaticRuleNrqlQuery[] | cdktn.IResolvable): void;
    resetNrqlQuery(): void;
    get nrqlQueryInput(): cdktn.IResolvable | WorkloadStatusConfigAutomaticRuleNrqlQuery[] | undefined;
    private _rollup;
    get rollup(): WorkloadStatusConfigAutomaticRuleRollupOutputReference;
    putRollup(value: WorkloadStatusConfigAutomaticRuleRollup): void;
    get rollupInput(): WorkloadStatusConfigAutomaticRuleRollup | undefined;
}
export declare class WorkloadStatusConfigAutomaticRuleList extends cdktn.ComplexList {
    internalValue?: WorkloadStatusConfigAutomaticRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkloadStatusConfigAutomaticRuleOutputReference;
}
export interface WorkloadStatusConfigAutomatic {
    /**
    * Whether the automatic status configuration is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#enabled Workload#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * remaining_entities_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#remaining_entities_rule Workload#remaining_entities_rule}
    */
    readonly remainingEntitiesRule?: WorkloadStatusConfigAutomaticRemainingEntitiesRule;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#rule Workload#rule}
    */
    readonly rule?: WorkloadStatusConfigAutomaticRule[] | cdktn.IResolvable;
}
export declare function workloadStatusConfigAutomaticToTerraform(struct?: WorkloadStatusConfigAutomaticOutputReference | WorkloadStatusConfigAutomatic): any;
export declare function workloadStatusConfigAutomaticToHclTerraform(struct?: WorkloadStatusConfigAutomaticOutputReference | WorkloadStatusConfigAutomatic): any;
export declare class WorkloadStatusConfigAutomaticOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkloadStatusConfigAutomatic | undefined;
    set internalValue(value: WorkloadStatusConfigAutomatic | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _remainingEntitiesRule;
    get remainingEntitiesRule(): WorkloadStatusConfigAutomaticRemainingEntitiesRuleOutputReference;
    putRemainingEntitiesRule(value: WorkloadStatusConfigAutomaticRemainingEntitiesRule): void;
    resetRemainingEntitiesRule(): void;
    get remainingEntitiesRuleInput(): WorkloadStatusConfigAutomaticRemainingEntitiesRule | undefined;
    private _rule;
    get rule(): WorkloadStatusConfigAutomaticRuleList;
    putRule(value: WorkloadStatusConfigAutomaticRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | WorkloadStatusConfigAutomaticRule[] | undefined;
}
export interface WorkloadStatusConfigStatic {
    /**
    * A description that provides additional details about the status of the workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#description Workload#description}
    */
    readonly description?: string;
    /**
    * Whether the static status configuration is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#enabled Workload#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The status of the workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#status Workload#status}
    */
    readonly status: string;
    /**
    * A short description of the status of the workload.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#summary Workload#summary}
    */
    readonly summary?: string;
}
export declare function workloadStatusConfigStaticToTerraform(struct?: WorkloadStatusConfigStaticOutputReference | WorkloadStatusConfigStatic): any;
export declare function workloadStatusConfigStaticToHclTerraform(struct?: WorkloadStatusConfigStaticOutputReference | WorkloadStatusConfigStatic): any;
export declare class WorkloadStatusConfigStaticOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkloadStatusConfigStatic | undefined;
    set internalValue(value: WorkloadStatusConfigStatic | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _summary?;
    get summary(): string;
    set summary(value: string);
    resetSummary(): void;
    get summaryInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload newrelic_workload}
*/
export declare class Workload extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_workload";
    /**
    * Generates CDKTN code for importing a Workload resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Workload to import
    * @param importFromId The id of the existing Workload that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Workload to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/workload newrelic_workload} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkloadConfig
    */
    constructor(scope: Construct, id: string, config: WorkloadConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    get compositeEntitySearchQuery(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _entityGuids?;
    get entityGuids(): string[];
    set entityGuids(value: string[]);
    resetEntityGuids(): void;
    get entityGuidsInput(): string[] | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get permalink(): string;
    private _scopeAccountIds?;
    get scopeAccountIds(): number[];
    set scopeAccountIds(value: number[]);
    resetScopeAccountIds(): void;
    get scopeAccountIdsInput(): number[] | undefined;
    get workloadId(): number;
    private _entitySearchQuery;
    get entitySearchQuery(): WorkloadEntitySearchQueryList;
    putEntitySearchQuery(value: WorkloadEntitySearchQuery[] | cdktn.IResolvable): void;
    resetEntitySearchQuery(): void;
    get entitySearchQueryInput(): cdktn.IResolvable | WorkloadEntitySearchQuery[] | undefined;
    private _statusConfigAutomatic;
    get statusConfigAutomatic(): WorkloadStatusConfigAutomaticOutputReference;
    putStatusConfigAutomatic(value: WorkloadStatusConfigAutomatic): void;
    resetStatusConfigAutomatic(): void;
    get statusConfigAutomaticInput(): WorkloadStatusConfigAutomatic | undefined;
    private _statusConfigStatic;
    get statusConfigStatic(): WorkloadStatusConfigStaticOutputReference;
    putStatusConfigStatic(value: WorkloadStatusConfigStatic): void;
    resetStatusConfigStatic(): void;
    get statusConfigStaticInput(): WorkloadStatusConfigStatic | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
