/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudAwsEuSovereignIntegrationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the account in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#account_id CloudAwsEuSovereignIntegrations#account_id}
    */
    readonly accountId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#id CloudAwsEuSovereignIntegrations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the linked AWS EU Sovereign account in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#linked_account_id CloudAwsEuSovereignIntegrations#linked_account_id}
    */
    readonly linkedAccountId: number;
    /**
    * billing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#billing CloudAwsEuSovereignIntegrations#billing}
    */
    readonly billing?: CloudAwsEuSovereignIntegrationsBilling;
    /**
    * cloudtrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#cloudtrail CloudAwsEuSovereignIntegrations#cloudtrail}
    */
    readonly cloudtrail?: CloudAwsEuSovereignIntegrationsCloudtrail;
    /**
    * x_ray block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#x_ray CloudAwsEuSovereignIntegrations#x_ray}
    */
    readonly xRay?: CloudAwsEuSovereignIntegrationsXRay;
}
export interface CloudAwsEuSovereignIntegrationsBilling {
    /**
    * The data polling interval in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#metrics_polling_interval CloudAwsEuSovereignIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsEuSovereignIntegrationsBillingToTerraform(struct?: CloudAwsEuSovereignIntegrationsBillingOutputReference | CloudAwsEuSovereignIntegrationsBilling): any;
export declare function cloudAwsEuSovereignIntegrationsBillingToHclTerraform(struct?: CloudAwsEuSovereignIntegrationsBillingOutputReference | CloudAwsEuSovereignIntegrationsBilling): any;
export declare class CloudAwsEuSovereignIntegrationsBillingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsEuSovereignIntegrationsBilling | undefined;
    set internalValue(value: CloudAwsEuSovereignIntegrationsBilling | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsEuSovereignIntegrationsCloudtrail {
    /**
    * Specify each AWS region that includes the resources that you want to monitor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#aws_regions CloudAwsEuSovereignIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#metrics_polling_interval CloudAwsEuSovereignIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsEuSovereignIntegrationsCloudtrailToTerraform(struct?: CloudAwsEuSovereignIntegrationsCloudtrailOutputReference | CloudAwsEuSovereignIntegrationsCloudtrail): any;
export declare function cloudAwsEuSovereignIntegrationsCloudtrailToHclTerraform(struct?: CloudAwsEuSovereignIntegrationsCloudtrailOutputReference | CloudAwsEuSovereignIntegrationsCloudtrail): any;
export declare class CloudAwsEuSovereignIntegrationsCloudtrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsEuSovereignIntegrationsCloudtrail | undefined;
    set internalValue(value: CloudAwsEuSovereignIntegrationsCloudtrail | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsEuSovereignIntegrationsXRay {
    /**
    * Specify each AWS region that includes the resources that you want to monitor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#aws_regions CloudAwsEuSovereignIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#metrics_polling_interval CloudAwsEuSovereignIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsEuSovereignIntegrationsXRayToTerraform(struct?: CloudAwsEuSovereignIntegrationsXRayOutputReference | CloudAwsEuSovereignIntegrationsXRay): any;
export declare function cloudAwsEuSovereignIntegrationsXRayToHclTerraform(struct?: CloudAwsEuSovereignIntegrationsXRayOutputReference | CloudAwsEuSovereignIntegrationsXRay): any;
export declare class CloudAwsEuSovereignIntegrationsXRayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsEuSovereignIntegrationsXRay | undefined;
    set internalValue(value: CloudAwsEuSovereignIntegrationsXRay | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations newrelic_cloud_aws_eu_sovereign_integrations}
*/
export declare class CloudAwsEuSovereignIntegrations extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_cloud_aws_eu_sovereign_integrations";
    /**
    * Generates CDKTN code for importing a CloudAwsEuSovereignIntegrations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudAwsEuSovereignIntegrations to import
    * @param importFromId The id of the existing CloudAwsEuSovereignIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudAwsEuSovereignIntegrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/cloud_aws_eu_sovereign_integrations newrelic_cloud_aws_eu_sovereign_integrations} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudAwsEuSovereignIntegrationsConfig
    */
    constructor(scope: Construct, id: string, config: CloudAwsEuSovereignIntegrationsConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _linkedAccountId?;
    get linkedAccountId(): number;
    set linkedAccountId(value: number);
    get linkedAccountIdInput(): number | undefined;
    private _billing;
    get billing(): CloudAwsEuSovereignIntegrationsBillingOutputReference;
    putBilling(value: CloudAwsEuSovereignIntegrationsBilling): void;
    resetBilling(): void;
    get billingInput(): CloudAwsEuSovereignIntegrationsBilling | undefined;
    private _cloudtrail;
    get cloudtrail(): CloudAwsEuSovereignIntegrationsCloudtrailOutputReference;
    putCloudtrail(value: CloudAwsEuSovereignIntegrationsCloudtrail): void;
    resetCloudtrail(): void;
    get cloudtrailInput(): CloudAwsEuSovereignIntegrationsCloudtrail | undefined;
    private _xRay;
    get xRay(): CloudAwsEuSovereignIntegrationsXRayOutputReference;
    putXRay(value: CloudAwsEuSovereignIntegrationsXRay): void;
    resetXRay(): void;
    get xRayInput(): CloudAwsEuSovereignIntegrationsXRay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
