/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsSecureCredentialConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where you want to create the secure credential.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential#account_id SyntheticsSecureCredential#account_id}
    */
    readonly accountId?: number;
    /**
    * The secure credential's description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential#description SyntheticsSecureCredential#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential#id SyntheticsSecureCredential#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The secure credential's key name. Regardless of the case used in the configuration, the provider will provide an upcased key to the underlying API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential#key SyntheticsSecureCredential#key}
    */
    readonly key: string;
    /**
    * The time the secure credential was last updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential#last_updated SyntheticsSecureCredential#last_updated}
    */
    readonly lastUpdated?: string;
    /**
    * The secure credential's value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential#value SyntheticsSecureCredential#value}
    */
    readonly value: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential#timeouts SyntheticsSecureCredential#timeouts}
    */
    readonly timeouts?: SyntheticsSecureCredentialTimeouts;
}
export interface SyntheticsSecureCredentialTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential#read SyntheticsSecureCredential#read}
    */
    readonly read?: string;
}
export declare function syntheticsSecureCredentialTimeoutsToTerraform(struct?: SyntheticsSecureCredentialTimeouts | cdktn.IResolvable): any;
export declare function syntheticsSecureCredentialTimeoutsToHclTerraform(struct?: SyntheticsSecureCredentialTimeouts | cdktn.IResolvable): any;
export declare class SyntheticsSecureCredentialTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsSecureCredentialTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsSecureCredentialTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential newrelic_synthetics_secure_credential}
*/
export declare class SyntheticsSecureCredential extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_synthetics_secure_credential";
    /**
    * Generates CDKTN code for importing a SyntheticsSecureCredential resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsSecureCredential to import
    * @param importFromId The id of the existing SyntheticsSecureCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsSecureCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.87.1/docs/resources/synthetics_secure_credential newrelic_synthetics_secure_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsSecureCredentialConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsSecureCredentialConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _lastUpdated?;
    get lastUpdated(): string;
    set lastUpdated(value: string);
    resetLastUpdated(): void;
    get lastUpdatedInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _timeouts;
    get timeouts(): SyntheticsSecureCredentialTimeoutsOutputReference;
    putTimeouts(value: SyntheticsSecureCredentialTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | SyntheticsSecureCredentialTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
