/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudGcpLinkAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * accountID of newrelic account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account#account_id CloudGcpLinkAccount#account_id}
    */
    readonly accountId?: number;
    /**
    * The Workload Identity Federation pool provider audience URI, used for GCP Dimensional Metrics (keyless) linking. Format: //iam.googleapis.com/projects/{PROJECT_NUMBER}/locations/global/workloadIdentityPools/{POOL_ID}/providers/{PROVIDER_ID}. Required when use_workload_identity_federation = true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account#audience CloudGcpLinkAccount#audience}
    */
    readonly audience?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account#id CloudGcpLinkAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * name of the linked account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account#name CloudGcpLinkAccount#name}
    */
    readonly name: string;
    /**
    * project id of the Gcp account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account#project_id CloudGcpLinkAccount#project_id}
    */
    readonly projectId: string;
    /**
    * The GCP service account email New Relic impersonates to collect metrics when linking via Workload Identity Federation (GCP Dimensional Metrics). The service account must grant the WIF pool the roles/iam.workloadIdentityUser binding. Required when use_workload_identity_federation = true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account#service_account_email CloudGcpLinkAccount#service_account_email}
    */
    readonly serviceAccountEmail?: string;
    /**
    * Set to true to link this GCP account for New Relic GCP Dimensional Metrics (v2) using keyless Workload Identity Federation (WIF). When true, audience and service_account_email are required. When false (the default), the account is linked using the legacy service-account-key flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account#use_workload_identity_federation CloudGcpLinkAccount#use_workload_identity_federation}
    */
    readonly useWorkloadIdentityFederation?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account newrelic_cloud_gcp_link_account}
*/
export declare class CloudGcpLinkAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_cloud_gcp_link_account";
    /**
    * Generates CDKTN code for importing a CloudGcpLinkAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudGcpLinkAccount to import
    * @param importFromId The id of the existing CloudGcpLinkAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudGcpLinkAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/cloud_gcp_link_account newrelic_cloud_gcp_link_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudGcpLinkAccountConfig
    */
    constructor(scope: Construct, id: string, config: CloudGcpLinkAccountConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    private _useWorkloadIdentityFederation?;
    get useWorkloadIdentityFederation(): boolean | cdktn.IResolvable;
    set useWorkloadIdentityFederation(value: boolean | cdktn.IResolvable);
    resetUseWorkloadIdentityFederation(): void;
    get useWorkloadIdentityFederationInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
