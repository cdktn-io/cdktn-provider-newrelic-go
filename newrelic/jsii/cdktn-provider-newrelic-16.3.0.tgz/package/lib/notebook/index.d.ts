/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NotebookConfig extends cdktn.TerraformMetaArguments {
    /**
    * The notebook body as a JSON string. Accepts a raw JSON string, a file() reference, or a jsonencode({...}) expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook#content Notebook#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook#id Notebook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The title of the notebook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook#title Notebook#title}
    */
    readonly title: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook#timeouts Notebook#timeouts}
    */
    readonly timeouts?: NotebookTimeouts;
}
export interface NotebookTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook#create Notebook#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook#delete Notebook#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook#update Notebook#update}
    */
    readonly update?: string;
}
export declare function notebookTimeoutsToTerraform(struct?: NotebookTimeouts | cdktn.IResolvable): any;
export declare function notebookTimeoutsToHclTerraform(struct?: NotebookTimeouts | cdktn.IResolvable): any;
export declare class NotebookTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotebookTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: NotebookTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook newrelic_notebook}
*/
export declare class Notebook extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_notebook";
    /**
    * Generates CDKTN code for importing a Notebook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Notebook to import
    * @param importFromId The id of the existing Notebook that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Notebook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/notebook newrelic_notebook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotebookConfig
    */
    constructor(scope: Construct, id: string, config: NotebookConfig);
    get blobId(): string;
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _timeouts;
    get timeouts(): NotebookTimeoutsOutputReference;
    putTimeouts(value: NotebookTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | NotebookTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
