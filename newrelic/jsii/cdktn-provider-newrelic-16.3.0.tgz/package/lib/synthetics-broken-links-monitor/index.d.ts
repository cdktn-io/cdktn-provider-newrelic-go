/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsBrokenLinksMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the newrelic account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#account_id SyntheticsBrokenLinksMonitor#account_id}
    */
    readonly accountId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#id SyntheticsBrokenLinksMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * List private location GUIDs for which the monitor will run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#locations_private SyntheticsBrokenLinksMonitor#locations_private}
    */
    readonly locationsPrivate?: string[];
    /**
    * Publicly available location names in which the monitor will run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#locations_public SyntheticsBrokenLinksMonitor#locations_public}
    */
    readonly locationsPublic?: string[];
    /**
    * The title of this monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#name SyntheticsBrokenLinksMonitor#name}
    */
    readonly name: string;
    /**
    * The interval at which this monitor should run. Valid values are EVERY_MINUTE, EVERY_5_MINUTES, EVERY_10_MINUTES, EVERY_15_MINUTES, EVERY_30_MINUTES, EVERY_HOUR, EVERY_6_HOURS, EVERY_12_HOURS, or EVERY_DAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#period SyntheticsBrokenLinksMonitor#period}
    */
    readonly period: string;
    /**
    * The runtime type that the monitor will run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#runtime_type SyntheticsBrokenLinksMonitor#runtime_type}
    */
    readonly runtimeType?: string;
    /**
    * The specific semver version of the runtime type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#runtime_type_version SyntheticsBrokenLinksMonitor#runtime_type_version}
    */
    readonly runtimeTypeVersion?: string;
    /**
    * The monitor status (ENABLED or DISABLED).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#status SyntheticsBrokenLinksMonitor#status}
    */
    readonly status: string;
    /**
    * The URI the monitor runs against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#uri SyntheticsBrokenLinksMonitor#uri}
    */
    readonly uri: string;
    /**
    * A boolean attribute to be set true by the customer, if they would like to use the unsupported legacy runtime of Synthetic Monitors by means of an exemption given until the October 22, 2024 Legacy Runtime EOL. Setting this attribute to true would allow skipping validation performed by the the New Relic Terraform Provider starting v3.43.0 to disallow using the legacy runtime with new monitors. This would, hence, allow creation of monitors in the legacy runtime until the October 22, 2024 Legacy Runtime EOL, if exempt by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#use_unsupported_legacy_runtime SyntheticsBrokenLinksMonitor#use_unsupported_legacy_runtime}
    */
    readonly useUnsupportedLegacyRuntime?: boolean | cdktn.IResolvable;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#tag SyntheticsBrokenLinksMonitor#tag}
    */
    readonly tag?: SyntheticsBrokenLinksMonitorTag[] | cdktn.IResolvable;
}
export interface SyntheticsBrokenLinksMonitorTag {
    /**
    * Name of the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#key SyntheticsBrokenLinksMonitor#key}
    */
    readonly key: string;
    /**
    * Values associated with the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#values SyntheticsBrokenLinksMonitor#values}
    */
    readonly values: string[];
}
export declare function syntheticsBrokenLinksMonitorTagToTerraform(struct?: SyntheticsBrokenLinksMonitorTag | cdktn.IResolvable): any;
export declare function syntheticsBrokenLinksMonitorTagToHclTerraform(struct?: SyntheticsBrokenLinksMonitorTag | cdktn.IResolvable): any;
export declare class SyntheticsBrokenLinksMonitorTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsBrokenLinksMonitorTag | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsBrokenLinksMonitorTag | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class SyntheticsBrokenLinksMonitorTagList extends cdktn.ComplexList {
    internalValue?: SyntheticsBrokenLinksMonitorTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsBrokenLinksMonitorTagOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor newrelic_synthetics_broken_links_monitor}
*/
export declare class SyntheticsBrokenLinksMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_synthetics_broken_links_monitor";
    /**
    * Generates CDKTN code for importing a SyntheticsBrokenLinksMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsBrokenLinksMonitor to import
    * @param importFromId The id of the existing SyntheticsBrokenLinksMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsBrokenLinksMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/resources/synthetics_broken_links_monitor newrelic_synthetics_broken_links_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsBrokenLinksMonitorConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsBrokenLinksMonitorConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationsPrivate?;
    get locationsPrivate(): string[];
    set locationsPrivate(value: string[]);
    resetLocationsPrivate(): void;
    get locationsPrivateInput(): string[] | undefined;
    private _locationsPublic?;
    get locationsPublic(): string[];
    set locationsPublic(value: string[]);
    resetLocationsPublic(): void;
    get locationsPublicInput(): string[] | undefined;
    get monitorId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    get periodInput(): string | undefined;
    get periodInMinutes(): number;
    private _runtimeType?;
    get runtimeType(): string;
    set runtimeType(value: string);
    resetRuntimeType(): void;
    get runtimeTypeInput(): string | undefined;
    private _runtimeTypeVersion?;
    get runtimeTypeVersion(): string;
    set runtimeTypeVersion(value: string);
    resetRuntimeTypeVersion(): void;
    get runtimeTypeVersionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
    private _useUnsupportedLegacyRuntime?;
    get useUnsupportedLegacyRuntime(): boolean | cdktn.IResolvable;
    set useUnsupportedLegacyRuntime(value: boolean | cdktn.IResolvable);
    resetUseUnsupportedLegacyRuntime(): void;
    get useUnsupportedLegacyRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _tag;
    get tag(): SyntheticsBrokenLinksMonitorTagList;
    putTag(value: SyntheticsBrokenLinksMonitorTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | SyntheticsBrokenLinksMonitorTag[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
