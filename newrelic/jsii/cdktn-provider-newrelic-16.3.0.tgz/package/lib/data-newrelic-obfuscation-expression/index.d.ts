/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicObfuscationExpressionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id associated with the obfuscation expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/obfuscation_expression#account_id DataNewrelicObfuscationExpression#account_id}
    */
    readonly accountId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/obfuscation_expression#id DataNewrelicObfuscationExpression#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/obfuscation_expression#name DataNewrelicObfuscationExpression#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/obfuscation_expression newrelic_obfuscation_expression}
*/
export declare class DataNewrelicObfuscationExpression extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_obfuscation_expression";
    /**
    * Generates CDKTN code for importing a DataNewrelicObfuscationExpression resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicObfuscationExpression to import
    * @param importFromId The id of the existing DataNewrelicObfuscationExpression that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/obfuscation_expression#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicObfuscationExpression to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/obfuscation_expression newrelic_obfuscation_expression} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicObfuscationExpressionConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicObfuscationExpressionConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
