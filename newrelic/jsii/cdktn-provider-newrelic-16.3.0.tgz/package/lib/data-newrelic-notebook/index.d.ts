/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicNotebookConfig extends cdktn.TerraformMetaArguments {
    /**
    * When true, the full notebook body is fetched from the Blob Storage API and stored in the `content` attribute. When false (default), only NerdGraph metadata (title, organization_id, blob_id) is retrieved, which is faster and avoids an extra API call.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/notebook#fetch_content DataNewrelicNotebook#fetch_content}
    */
    readonly fetchContent?: boolean | cdktn.IResolvable;
    /**
    * The unique entity identifier (GUID) of the notebook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/notebook#guid DataNewrelicNotebook#guid}
    */
    readonly guid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/notebook#id DataNewrelicNotebook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/notebook newrelic_notebook}
*/
export declare class DataNewrelicNotebook extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_notebook";
    /**
    * Generates CDKTN code for importing a DataNewrelicNotebook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicNotebook to import
    * @param importFromId The id of the existing DataNewrelicNotebook that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/notebook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicNotebook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.1/docs/data-sources/notebook newrelic_notebook} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicNotebookConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicNotebookConfig);
    get blobId(): string;
    get content(): string;
    private _fetchContent?;
    get fetchContent(): boolean | cdktn.IResolvable;
    set fetchContent(value: boolean | cdktn.IResolvable);
    resetFetchContent(): void;
    get fetchContentInput(): boolean | cdktn.IResolvable | undefined;
    private _guid?;
    get guid(): string;
    set guid(value: string);
    get guidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationId(): string;
    get title(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
