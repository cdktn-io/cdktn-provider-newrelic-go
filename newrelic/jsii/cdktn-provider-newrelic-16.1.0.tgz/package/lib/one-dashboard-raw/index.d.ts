/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OneDashboardRawConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where you want to create the dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#account_id OneDashboardRaw#account_id}
    */
    readonly accountId?: number;
    /**
    * The dashboard's description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#description OneDashboardRaw#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#id OneDashboardRaw#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The dashboard's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#name OneDashboardRaw#name}
    */
    readonly name: string;
    /**
    * Determines who can see or edit the dashboard. Valid values are private, public_read_only, public_read_write. Defaults to public_read_only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#permissions OneDashboardRaw#permissions}
    */
    readonly permissions?: string;
    /**
    * page block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#page OneDashboardRaw#page}
    */
    readonly page: OneDashboardRawPage[] | cdktn.IResolvable;
}
export interface OneDashboardRawPageWidget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#column OneDashboardRaw#column}
    */
    readonly column: number;
    /**
    * The configuration of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#configuration OneDashboardRaw#configuration}
    */
    readonly configuration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#height OneDashboardRaw#height}
    */
    readonly height?: number;
    /**
    * (Optional) Related entity GUIDs. Currently only supports Dashboard entity GUIDs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#linked_entity_guids OneDashboardRaw#linked_entity_guids}
    */
    readonly linkedEntityGuids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#row OneDashboardRaw#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#title OneDashboardRaw#title}
    */
    readonly title: string;
    /**
    * The visualization ID of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#visualization_id OneDashboardRaw#visualization_id}
    */
    readonly visualizationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#width OneDashboardRaw#width}
    */
    readonly width?: number;
}
export declare function oneDashboardRawPageWidgetToTerraform(struct?: OneDashboardRawPageWidget | cdktn.IResolvable): any;
export declare function oneDashboardRawPageWidgetToHclTerraform(struct?: OneDashboardRawPageWidget | cdktn.IResolvable): any;
export declare class OneDashboardRawPageWidgetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardRawPageWidget | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardRawPageWidget | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    get configurationInput(): string | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _linkedEntityGuids?;
    get linkedEntityGuids(): string[];
    set linkedEntityGuids(value: string[]);
    resetLinkedEntityGuids(): void;
    get linkedEntityGuidsInput(): string[] | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _visualizationId?;
    get visualizationId(): string;
    set visualizationId(value: string);
    get visualizationIdInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
}
export declare class OneDashboardRawPageWidgetList extends cdktn.ComplexList {
    internalValue?: OneDashboardRawPageWidget[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardRawPageWidgetOutputReference;
}
export interface OneDashboardRawPage {
    /**
    * The dashboard page's description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#description OneDashboardRaw#description}
    */
    readonly description?: string;
    /**
    * The dashboard page's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#name OneDashboardRaw#name}
    */
    readonly name: string;
    /**
    * widget block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#widget OneDashboardRaw#widget}
    */
    readonly widget?: OneDashboardRawPageWidget[] | cdktn.IResolvable;
}
export declare function oneDashboardRawPageToTerraform(struct?: OneDashboardRawPage | cdktn.IResolvable): any;
export declare function oneDashboardRawPageToHclTerraform(struct?: OneDashboardRawPage | cdktn.IResolvable): any;
export declare class OneDashboardRawPageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardRawPage | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardRawPage | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get guid(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _widget;
    get widget(): OneDashboardRawPageWidgetList;
    putWidget(value: OneDashboardRawPageWidget[] | cdktn.IResolvable): void;
    resetWidget(): void;
    get widgetInput(): cdktn.IResolvable | OneDashboardRawPageWidget[] | undefined;
}
export declare class OneDashboardRawPageList extends cdktn.ComplexList {
    internalValue?: OneDashboardRawPage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardRawPageOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw newrelic_one_dashboard_raw}
*/
export declare class OneDashboardRaw extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_one_dashboard_raw";
    /**
    * Generates CDKTN code for importing a OneDashboardRaw resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OneDashboardRaw to import
    * @param importFromId The id of the existing OneDashboardRaw that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OneDashboardRaw to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.0/docs/resources/one_dashboard_raw newrelic_one_dashboard_raw} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OneDashboardRawConfig
    */
    constructor(scope: Construct, id: string, config: OneDashboardRawConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get permalink(): string;
    private _permissions?;
    get permissions(): string;
    set permissions(value: string);
    resetPermissions(): void;
    get permissionsInput(): string | undefined;
    private _page;
    get page(): OneDashboardRawPageList;
    putPage(value: OneDashboardRawPage[] | cdktn.IResolvable): void;
    get pageInput(): cdktn.IResolvable | OneDashboardRawPage[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
