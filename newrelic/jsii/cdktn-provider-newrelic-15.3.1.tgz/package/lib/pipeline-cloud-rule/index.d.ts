/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PipelineCloudRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account ID where the Pipeline Cloud rule will be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.1/docs/resources/pipeline_cloud_rule#account_id PipelineCloudRule#account_id}
    */
    readonly accountId?: number;
    /**
    * Provides additional information about the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.1/docs/resources/pipeline_cloud_rule#description PipelineCloudRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.1/docs/resources/pipeline_cloud_rule#id PipelineCloudRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the rule. This must be unique within an account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.1/docs/resources/pipeline_cloud_rule#name PipelineCloudRule#name}
    */
    readonly name: string;
    /**
    * The NRQL query that defines which data will be processed by this pipeline cloud rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.1/docs/resources/pipeline_cloud_rule#nrql PipelineCloudRule#nrql}
    */
    readonly nrql: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.1/docs/resources/pipeline_cloud_rule newrelic_pipeline_cloud_rule}
*/
export declare class PipelineCloudRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_pipeline_cloud_rule";
    /**
    * Generates CDKTN code for importing a PipelineCloudRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PipelineCloudRule to import
    * @param importFromId The id of the existing PipelineCloudRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.1/docs/resources/pipeline_cloud_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PipelineCloudRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.1/docs/resources/pipeline_cloud_rule newrelic_pipeline_cloud_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PipelineCloudRuleConfig
    */
    constructor(scope: Construct, id: string, config: PipelineCloudRuleConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
