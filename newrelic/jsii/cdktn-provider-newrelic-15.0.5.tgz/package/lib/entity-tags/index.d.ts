/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EntityTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The guid of the entity to tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags#guid EntityTags#guid}
    */
    readonly guid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags#id EntityTags#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags#tag EntityTags#tag}
    */
    readonly tag: EntityTagsTag[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags#timeouts EntityTags#timeouts}
    */
    readonly timeouts?: EntityTagsTimeouts;
}
export interface EntityTagsTag {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags#key EntityTags#key}
    */
    readonly key: string;
    /**
    * The tag values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags#values EntityTags#values}
    */
    readonly values: string[];
}
export declare function entityTagsTagToTerraform(struct?: EntityTagsTag | cdktn.IResolvable): any;
export declare function entityTagsTagToHclTerraform(struct?: EntityTagsTag | cdktn.IResolvable): any;
export declare class EntityTagsTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EntityTagsTag | cdktn.IResolvable | undefined;
    set internalValue(value: EntityTagsTag | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class EntityTagsTagList extends cdktn.ComplexList {
    internalValue?: EntityTagsTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EntityTagsTagOutputReference;
}
export interface EntityTagsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags#create EntityTags#create}
    */
    readonly create?: string;
}
export declare function entityTagsTimeoutsToTerraform(struct?: EntityTagsTimeouts | cdktn.IResolvable): any;
export declare function entityTagsTimeoutsToHclTerraform(struct?: EntityTagsTimeouts | cdktn.IResolvable): any;
export declare class EntityTagsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EntityTagsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: EntityTagsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags newrelic_entity_tags}
*/
export declare class EntityTags extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_entity_tags";
    /**
    * Generates CDKTN code for importing a EntityTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EntityTags to import
    * @param importFromId The id of the existing EntityTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EntityTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/entity_tags newrelic_entity_tags} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EntityTagsConfig
    */
    constructor(scope: Construct, id: string, config: EntityTagsConfig);
    private _guid?;
    get guid(): string;
    set guid(value: string);
    get guidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _tag;
    get tag(): EntityTagsTagList;
    putTag(value: EntityTagsTag[] | cdktn.IResolvable): void;
    get tagInput(): cdktn.IResolvable | EntityTagsTag[] | undefined;
    private _timeouts;
    get timeouts(): EntityTagsTimeoutsOutputReference;
    putTimeouts(value: EntityTagsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | EntityTagsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
