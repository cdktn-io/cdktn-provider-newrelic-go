/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsAlertConditionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Set whether to enable the alert condition. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/synthetics_alert_condition#enabled SyntheticsAlertCondition#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/synthetics_alert_condition#id SyntheticsAlertCondition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the Synthetics monitor to be referenced in the alert condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/synthetics_alert_condition#monitor_id SyntheticsAlertCondition#monitor_id}
    */
    readonly monitorId: string;
    /**
    * The title of this condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/synthetics_alert_condition#name SyntheticsAlertCondition#name}
    */
    readonly name: string;
    /**
    * The ID of the policy where this condition should be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/synthetics_alert_condition#policy_id SyntheticsAlertCondition#policy_id}
    */
    readonly policyId: number;
    /**
    * Runbook URL to display in notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/synthetics_alert_condition#runbook_url SyntheticsAlertCondition#runbook_url}
    */
    readonly runbookUrl?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/synthetics_alert_condition newrelic_synthetics_alert_condition}
*/
export declare class SyntheticsAlertCondition extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_synthetics_alert_condition";
    /**
    * Generates CDKTN code for importing a SyntheticsAlertCondition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsAlertCondition to import
    * @param importFromId The id of the existing SyntheticsAlertCondition that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/synthetics_alert_condition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsAlertCondition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.90.0/docs/resources/synthetics_alert_condition newrelic_synthetics_alert_condition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsAlertConditionConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsAlertConditionConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get entityGuid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _monitorId?;
    get monitorId(): string;
    set monitorId(value: string);
    get monitorIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyId?;
    get policyId(): number;
    set policyId(value: number);
    get policyIdInput(): number | undefined;
    private _runbookUrl?;
    get runbookUrl(): string;
    set runbookUrl(value: string);
    resetRunbookUrl(): void;
    get runbookUrlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
