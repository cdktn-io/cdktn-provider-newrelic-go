/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Authentication Domain the group being queried would belong to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/group#authentication_domain_id DataNewrelicGroup#authentication_domain_id}
    */
    readonly authenticationDomainId: string;
    /**
    * The name of the group to be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/group#name DataNewrelicGroup#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/group newrelic_group}
*/
export declare class DataNewrelicGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_group";
    /**
    * Generates CDKTN code for importing a DataNewrelicGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicGroup to import
    * @param importFromId The id of the existing DataNewrelicGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/group newrelic_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicGroupConfig);
    private _authenticationDomainId?;
    get authenticationDomainId(): string;
    set authenticationDomainId(value: string);
    get authenticationDomainIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get userIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
