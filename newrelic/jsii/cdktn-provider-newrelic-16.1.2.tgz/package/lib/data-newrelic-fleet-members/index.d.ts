/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicFleetMembersConfig extends cdktn.TerraformMetaArguments {
    /**
    * The GUID of the fleet to list members for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/fleet_members#fleet_id DataNewrelicFleetMembers#fleet_id}
    */
    readonly fleetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/fleet_members#id DataNewrelicFleetMembers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filter members by ring name. If omitted, all members across all rings are returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/fleet_members#ring DataNewrelicFleetMembers#ring}
    */
    readonly ring?: string;
}
export interface DataNewrelicFleetMembersMembers {
}
export declare function dataNewrelicFleetMembersMembersToTerraform(struct?: DataNewrelicFleetMembersMembers): any;
export declare function dataNewrelicFleetMembersMembersToHclTerraform(struct?: DataNewrelicFleetMembersMembers): any;
export declare class DataNewrelicFleetMembersMembersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNewrelicFleetMembersMembers | undefined;
    set internalValue(value: DataNewrelicFleetMembersMembers | undefined);
    get id(): string;
    get name(): string;
    get type(): string;
}
export declare class DataNewrelicFleetMembersMembersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNewrelicFleetMembersMembersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/fleet_members newrelic_fleet_members}
*/
export declare class DataNewrelicFleetMembers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_fleet_members";
    /**
    * Generates CDKTN code for importing a DataNewrelicFleetMembers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicFleetMembers to import
    * @param importFromId The id of the existing DataNewrelicFleetMembers that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/fleet_members#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicFleetMembers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/data-sources/fleet_members newrelic_fleet_members} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicFleetMembersConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicFleetMembersConfig);
    private _fleetId?;
    get fleetId(): string;
    set fleetId(value: string);
    get fleetIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _members;
    get members(): DataNewrelicFleetMembersMembersList;
    private _ring?;
    get ring(): string;
    set ring(value: string);
    resetRing(): void;
    get ringInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
