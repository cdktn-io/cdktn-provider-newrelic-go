/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FleetDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#description FleetDeployment#description}
    */
    readonly description?: string;
    /**
    * The GUID of the fleet this deployment belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#fleet_id FleetDeployment#fleet_id}
    */
    readonly fleetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#id FleetDeployment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#name FleetDeployment#name}
    */
    readonly name: string;
    /**
    * The organization ID. Auto-fetched from the account if not provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#organization_id FleetDeployment#organization_id}
    */
    readonly organizationId?: string;
    /**
    * Tags for the deployment in format 'key:value1,value2'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#tags FleetDeployment#tags}
    */
    readonly tags?: string[];
    /**
    * agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#agent FleetDeployment#agent}
    */
    readonly agent?: FleetDeploymentAgent[] | cdktn.IResolvable;
}
export interface FleetDeploymentAgent {
    /**
    * The agent type. Allowed values: NRInfra, NRDOT, FluentBit, NRPrometheusAgent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#agent_type FleetDeployment#agent_type}
    */
    readonly agentType: string;
    /**
    * Configuration version entity GUID to associate with this agent in the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#configuration_version_id FleetDeployment#configuration_version_id}
    */
    readonly configurationVersionId: string;
    /**
    * The agent version to deploy (e.g. "1.58.0").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#version FleetDeployment#version}
    */
    readonly version: string;
}
export declare function fleetDeploymentAgentToTerraform(struct?: FleetDeploymentAgent | cdktn.IResolvable): any;
export declare function fleetDeploymentAgentToHclTerraform(struct?: FleetDeploymentAgent | cdktn.IResolvable): any;
export declare class FleetDeploymentAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FleetDeploymentAgent | cdktn.IResolvable | undefined;
    set internalValue(value: FleetDeploymentAgent | cdktn.IResolvable | undefined);
    private _agentType?;
    get agentType(): string;
    set agentType(value: string);
    get agentTypeInput(): string | undefined;
    private _configurationVersionId?;
    get configurationVersionId(): string;
    set configurationVersionId(value: string);
    get configurationVersionIdInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export declare class FleetDeploymentAgentList extends cdktn.ComplexList {
    internalValue?: FleetDeploymentAgent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FleetDeploymentAgentOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment newrelic_fleet_deployment}
*/
export declare class FleetDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_fleet_deployment";
    /**
    * Generates CDKTN code for importing a FleetDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FleetDeployment to import
    * @param importFromId The id of the existing FleetDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FleetDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/fleet_deployment newrelic_fleet_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FleetDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: FleetDeploymentConfig);
    get deploymentId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _fleetId?;
    get fleetId(): string;
    set fleetId(value: string);
    get fleetIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    resetOrganizationId(): void;
    get organizationIdInput(): string | undefined;
    get phase(): string;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _agent;
    get agent(): FleetDeploymentAgentList;
    putAgent(value: FleetDeploymentAgent[] | cdktn.IResolvable): void;
    resetAgent(): void;
    get agentInput(): cdktn.IResolvable | FleetDeploymentAgent[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
