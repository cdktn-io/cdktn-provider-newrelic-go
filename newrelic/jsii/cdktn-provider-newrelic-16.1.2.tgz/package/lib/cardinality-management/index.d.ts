/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CardinalityManagementConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account-wide cardinality limit — the maximum number of unique dimension-value combinations allowed per metric per day. Required when `mode` is `DEFAULT`; must not be set when `mode` is `PER_METRIC`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/cardinality_management#cardinality_limit CardinalityManagement#cardinality_limit}
    */
    readonly cardinalityLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/cardinality_management#id CardinalityManagement#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The override mode. Use `DEFAULT` to set a single account-wide limit that applies to all metrics, or `PER_METRIC` to set individual limits for one or more named metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/cardinality_management#mode CardinalityManagement#mode}
    */
    readonly mode: string;
    /**
    * metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/cardinality_management#metric CardinalityManagement#metric}
    */
    readonly metric?: CardinalityManagementMetric[] | cdktn.IResolvable;
}
export interface CardinalityManagementMetric {
    /**
    * The maximum number of unique dimension-value combinations allowed per day for this metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/cardinality_management#cardinality_limit CardinalityManagement#cardinality_limit}
    */
    readonly cardinalityLimit: number;
    /**
    * The full name of the metric (e.g. `http.server.duration`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/cardinality_management#name CardinalityManagement#name}
    */
    readonly name: string;
}
export declare function cardinalityManagementMetricToTerraform(struct?: CardinalityManagementMetric | cdktn.IResolvable): any;
export declare function cardinalityManagementMetricToHclTerraform(struct?: CardinalityManagementMetric | cdktn.IResolvable): any;
export declare class CardinalityManagementMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CardinalityManagementMetric | cdktn.IResolvable | undefined;
    set internalValue(value: CardinalityManagementMetric | cdktn.IResolvable | undefined);
    private _cardinalityLimit?;
    get cardinalityLimit(): number;
    set cardinalityLimit(value: number);
    get cardinalityLimitInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class CardinalityManagementMetricList extends cdktn.ComplexList {
    internalValue?: CardinalityManagementMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CardinalityManagementMetricOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/cardinality_management newrelic_cardinality_management}
*/
export declare class CardinalityManagement extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_cardinality_management";
    /**
    * Generates CDKTN code for importing a CardinalityManagement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CardinalityManagement to import
    * @param importFromId The id of the existing CardinalityManagement that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/cardinality_management#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CardinalityManagement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.3/docs/resources/cardinality_management newrelic_cardinality_management} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CardinalityManagementConfig
    */
    constructor(scope: Construct, id: string, config: CardinalityManagementConfig);
    private _cardinalityLimit?;
    get cardinalityLimit(): number;
    set cardinalityLimit(value: number);
    resetCardinalityLimit(): void;
    get cardinalityLimitInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _metric;
    get metric(): CardinalityManagementMetricList;
    putMetric(value: CardinalityManagementMetric[] | cdktn.IResolvable): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | CardinalityManagementMetric[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
