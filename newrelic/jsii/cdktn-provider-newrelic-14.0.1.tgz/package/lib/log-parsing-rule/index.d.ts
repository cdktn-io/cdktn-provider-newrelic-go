/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogParsingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id associated with the obfuscation expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#account_id LogParsingRule#account_id}
    */
    readonly accountId?: number;
    /**
    * The parsing rule will apply to value of this attribute. If field is not provided, value will default to message.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#attribute LogParsingRule#attribute}
    */
    readonly attribute?: string;
    /**
    * Whether or not this rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#enabled LogParsingRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The Grok of what to parse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#grok LogParsingRule#grok}
    */
    readonly grok: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#id LogParsingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Lucene to match events to the parsing rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#lucene LogParsingRule#lucene}
    */
    readonly lucene: string;
    /**
    * Whether the Grok pattern matched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#matched LogParsingRule#matched}
    */
    readonly matched?: boolean | cdktn.IResolvable;
    /**
    * A description of what this parsing rule represents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#name LogParsingRule#name}
    */
    readonly name: string;
    /**
    * The NRQL to match events to the parsing rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#nrql LogParsingRule#nrql}
    */
    readonly nrql: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule newrelic_log_parsing_rule}
*/
export declare class LogParsingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_log_parsing_rule";
    /**
    * Generates CDKTN code for importing a LogParsingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogParsingRule to import
    * @param importFromId The id of the existing LogParsingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogParsingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.80.3/docs/resources/log_parsing_rule newrelic_log_parsing_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogParsingRuleConfig
    */
    constructor(scope: Construct, id: string, config: LogParsingRuleConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    get deleted(): cdktn.IResolvable;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _grok?;
    get grok(): string;
    set grok(value: string);
    get grokInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lucene?;
    get lucene(): string;
    set lucene(value: string);
    get luceneInput(): string | undefined;
    private _matched?;
    get matched(): boolean | cdktn.IResolvable;
    set matched(value: boolean | cdktn.IResolvable);
    resetMatched(): void;
    get matchedInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
