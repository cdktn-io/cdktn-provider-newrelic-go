/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PathpointFlowConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID that owns this Pathpoint flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#account_id PathpointFlow#account_id}
    */
    readonly accountId?: number;
    /**
    * Optional category used to group flows (e.g. Marketing, Checkout).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#category PathpointFlow#category}
    */
    readonly category?: string;
    /**
    * Optional description of the flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#description PathpointFlow#description}
    */
    readonly description?: string;
    /**
    * Health rollup strategy: ALERT_CONDITIONS or AUTOMATIC_ROLL_UP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#health_rollup PathpointFlow#health_rollup}
    */
    readonly healthRollup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#id PathpointFlow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Display name of the Pathpoint flow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#name PathpointFlow#name}
    */
    readonly name: string;
    /**
    * How often health statuses refresh: ONE_MINUTE, FIVE_MINUTES, TEN_MINUTES, FIFTEEN_MINUTES, THIRTY_MINUTES.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#refresh_interval PathpointFlow#refresh_interval}
    */
    readonly refreshInterval?: string;
    /**
    * kpis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#kpis PathpointFlow#kpis}
    */
    readonly kpis?: PathpointFlowKpis[] | cdktn.IResolvable;
    /**
    * stages block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#stages PathpointFlow#stages}
    */
    readonly stages?: PathpointFlowStages[] | cdktn.IResolvable;
}
export interface PathpointFlowKpisQuerySelect {
    /**
    * Aggregation function: AVERAGE, COUNT, HISTOGRAM, MAX, MIN, PERCENTILE, SUM, UNIQUE_COUNT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#aggregation_type PathpointFlow#aggregation_type}
    */
    readonly aggregationType: string;
    /**
    * Optional alias for the aggregated value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#alias PathpointFlow#alias}
    */
    readonly alias?: string;
    /**
    * Attribute name to aggregate. Required for all functions except COUNT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#attribute PathpointFlow#attribute}
    */
    readonly attribute?: string;
    /**
    * Threshold used in the selected function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#threshold PathpointFlow#threshold}
    */
    readonly threshold?: number;
}
export declare function pathpointFlowKpisQuerySelectToTerraform(struct?: PathpointFlowKpisQuerySelectOutputReference | PathpointFlowKpisQuerySelect): any;
export declare function pathpointFlowKpisQuerySelectToHclTerraform(struct?: PathpointFlowKpisQuerySelectOutputReference | PathpointFlowKpisQuerySelect): any;
export declare class PathpointFlowKpisQuerySelectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowKpisQuerySelect | undefined;
    set internalValue(value: PathpointFlowKpisQuerySelect | undefined);
    private _aggregationType?;
    get aggregationType(): string;
    set aggregationType(value: string);
    get aggregationTypeInput(): string | undefined;
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
}
export interface PathpointFlowKpisQueryTimeWindowRelativeRange {
    /**
    * The earlier window to compare against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#compare_against PathpointFlow#compare_against}
    */
    readonly compareAgainst?: string;
    /**
    * How far back the KPI is evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#since PathpointFlow#since}
    */
    readonly since: string;
}
export declare function pathpointFlowKpisQueryTimeWindowRelativeRangeToTerraform(struct?: PathpointFlowKpisQueryTimeWindowRelativeRangeOutputReference | PathpointFlowKpisQueryTimeWindowRelativeRange): any;
export declare function pathpointFlowKpisQueryTimeWindowRelativeRangeToHclTerraform(struct?: PathpointFlowKpisQueryTimeWindowRelativeRangeOutputReference | PathpointFlowKpisQueryTimeWindowRelativeRange): any;
export declare class PathpointFlowKpisQueryTimeWindowRelativeRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowKpisQueryTimeWindowRelativeRange | undefined;
    set internalValue(value: PathpointFlowKpisQueryTimeWindowRelativeRange | undefined);
    private _compareAgainst?;
    get compareAgainst(): string;
    set compareAgainst(value: string);
    resetCompareAgainst(): void;
    get compareAgainstInput(): string | undefined;
    private _since?;
    get since(): string;
    set since(value: string);
    get sinceInput(): string | undefined;
}
export interface PathpointFlowKpisQueryTimeWindow {
    /**
    * Raw NRQL time fragment, e.g. 'SINCE 3 days ago COMPARE WITH 1 day ago'. Mutually exclusive with relative_range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#custom_range PathpointFlow#custom_range}
    */
    readonly customRange?: string;
    /**
    * relative_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#relative_range PathpointFlow#relative_range}
    */
    readonly relativeRange?: PathpointFlowKpisQueryTimeWindowRelativeRange;
}
export declare function pathpointFlowKpisQueryTimeWindowToTerraform(struct?: PathpointFlowKpisQueryTimeWindowOutputReference | PathpointFlowKpisQueryTimeWindow): any;
export declare function pathpointFlowKpisQueryTimeWindowToHclTerraform(struct?: PathpointFlowKpisQueryTimeWindowOutputReference | PathpointFlowKpisQueryTimeWindow): any;
export declare class PathpointFlowKpisQueryTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowKpisQueryTimeWindow | undefined;
    set internalValue(value: PathpointFlowKpisQueryTimeWindow | undefined);
    private _customRange?;
    get customRange(): string;
    set customRange(value: string);
    resetCustomRange(): void;
    get customRangeInput(): string | undefined;
    private _relativeRange;
    get relativeRange(): PathpointFlowKpisQueryTimeWindowRelativeRangeOutputReference;
    putRelativeRange(value: PathpointFlowKpisQueryTimeWindowRelativeRange): void;
    resetRelativeRange(): void;
    get relativeRangeInput(): PathpointFlowKpisQueryTimeWindowRelativeRange | undefined;
}
export interface PathpointFlowKpisQuery {
    /**
    * Data source to query from (e.g., Transaction, Metric, Log).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#from PathpointFlow#from}
    */
    readonly from: string;
    /**
    * Optional WHERE clause to filter data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#where PathpointFlow#where}
    */
    readonly where?: string;
    /**
    * select block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#select PathpointFlow#select}
    */
    readonly select: PathpointFlowKpisQuerySelect;
    /**
    * time_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#time_window PathpointFlow#time_window}
    */
    readonly timeWindow?: PathpointFlowKpisQueryTimeWindow;
}
export declare function pathpointFlowKpisQueryToTerraform(struct?: PathpointFlowKpisQueryOutputReference | PathpointFlowKpisQuery): any;
export declare function pathpointFlowKpisQueryToHclTerraform(struct?: PathpointFlowKpisQueryOutputReference | PathpointFlowKpisQuery): any;
export declare class PathpointFlowKpisQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowKpisQuery | undefined;
    set internalValue(value: PathpointFlowKpisQuery | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    get fromInput(): string | undefined;
    private _where?;
    get where(): string;
    set where(value: string);
    resetWhere(): void;
    get whereInput(): string | undefined;
    private _select;
    get select(): PathpointFlowKpisQuerySelectOutputReference;
    putSelect(value: PathpointFlowKpisQuerySelect): void;
    get selectInput(): PathpointFlowKpisQuerySelect | undefined;
    private _timeWindow;
    get timeWindow(): PathpointFlowKpisQueryTimeWindowOutputReference;
    putTimeWindow(value: PathpointFlowKpisQueryTimeWindow): void;
    resetTimeWindow(): void;
    get timeWindowInput(): PathpointFlowKpisQueryTimeWindow | undefined;
}
export interface PathpointFlowKpis {
    /**
    * Account ID this KPI belongs to. Defaults to the flow's account_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#account_id PathpointFlow#account_id}
    */
    readonly accountId?: number;
    /**
    * Optional category to group KPIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#category PathpointFlow#category}
    */
    readonly category?: string;
    /**
    * Optional description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#description PathpointFlow#description}
    */
    readonly description?: string;
    /**
    * Display name of the KPI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#name PathpointFlow#name}
    */
    readonly name: string;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#query PathpointFlow#query}
    */
    readonly query: PathpointFlowKpisQuery;
}
export declare function pathpointFlowKpisToTerraform(struct?: PathpointFlowKpis | cdktn.IResolvable): any;
export declare function pathpointFlowKpisToHclTerraform(struct?: PathpointFlowKpis | cdktn.IResolvable): any;
export declare class PathpointFlowKpisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PathpointFlowKpis | cdktn.IResolvable | undefined;
    set internalValue(value: PathpointFlowKpis | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get metricQuery(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query;
    get query(): PathpointFlowKpisQueryOutputReference;
    putQuery(value: PathpointFlowKpisQuery): void;
    get queryInput(): PathpointFlowKpisQuery | undefined;
}
export declare class PathpointFlowKpisList extends cdktn.ComplexList {
    internalValue?: PathpointFlowKpis[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PathpointFlowKpisOutputReference;
}
export interface PathpointFlowStagesLevelsStepsConfig {
    /**
    * How step health is rolled up: BEST_STATUS_WINS or WORST_STATUS_WINS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#health_rollup PathpointFlow#health_rollup}
    */
    readonly healthRollup?: string;
    /**
    * Whether threshold is FIXED or PERCENTAGE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#threshold_type PathpointFlow#threshold_type}
    */
    readonly thresholdType?: string;
    /**
    * Numeric threshold value for step health evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#threshold_value PathpointFlow#threshold_value}
    */
    readonly thresholdValue?: number;
}
export declare function pathpointFlowStagesLevelsStepsConfigToTerraform(struct?: PathpointFlowStagesLevelsStepsConfigOutputReference | PathpointFlowStagesLevelsStepsConfig): any;
export declare function pathpointFlowStagesLevelsStepsConfigToHclTerraform(struct?: PathpointFlowStagesLevelsStepsConfigOutputReference | PathpointFlowStagesLevelsStepsConfig): any;
export declare class PathpointFlowStagesLevelsStepsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowStagesLevelsStepsConfig | undefined;
    set internalValue(value: PathpointFlowStagesLevelsStepsConfig | undefined);
    private _healthRollup?;
    get healthRollup(): string;
    set healthRollup(value: string);
    resetHealthRollup(): void;
    get healthRollupInput(): string | undefined;
    private _thresholdType?;
    get thresholdType(): string;
    set thresholdType(value: string);
    resetThresholdType(): void;
    get thresholdTypeInput(): string | undefined;
    private _thresholdValue?;
    get thresholdValue(): number;
    set thresholdValue(value: number);
    resetThresholdValue(): void;
    get thresholdValueInput(): number | undefined;
}
export interface PathpointFlowStagesLevelsStepsEntitySearchQuery {
    /**
    * When true, this query is excluded from health calculation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#is_excluded PathpointFlow#is_excluded}
    */
    readonly isExcluded?: boolean | cdktn.IResolvable;
    /**
    * Filter query for signals, e.g. domain='NR1' AND type='APPLICATION'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#query PathpointFlow#query}
    */
    readonly query: string;
}
export declare function pathpointFlowStagesLevelsStepsEntitySearchQueryToTerraform(struct?: PathpointFlowStagesLevelsStepsEntitySearchQueryOutputReference | PathpointFlowStagesLevelsStepsEntitySearchQuery): any;
export declare function pathpointFlowStagesLevelsStepsEntitySearchQueryToHclTerraform(struct?: PathpointFlowStagesLevelsStepsEntitySearchQueryOutputReference | PathpointFlowStagesLevelsStepsEntitySearchQuery): any;
export declare class PathpointFlowStagesLevelsStepsEntitySearchQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowStagesLevelsStepsEntitySearchQuery | undefined;
    set internalValue(value: PathpointFlowStagesLevelsStepsEntitySearchQuery | undefined);
    private _isExcluded?;
    get isExcluded(): boolean | cdktn.IResolvable;
    set isExcluded(value: boolean | cdktn.IResolvable);
    resetIsExcluded(): void;
    get isExcludedInput(): boolean | cdktn.IResolvable | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PathpointFlowStagesLevelsStepsSignals {
    /**
    * Entity GUID of the signal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#guid PathpointFlow#guid}
    */
    readonly guid: string;
    /**
    * When true, this signal is excluded from step health calculation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#is_excluded PathpointFlow#is_excluded}
    */
    readonly isExcluded?: boolean | cdktn.IResolvable;
    /**
    * Display name of the signal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#name PathpointFlow#name}
    */
    readonly name?: string;
    /**
    * Whether this GUID belongs to an entity or an alert condition: ENTITY or ALERT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#type PathpointFlow#type}
    */
    readonly type?: string;
}
export declare function pathpointFlowStagesLevelsStepsSignalsToTerraform(struct?: PathpointFlowStagesLevelsStepsSignals | cdktn.IResolvable): any;
export declare function pathpointFlowStagesLevelsStepsSignalsToHclTerraform(struct?: PathpointFlowStagesLevelsStepsSignals | cdktn.IResolvable): any;
export declare class PathpointFlowStagesLevelsStepsSignalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PathpointFlowStagesLevelsStepsSignals | cdktn.IResolvable | undefined;
    set internalValue(value: PathpointFlowStagesLevelsStepsSignals | cdktn.IResolvable | undefined);
    private _guid?;
    get guid(): string;
    set guid(value: string);
    get guidInput(): string | undefined;
    private _isExcluded?;
    get isExcluded(): boolean | cdktn.IResolvable;
    set isExcluded(value: boolean | cdktn.IResolvable);
    resetIsExcluded(): void;
    get isExcludedInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class PathpointFlowStagesLevelsStepsSignalsList extends cdktn.ComplexList {
    internalValue?: PathpointFlowStagesLevelsStepsSignals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PathpointFlowStagesLevelsStepsSignalsOutputReference;
}
export interface PathpointFlowStagesLevelsSteps {
    /**
    * When true, this step is excluded from level health calculation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#is_excluded PathpointFlow#is_excluded}
    */
    readonly isExcluded?: boolean | cdktn.IResolvable;
    /**
    * Optional URL to an external resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#link PathpointFlow#link}
    */
    readonly link?: string;
    /**
    * Display name of the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#name PathpointFlow#name}
    */
    readonly name: string;
    /**
    * Account IDs whose data is scoped to this step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#scoped_accounts PathpointFlow#scoped_accounts}
    */
    readonly scopedAccounts?: number[];
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#config PathpointFlow#config}
    */
    readonly config?: PathpointFlowStagesLevelsStepsConfig;
    /**
    * entity_search_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#entity_search_query PathpointFlow#entity_search_query}
    */
    readonly entitySearchQuery?: PathpointFlowStagesLevelsStepsEntitySearchQuery;
    /**
    * signals block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#signals PathpointFlow#signals}
    */
    readonly signals?: PathpointFlowStagesLevelsStepsSignals[] | cdktn.IResolvable;
}
export declare function pathpointFlowStagesLevelsStepsToTerraform(struct?: PathpointFlowStagesLevelsSteps | cdktn.IResolvable): any;
export declare function pathpointFlowStagesLevelsStepsToHclTerraform(struct?: PathpointFlowStagesLevelsSteps | cdktn.IResolvable): any;
export declare class PathpointFlowStagesLevelsStepsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PathpointFlowStagesLevelsSteps | cdktn.IResolvable | undefined;
    set internalValue(value: PathpointFlowStagesLevelsSteps | cdktn.IResolvable | undefined);
    get id(): string;
    private _isExcluded?;
    get isExcluded(): boolean | cdktn.IResolvable;
    set isExcluded(value: boolean | cdktn.IResolvable);
    resetIsExcluded(): void;
    get isExcludedInput(): boolean | cdktn.IResolvable | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _scopedAccounts?;
    get scopedAccounts(): number[];
    set scopedAccounts(value: number[]);
    resetScopedAccounts(): void;
    get scopedAccountsInput(): number[] | undefined;
    private _config;
    get config(): PathpointFlowStagesLevelsStepsConfigOutputReference;
    putConfig(value: PathpointFlowStagesLevelsStepsConfig): void;
    resetConfig(): void;
    get configInput(): PathpointFlowStagesLevelsStepsConfig | undefined;
    private _entitySearchQuery;
    get entitySearchQuery(): PathpointFlowStagesLevelsStepsEntitySearchQueryOutputReference;
    putEntitySearchQuery(value: PathpointFlowStagesLevelsStepsEntitySearchQuery): void;
    resetEntitySearchQuery(): void;
    get entitySearchQueryInput(): PathpointFlowStagesLevelsStepsEntitySearchQuery | undefined;
    private _signals;
    get signals(): PathpointFlowStagesLevelsStepsSignalsList;
    putSignals(value: PathpointFlowStagesLevelsStepsSignals[] | cdktn.IResolvable): void;
    resetSignals(): void;
    get signalsInput(): cdktn.IResolvable | PathpointFlowStagesLevelsStepsSignals[] | undefined;
}
export declare class PathpointFlowStagesLevelsStepsList extends cdktn.ComplexList {
    internalValue?: PathpointFlowStagesLevelsSteps[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PathpointFlowStagesLevelsStepsOutputReference;
}
export interface PathpointFlowStagesLevels {
    /**
    * steps block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#steps PathpointFlow#steps}
    */
    readonly steps?: PathpointFlowStagesLevelsSteps[] | cdktn.IResolvable;
}
export declare function pathpointFlowStagesLevelsToTerraform(struct?: PathpointFlowStagesLevels | cdktn.IResolvable): any;
export declare function pathpointFlowStagesLevelsToHclTerraform(struct?: PathpointFlowStagesLevels | cdktn.IResolvable): any;
export declare class PathpointFlowStagesLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PathpointFlowStagesLevels | cdktn.IResolvable | undefined;
    set internalValue(value: PathpointFlowStagesLevels | cdktn.IResolvable | undefined);
    get id(): string;
    private _steps;
    get steps(): PathpointFlowStagesLevelsStepsList;
    putSteps(value: PathpointFlowStagesLevelsSteps[] | cdktn.IResolvable): void;
    resetSteps(): void;
    get stepsInput(): cdktn.IResolvable | PathpointFlowStagesLevelsSteps[] | undefined;
}
export declare class PathpointFlowStagesLevelsList extends cdktn.ComplexList {
    internalValue?: PathpointFlowStagesLevels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PathpointFlowStagesLevelsOutputReference;
}
export interface PathpointFlowStagesRelated {
    /**
    * When true, this stage acts as a source to other stages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#source PathpointFlow#source}
    */
    readonly source?: boolean | cdktn.IResolvable;
    /**
    * When true, this stage acts as a target to other stages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#target PathpointFlow#target}
    */
    readonly target?: boolean | cdktn.IResolvable;
}
export declare function pathpointFlowStagesRelatedToTerraform(struct?: PathpointFlowStagesRelatedOutputReference | PathpointFlowStagesRelated): any;
export declare function pathpointFlowStagesRelatedToHclTerraform(struct?: PathpointFlowStagesRelatedOutputReference | PathpointFlowStagesRelated): any;
export declare class PathpointFlowStagesRelatedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowStagesRelated | undefined;
    set internalValue(value: PathpointFlowStagesRelated | undefined);
    private _source?;
    get source(): boolean | cdktn.IResolvable;
    set source(value: boolean | cdktn.IResolvable);
    resetSource(): void;
    get sourceInput(): boolean | cdktn.IResolvable | undefined;
    private _target?;
    get target(): boolean | cdktn.IResolvable;
    set target(value: boolean | cdktn.IResolvable);
    resetTarget(): void;
    get targetInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PathpointFlowStagesStageKpisQuerySelect {
    /**
    * Aggregation function: AVERAGE, COUNT, HISTOGRAM, MAX, MIN, PERCENTILE, SUM, UNIQUE_COUNT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#aggregation_type PathpointFlow#aggregation_type}
    */
    readonly aggregationType: string;
    /**
    * Optional alias for the aggregated value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#alias PathpointFlow#alias}
    */
    readonly alias?: string;
    /**
    * Attribute name to aggregate. Required for all functions except COUNT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#attribute PathpointFlow#attribute}
    */
    readonly attribute?: string;
    /**
    * Threshold used in the selected function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#threshold PathpointFlow#threshold}
    */
    readonly threshold?: number;
}
export declare function pathpointFlowStagesStageKpisQuerySelectToTerraform(struct?: PathpointFlowStagesStageKpisQuerySelectOutputReference | PathpointFlowStagesStageKpisQuerySelect): any;
export declare function pathpointFlowStagesStageKpisQuerySelectToHclTerraform(struct?: PathpointFlowStagesStageKpisQuerySelectOutputReference | PathpointFlowStagesStageKpisQuerySelect): any;
export declare class PathpointFlowStagesStageKpisQuerySelectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowStagesStageKpisQuerySelect | undefined;
    set internalValue(value: PathpointFlowStagesStageKpisQuerySelect | undefined);
    private _aggregationType?;
    get aggregationType(): string;
    set aggregationType(value: string);
    get aggregationTypeInput(): string | undefined;
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
}
export interface PathpointFlowStagesStageKpisQueryTimeWindowRelativeRange {
    /**
    * The earlier window to compare against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#compare_against PathpointFlow#compare_against}
    */
    readonly compareAgainst?: string;
    /**
    * How far back the KPI is evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#since PathpointFlow#since}
    */
    readonly since: string;
}
export declare function pathpointFlowStagesStageKpisQueryTimeWindowRelativeRangeToTerraform(struct?: PathpointFlowStagesStageKpisQueryTimeWindowRelativeRangeOutputReference | PathpointFlowStagesStageKpisQueryTimeWindowRelativeRange): any;
export declare function pathpointFlowStagesStageKpisQueryTimeWindowRelativeRangeToHclTerraform(struct?: PathpointFlowStagesStageKpisQueryTimeWindowRelativeRangeOutputReference | PathpointFlowStagesStageKpisQueryTimeWindowRelativeRange): any;
export declare class PathpointFlowStagesStageKpisQueryTimeWindowRelativeRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowStagesStageKpisQueryTimeWindowRelativeRange | undefined;
    set internalValue(value: PathpointFlowStagesStageKpisQueryTimeWindowRelativeRange | undefined);
    private _compareAgainst?;
    get compareAgainst(): string;
    set compareAgainst(value: string);
    resetCompareAgainst(): void;
    get compareAgainstInput(): string | undefined;
    private _since?;
    get since(): string;
    set since(value: string);
    get sinceInput(): string | undefined;
}
export interface PathpointFlowStagesStageKpisQueryTimeWindow {
    /**
    * Raw NRQL time fragment, e.g. 'SINCE 3 days ago COMPARE WITH 1 day ago'. Mutually exclusive with relative_range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#custom_range PathpointFlow#custom_range}
    */
    readonly customRange?: string;
    /**
    * relative_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#relative_range PathpointFlow#relative_range}
    */
    readonly relativeRange?: PathpointFlowStagesStageKpisQueryTimeWindowRelativeRange;
}
export declare function pathpointFlowStagesStageKpisQueryTimeWindowToTerraform(struct?: PathpointFlowStagesStageKpisQueryTimeWindowOutputReference | PathpointFlowStagesStageKpisQueryTimeWindow): any;
export declare function pathpointFlowStagesStageKpisQueryTimeWindowToHclTerraform(struct?: PathpointFlowStagesStageKpisQueryTimeWindowOutputReference | PathpointFlowStagesStageKpisQueryTimeWindow): any;
export declare class PathpointFlowStagesStageKpisQueryTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowStagesStageKpisQueryTimeWindow | undefined;
    set internalValue(value: PathpointFlowStagesStageKpisQueryTimeWindow | undefined);
    private _customRange?;
    get customRange(): string;
    set customRange(value: string);
    resetCustomRange(): void;
    get customRangeInput(): string | undefined;
    private _relativeRange;
    get relativeRange(): PathpointFlowStagesStageKpisQueryTimeWindowRelativeRangeOutputReference;
    putRelativeRange(value: PathpointFlowStagesStageKpisQueryTimeWindowRelativeRange): void;
    resetRelativeRange(): void;
    get relativeRangeInput(): PathpointFlowStagesStageKpisQueryTimeWindowRelativeRange | undefined;
}
export interface PathpointFlowStagesStageKpisQuery {
    /**
    * Data source to query from (e.g., Transaction, Metric, Log).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#from PathpointFlow#from}
    */
    readonly from: string;
    /**
    * Optional WHERE clause to filter data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#where PathpointFlow#where}
    */
    readonly where?: string;
    /**
    * select block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#select PathpointFlow#select}
    */
    readonly select: PathpointFlowStagesStageKpisQuerySelect;
    /**
    * time_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#time_window PathpointFlow#time_window}
    */
    readonly timeWindow?: PathpointFlowStagesStageKpisQueryTimeWindow;
}
export declare function pathpointFlowStagesStageKpisQueryToTerraform(struct?: PathpointFlowStagesStageKpisQueryOutputReference | PathpointFlowStagesStageKpisQuery): any;
export declare function pathpointFlowStagesStageKpisQueryToHclTerraform(struct?: PathpointFlowStagesStageKpisQueryOutputReference | PathpointFlowStagesStageKpisQuery): any;
export declare class PathpointFlowStagesStageKpisQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PathpointFlowStagesStageKpisQuery | undefined;
    set internalValue(value: PathpointFlowStagesStageKpisQuery | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    get fromInput(): string | undefined;
    private _where?;
    get where(): string;
    set where(value: string);
    resetWhere(): void;
    get whereInput(): string | undefined;
    private _select;
    get select(): PathpointFlowStagesStageKpisQuerySelectOutputReference;
    putSelect(value: PathpointFlowStagesStageKpisQuerySelect): void;
    get selectInput(): PathpointFlowStagesStageKpisQuerySelect | undefined;
    private _timeWindow;
    get timeWindow(): PathpointFlowStagesStageKpisQueryTimeWindowOutputReference;
    putTimeWindow(value: PathpointFlowStagesStageKpisQueryTimeWindow): void;
    resetTimeWindow(): void;
    get timeWindowInput(): PathpointFlowStagesStageKpisQueryTimeWindow | undefined;
}
export interface PathpointFlowStagesStageKpis {
    /**
    * Account ID this KPI belongs to. Defaults to the flow's account_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#account_id PathpointFlow#account_id}
    */
    readonly accountId?: number;
    /**
    * Optional category to group KPIs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#category PathpointFlow#category}
    */
    readonly category?: string;
    /**
    * Optional description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#description PathpointFlow#description}
    */
    readonly description?: string;
    /**
    * Display name of the KPI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#name PathpointFlow#name}
    */
    readonly name: string;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#query PathpointFlow#query}
    */
    readonly query: PathpointFlowStagesStageKpisQuery;
}
export declare function pathpointFlowStagesStageKpisToTerraform(struct?: PathpointFlowStagesStageKpis | cdktn.IResolvable): any;
export declare function pathpointFlowStagesStageKpisToHclTerraform(struct?: PathpointFlowStagesStageKpis | cdktn.IResolvable): any;
export declare class PathpointFlowStagesStageKpisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PathpointFlowStagesStageKpis | cdktn.IResolvable | undefined;
    set internalValue(value: PathpointFlowStagesStageKpis | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get metricQuery(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query;
    get query(): PathpointFlowStagesStageKpisQueryOutputReference;
    putQuery(value: PathpointFlowStagesStageKpisQuery): void;
    get queryInput(): PathpointFlowStagesStageKpisQuery | undefined;
}
export declare class PathpointFlowStagesStageKpisList extends cdktn.ComplexList {
    internalValue?: PathpointFlowStagesStageKpis[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PathpointFlowStagesStageKpisOutputReference;
}
export interface PathpointFlowStages {
    /**
    * Health rollup strategy: ALERT_CONDITIONS or AUTOMATIC_ROLL_UP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#health_rollup PathpointFlow#health_rollup}
    */
    readonly healthRollup?: string;
    /**
    * When true, this stage is excluded from flow health calculation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#is_excluded PathpointFlow#is_excluded}
    */
    readonly isExcluded?: boolean | cdktn.IResolvable;
    /**
    * Optional URL to an external resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#link PathpointFlow#link}
    */
    readonly link?: string;
    /**
    * Display name of the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#name PathpointFlow#name}
    */
    readonly name: string;
    /**
    * levels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#levels PathpointFlow#levels}
    */
    readonly levels?: PathpointFlowStagesLevels[] | cdktn.IResolvable;
    /**
    * related block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#related PathpointFlow#related}
    */
    readonly related?: PathpointFlowStagesRelated;
    /**
    * stage_kpis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#stage_kpis PathpointFlow#stage_kpis}
    */
    readonly stageKpis?: PathpointFlowStagesStageKpis[] | cdktn.IResolvable;
}
export declare function pathpointFlowStagesToTerraform(struct?: PathpointFlowStages | cdktn.IResolvable): any;
export declare function pathpointFlowStagesToHclTerraform(struct?: PathpointFlowStages | cdktn.IResolvable): any;
export declare class PathpointFlowStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PathpointFlowStages | cdktn.IResolvable | undefined;
    set internalValue(value: PathpointFlowStages | cdktn.IResolvable | undefined);
    private _healthRollup?;
    get healthRollup(): string;
    set healthRollup(value: string);
    resetHealthRollup(): void;
    get healthRollupInput(): string | undefined;
    get id(): string;
    private _isExcluded?;
    get isExcluded(): boolean | cdktn.IResolvable;
    set isExcluded(value: boolean | cdktn.IResolvable);
    resetIsExcluded(): void;
    get isExcludedInput(): boolean | cdktn.IResolvable | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _levels;
    get levels(): PathpointFlowStagesLevelsList;
    putLevels(value: PathpointFlowStagesLevels[] | cdktn.IResolvable): void;
    resetLevels(): void;
    get levelsInput(): cdktn.IResolvable | PathpointFlowStagesLevels[] | undefined;
    private _related;
    get related(): PathpointFlowStagesRelatedOutputReference;
    putRelated(value: PathpointFlowStagesRelated): void;
    resetRelated(): void;
    get relatedInput(): PathpointFlowStagesRelated | undefined;
    private _stageKpis;
    get stageKpis(): PathpointFlowStagesStageKpisList;
    putStageKpis(value: PathpointFlowStagesStageKpis[] | cdktn.IResolvable): void;
    resetStageKpis(): void;
    get stageKpisInput(): cdktn.IResolvable | PathpointFlowStagesStageKpis[] | undefined;
}
export declare class PathpointFlowStagesList extends cdktn.ComplexList {
    internalValue?: PathpointFlowStages[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PathpointFlowStagesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow newrelic_pathpoint_flow}
*/
export declare class PathpointFlow extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_pathpoint_flow";
    /**
    * Generates CDKTN code for importing a PathpointFlow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PathpointFlow to import
    * @param importFromId The id of the existing PathpointFlow that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PathpointFlow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/pathpoint_flow newrelic_pathpoint_flow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PathpointFlowConfig
    */
    constructor(scope: Construct, id: string, config: PathpointFlowConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get guid(): string;
    private _healthRollup?;
    get healthRollup(): string;
    set healthRollup(value: string);
    resetHealthRollup(): void;
    get healthRollupInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _refreshInterval?;
    get refreshInterval(): string;
    set refreshInterval(value: string);
    resetRefreshInterval(): void;
    get refreshIntervalInput(): string | undefined;
    get version(): string;
    private _kpis;
    get kpis(): PathpointFlowKpisList;
    putKpis(value: PathpointFlowKpis[] | cdktn.IResolvable): void;
    resetKpis(): void;
    get kpisInput(): cdktn.IResolvable | PathpointFlowKpis[] | undefined;
    private _stages;
    get stages(): PathpointFlowStagesList;
    putStages(value: PathpointFlowStages[] | cdktn.IResolvable): void;
    resetStages(): void;
    get stagesInput(): cdktn.IResolvable | PathpointFlowStages[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
