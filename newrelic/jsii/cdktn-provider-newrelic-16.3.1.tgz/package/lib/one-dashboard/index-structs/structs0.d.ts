/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface OneDashboardPageWidgetAreaChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetAreaChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetAreaChartStylesGradientOutputReference | OneDashboardPageWidgetAreaChartStylesGradient): any;
export declare function oneDashboardPageWidgetAreaChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetAreaChartStylesGradientOutputReference | OneDashboardPageWidgetAreaChartStylesGradient): any;
export declare class OneDashboardPageWidgetAreaChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetAreaChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetAreaChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetAreaChartStylesGradient;
}
export declare function oneDashboardPageWidgetAreaChartStylesToTerraform(struct?: OneDashboardPageWidgetAreaChartStylesOutputReference | OneDashboardPageWidgetAreaChartStyles): any;
export declare function oneDashboardPageWidgetAreaChartStylesToHclTerraform(struct?: OneDashboardPageWidgetAreaChartStylesOutputReference | OneDashboardPageWidgetAreaChartStyles): any;
export declare class OneDashboardPageWidgetAreaChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetAreaChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetAreaChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetAreaChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetAreaChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetAreaColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetAreaColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetAreaColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetAreaColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetAreaColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetAreaColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetAreaColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetAreaColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetAreaColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetAreaColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetAreaColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetAreaColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetAreaColorsToTerraform(struct?: OneDashboardPageWidgetAreaColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetAreaColorsToHclTerraform(struct?: OneDashboardPageWidgetAreaColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetAreaColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetAreaColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetAreaColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetAreaColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetAreaColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetAreaColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetAreaColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetAreaColorsOutputReference;
}
export interface OneDashboardPageWidgetAreaDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetAreaDataFormatToTerraform(struct?: OneDashboardPageWidgetAreaDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetAreaDataFormatToHclTerraform(struct?: OneDashboardPageWidgetAreaDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetAreaDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetAreaDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetAreaDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetAreaDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetAreaDataFormatOutputReference;
}
export interface OneDashboardPageWidgetAreaInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetAreaInitialSortingToTerraform(struct?: OneDashboardPageWidgetAreaInitialSortingOutputReference | OneDashboardPageWidgetAreaInitialSorting): any;
export declare function oneDashboardPageWidgetAreaInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetAreaInitialSortingOutputReference | OneDashboardPageWidgetAreaInitialSorting): any;
export declare class OneDashboardPageWidgetAreaInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetAreaInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetAreaNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetAreaNrqlQueryToTerraform(struct?: OneDashboardPageWidgetAreaNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetAreaNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetAreaNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetAreaNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetAreaNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetAreaNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetAreaNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetAreaNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetAreaNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetAreaNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetAreaNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetAreaNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetAreaNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetAreaNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetAreaNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetAreaNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetAreaNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetAreaNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetAreaNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetAreaNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetAreaNullValuesToTerraform(struct?: OneDashboardPageWidgetAreaNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetAreaNullValuesToHclTerraform(struct?: OneDashboardPageWidgetAreaNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetAreaNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetAreaNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetAreaNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetAreaNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetAreaNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetAreaNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetAreaNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetAreaNullValuesOutputReference;
}
export interface OneDashboardPageWidgetAreaTooltip {
    /**
    * Tooltip display mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#mode OneDashboard#mode}
    */
    readonly mode: string;
}
export declare function oneDashboardPageWidgetAreaTooltipToTerraform(struct?: OneDashboardPageWidgetAreaTooltipOutputReference | OneDashboardPageWidgetAreaTooltip): any;
export declare function oneDashboardPageWidgetAreaTooltipToHclTerraform(struct?: OneDashboardPageWidgetAreaTooltipOutputReference | OneDashboardPageWidgetAreaTooltip): any;
export declare class OneDashboardPageWidgetAreaTooltipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetAreaTooltip | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaTooltip | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export interface OneDashboardPageWidgetAreaUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetAreaUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetAreaUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetAreaUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetAreaUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetAreaUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetAreaUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetAreaUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetAreaUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetAreaUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetAreaUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetAreaUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetAreaUnitsToTerraform(struct?: OneDashboardPageWidgetAreaUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetAreaUnitsToHclTerraform(struct?: OneDashboardPageWidgetAreaUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetAreaUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetAreaUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetAreaUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetAreaUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetAreaUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetAreaUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetAreaUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetAreaUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetAreaUnitsOutputReference;
}
export interface OneDashboardPageWidgetArea {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetAreaChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetAreaColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetAreaDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetAreaInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetAreaNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetAreaNullValues[] | cdktn.IResolvable;
    /**
    * tooltip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#tooltip OneDashboard#tooltip}
    */
    readonly tooltip?: OneDashboardPageWidgetAreaTooltip;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetAreaUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetAreaToTerraform(struct?: OneDashboardPageWidgetArea | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetAreaToHclTerraform(struct?: OneDashboardPageWidgetArea | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetAreaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetArea | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetArea | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetAreaChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetAreaChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetAreaChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetAreaColorsList;
    putColors(value: OneDashboardPageWidgetAreaColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetAreaColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetAreaDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetAreaDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetAreaDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetAreaInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetAreaInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetAreaInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetAreaNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetAreaNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetAreaNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetAreaNullValuesList;
    putNullValues(value: OneDashboardPageWidgetAreaNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetAreaNullValues[] | undefined;
    private _tooltip;
    get tooltip(): OneDashboardPageWidgetAreaTooltipOutputReference;
    putTooltip(value: OneDashboardPageWidgetAreaTooltip): void;
    resetTooltip(): void;
    get tooltipInput(): OneDashboardPageWidgetAreaTooltip | undefined;
    private _units;
    get units(): OneDashboardPageWidgetAreaUnitsList;
    putUnits(value: OneDashboardPageWidgetAreaUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetAreaUnits[] | undefined;
}
export declare class OneDashboardPageWidgetAreaList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetArea[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetAreaOutputReference;
}
export interface OneDashboardPageWidgetBarChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBarChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetBarChartStylesGradientOutputReference | OneDashboardPageWidgetBarChartStylesGradient): any;
export declare function oneDashboardPageWidgetBarChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetBarChartStylesGradientOutputReference | OneDashboardPageWidgetBarChartStylesGradient): any;
export declare class OneDashboardPageWidgetBarChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBarChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetBarChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetBarChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetBarChartStylesGradient;
}
export declare function oneDashboardPageWidgetBarChartStylesToTerraform(struct?: OneDashboardPageWidgetBarChartStylesOutputReference | OneDashboardPageWidgetBarChartStyles): any;
export declare function oneDashboardPageWidgetBarChartStylesToHclTerraform(struct?: OneDashboardPageWidgetBarChartStylesOutputReference | OneDashboardPageWidgetBarChartStyles): any;
export declare class OneDashboardPageWidgetBarChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBarChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetBarChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetBarChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetBarChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetBarChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetBarColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetBarColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetBarColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBarColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetBarColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBarColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBarColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBarColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBarColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBarColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBarColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetBarColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetBarColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBarColorsToTerraform(struct?: OneDashboardPageWidgetBarColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBarColorsToHclTerraform(struct?: OneDashboardPageWidgetBarColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBarColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBarColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBarColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetBarColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetBarColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetBarColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetBarColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBarColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBarColorsOutputReference;
}
export interface OneDashboardPageWidgetBarDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetBarDataFormatToTerraform(struct?: OneDashboardPageWidgetBarDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBarDataFormatToHclTerraform(struct?: OneDashboardPageWidgetBarDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBarDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBarDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBarDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBarDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBarDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBarDataFormatOutputReference;
}
export interface OneDashboardPageWidgetBarInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetBarInitialSortingToTerraform(struct?: OneDashboardPageWidgetBarInitialSortingOutputReference | OneDashboardPageWidgetBarInitialSorting): any;
export declare function oneDashboardPageWidgetBarInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetBarInitialSortingOutputReference | OneDashboardPageWidgetBarInitialSorting): any;
export declare class OneDashboardPageWidgetBarInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBarInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetBarInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetBarNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetBarNrqlQueryToTerraform(struct?: OneDashboardPageWidgetBarNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBarNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetBarNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBarNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBarNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBarNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBarNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBarNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBarNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetBarNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetBarNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetBarNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBarNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetBarNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBarNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBarNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBarNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBarNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBarNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBarNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetBarNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetBarNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBarNullValuesToTerraform(struct?: OneDashboardPageWidgetBarNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBarNullValuesToHclTerraform(struct?: OneDashboardPageWidgetBarNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBarNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBarNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBarNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetBarNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetBarNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetBarNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetBarNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBarNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBarNullValuesOutputReference;
}
export interface OneDashboardPageWidgetBarUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetBarUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetBarUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBarUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetBarUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBarUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBarUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBarUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBarUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBarUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBarUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetBarUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetBarUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBarUnitsToTerraform(struct?: OneDashboardPageWidgetBarUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBarUnitsToHclTerraform(struct?: OneDashboardPageWidgetBarUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBarUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBarUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBarUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetBarUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetBarUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetBarUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetBarUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBarUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBarUnitsOutputReference;
}
export interface OneDashboardPageWidgetBar {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Use this item to filter the current dashboard
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#filter_current_dashboard OneDashboard#filter_current_dashboard}
    */
    readonly filterCurrentDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Related entities. Currently only supports Dashboard entities, but may allow other cases in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#linked_entity_guids OneDashboard#linked_entity_guids}
    */
    readonly linkedEntityGuids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetBarChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetBarColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetBarDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetBarInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetBarNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetBarNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetBarUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBarToTerraform(struct?: OneDashboardPageWidgetBar | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBarToHclTerraform(struct?: OneDashboardPageWidgetBar | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBarOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBar | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBar | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _filterCurrentDashboard?;
    get filterCurrentDashboard(): boolean | cdktn.IResolvable;
    set filterCurrentDashboard(value: boolean | cdktn.IResolvable);
    resetFilterCurrentDashboard(): void;
    get filterCurrentDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _linkedEntityGuids?;
    get linkedEntityGuids(): string[];
    set linkedEntityGuids(value: string[]);
    resetLinkedEntityGuids(): void;
    get linkedEntityGuidsInput(): string[] | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetBarChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetBarChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetBarChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetBarColorsList;
    putColors(value: OneDashboardPageWidgetBarColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetBarColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetBarDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetBarDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetBarDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetBarInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetBarInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetBarInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetBarNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetBarNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetBarNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetBarNullValuesList;
    putNullValues(value: OneDashboardPageWidgetBarNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetBarNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetBarUnitsList;
    putUnits(value: OneDashboardPageWidgetBarUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetBarUnits[] | undefined;
}
export declare class OneDashboardPageWidgetBarList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBar[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBarOutputReference;
}
export interface OneDashboardPageWidgetBillboardBillboardSettingsGridOptions {
    /**
    * Number of columns in the grid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#columns OneDashboard#columns}
    */
    readonly columns?: number;
    /**
    * Grid label setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#label OneDashboard#label}
    */
    readonly label?: number;
    /**
    * Grid value setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#value OneDashboard#value}
    */
    readonly value?: number;
}
export declare function oneDashboardPageWidgetBillboardBillboardSettingsGridOptionsToTerraform(struct?: OneDashboardPageWidgetBillboardBillboardSettingsGridOptionsOutputReference | OneDashboardPageWidgetBillboardBillboardSettingsGridOptions): any;
export declare function oneDashboardPageWidgetBillboardBillboardSettingsGridOptionsToHclTerraform(struct?: OneDashboardPageWidgetBillboardBillboardSettingsGridOptionsOutputReference | OneDashboardPageWidgetBillboardBillboardSettingsGridOptions): any;
export declare class OneDashboardPageWidgetBillboardBillboardSettingsGridOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBillboardBillboardSettingsGridOptions | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardBillboardSettingsGridOptions | undefined);
    private _columns?;
    get columns(): number;
    set columns(value: number);
    resetColumns(): void;
    get columnsInput(): number | undefined;
    private _label?;
    get label(): number;
    set label(value: number);
    resetLabel(): void;
    get labelInput(): number | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface OneDashboardPageWidgetBillboardBillboardSettingsLink {
    /**
    * Whether to open the link in a new tab.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#new_tab OneDashboard#new_tab}
    */
    readonly newTab?: boolean | cdktn.IResolvable;
    /**
    * The title for the link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title?: string;
    /**
    * The URL for the link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#url OneDashboard#url}
    */
    readonly url?: string;
}
export declare function oneDashboardPageWidgetBillboardBillboardSettingsLinkToTerraform(struct?: OneDashboardPageWidgetBillboardBillboardSettingsLinkOutputReference | OneDashboardPageWidgetBillboardBillboardSettingsLink): any;
export declare function oneDashboardPageWidgetBillboardBillboardSettingsLinkToHclTerraform(struct?: OneDashboardPageWidgetBillboardBillboardSettingsLinkOutputReference | OneDashboardPageWidgetBillboardBillboardSettingsLink): any;
export declare class OneDashboardPageWidgetBillboardBillboardSettingsLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBillboardBillboardSettingsLink | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardBillboardSettingsLink | undefined);
    private _newTab?;
    get newTab(): boolean | cdktn.IResolvable;
    set newTab(value: boolean | cdktn.IResolvable);
    resetNewTab(): void;
    get newTabInput(): boolean | cdktn.IResolvable | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface OneDashboardPageWidgetBillboardBillboardSettingsVisual {
    /**
    * Billboard alignment type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#alignment OneDashboard#alignment}
    */
    readonly alignment?: string;
    /**
    * Billboard display type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#display OneDashboard#display}
    */
    readonly display?: string;
}
export declare function oneDashboardPageWidgetBillboardBillboardSettingsVisualToTerraform(struct?: OneDashboardPageWidgetBillboardBillboardSettingsVisualOutputReference | OneDashboardPageWidgetBillboardBillboardSettingsVisual): any;
export declare function oneDashboardPageWidgetBillboardBillboardSettingsVisualToHclTerraform(struct?: OneDashboardPageWidgetBillboardBillboardSettingsVisualOutputReference | OneDashboardPageWidgetBillboardBillboardSettingsVisual): any;
export declare class OneDashboardPageWidgetBillboardBillboardSettingsVisualOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBillboardBillboardSettingsVisual | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardBillboardSettingsVisual | undefined);
    private _alignment?;
    get alignment(): string;
    set alignment(value: string);
    resetAlignment(): void;
    get alignmentInput(): string | undefined;
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
}
export interface OneDashboardPageWidgetBillboardBillboardSettings {
    /**
    * grid_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#grid_options OneDashboard#grid_options}
    */
    readonly gridOptions?: OneDashboardPageWidgetBillboardBillboardSettingsGridOptions;
    /**
    * link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#link OneDashboard#link}
    */
    readonly link?: OneDashboardPageWidgetBillboardBillboardSettingsLink;
    /**
    * visual block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#visual OneDashboard#visual}
    */
    readonly visual?: OneDashboardPageWidgetBillboardBillboardSettingsVisual;
}
export declare function oneDashboardPageWidgetBillboardBillboardSettingsToTerraform(struct?: OneDashboardPageWidgetBillboardBillboardSettingsOutputReference | OneDashboardPageWidgetBillboardBillboardSettings): any;
export declare function oneDashboardPageWidgetBillboardBillboardSettingsToHclTerraform(struct?: OneDashboardPageWidgetBillboardBillboardSettingsOutputReference | OneDashboardPageWidgetBillboardBillboardSettings): any;
export declare class OneDashboardPageWidgetBillboardBillboardSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBillboardBillboardSettings | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardBillboardSettings | undefined);
    private _gridOptions;
    get gridOptions(): OneDashboardPageWidgetBillboardBillboardSettingsGridOptionsOutputReference;
    putGridOptions(value: OneDashboardPageWidgetBillboardBillboardSettingsGridOptions): void;
    resetGridOptions(): void;
    get gridOptionsInput(): OneDashboardPageWidgetBillboardBillboardSettingsGridOptions | undefined;
    private _link;
    get link(): OneDashboardPageWidgetBillboardBillboardSettingsLinkOutputReference;
    putLink(value: OneDashboardPageWidgetBillboardBillboardSettingsLink): void;
    resetLink(): void;
    get linkInput(): OneDashboardPageWidgetBillboardBillboardSettingsLink | undefined;
    private _visual;
    get visual(): OneDashboardPageWidgetBillboardBillboardSettingsVisualOutputReference;
    putVisual(value: OneDashboardPageWidgetBillboardBillboardSettingsVisual): void;
    resetVisual(): void;
    get visualInput(): OneDashboardPageWidgetBillboardBillboardSettingsVisual | undefined;
}
export interface OneDashboardPageWidgetBillboardChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBillboardChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetBillboardChartStylesGradientOutputReference | OneDashboardPageWidgetBillboardChartStylesGradient): any;
export declare function oneDashboardPageWidgetBillboardChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetBillboardChartStylesGradientOutputReference | OneDashboardPageWidgetBillboardChartStylesGradient): any;
export declare class OneDashboardPageWidgetBillboardChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBillboardChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetBillboardChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetBillboardChartStylesGradient;
}
export declare function oneDashboardPageWidgetBillboardChartStylesToTerraform(struct?: OneDashboardPageWidgetBillboardChartStylesOutputReference | OneDashboardPageWidgetBillboardChartStyles): any;
export declare function oneDashboardPageWidgetBillboardChartStylesToHclTerraform(struct?: OneDashboardPageWidgetBillboardChartStylesOutputReference | OneDashboardPageWidgetBillboardChartStyles): any;
export declare class OneDashboardPageWidgetBillboardChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBillboardChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetBillboardChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetBillboardChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetBillboardChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetBillboardColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetBillboardColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetBillboardColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBillboardColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetBillboardColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBillboardColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBillboardColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBillboardColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBillboardColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBillboardColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetBillboardColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetBillboardColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBillboardColorsToTerraform(struct?: OneDashboardPageWidgetBillboardColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBillboardColorsToHclTerraform(struct?: OneDashboardPageWidgetBillboardColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBillboardColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBillboardColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetBillboardColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetBillboardColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetBillboardColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetBillboardColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBillboardColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBillboardColorsOutputReference;
}
export interface OneDashboardPageWidgetBillboardDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetBillboardDataFormatToTerraform(struct?: OneDashboardPageWidgetBillboardDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBillboardDataFormatToHclTerraform(struct?: OneDashboardPageWidgetBillboardDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBillboardDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBillboardDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBillboardDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBillboardDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBillboardDataFormatOutputReference;
}
export interface OneDashboardPageWidgetBillboardInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetBillboardInitialSortingToTerraform(struct?: OneDashboardPageWidgetBillboardInitialSortingOutputReference | OneDashboardPageWidgetBillboardInitialSorting): any;
export declare function oneDashboardPageWidgetBillboardInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetBillboardInitialSortingOutputReference | OneDashboardPageWidgetBillboardInitialSorting): any;
export declare class OneDashboardPageWidgetBillboardInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBillboardInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetBillboardNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetBillboardNrqlQueryToTerraform(struct?: OneDashboardPageWidgetBillboardNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBillboardNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetBillboardNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBillboardNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBillboardNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBillboardNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBillboardNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBillboardNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetBillboardNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetBillboardNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetBillboardNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBillboardNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetBillboardNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBillboardNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBillboardNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBillboardNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBillboardNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBillboardNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetBillboardNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetBillboardNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBillboardNullValuesToTerraform(struct?: OneDashboardPageWidgetBillboardNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBillboardNullValuesToHclTerraform(struct?: OneDashboardPageWidgetBillboardNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBillboardNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBillboardNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetBillboardNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetBillboardNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetBillboardNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetBillboardNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBillboardNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBillboardNullValuesOutputReference;
}
export interface OneDashboardPageWidgetBillboardUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetBillboardUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetBillboardUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBillboardUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetBillboardUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBillboardUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBillboardUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBillboardUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBillboardUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBillboardUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetBillboardUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetBillboardUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBillboardUnitsToTerraform(struct?: OneDashboardPageWidgetBillboardUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBillboardUnitsToHclTerraform(struct?: OneDashboardPageWidgetBillboardUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBillboardUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBillboardUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboardUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetBillboardUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetBillboardUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetBillboardUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetBillboardUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBillboardUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBillboardUnitsOutputReference;
}
export interface OneDashboardPageWidgetBillboard {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * The critical threshold value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#critical OneDashboard#critical}
    */
    readonly critical?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * The warning threshold value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#warning OneDashboard#warning}
    */
    readonly warning?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * billboard_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#billboard_settings OneDashboard#billboard_settings}
    */
    readonly billboardSettings?: OneDashboardPageWidgetBillboardBillboardSettings;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetBillboardChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetBillboardColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetBillboardDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetBillboardInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetBillboardNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetBillboardNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetBillboardUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBillboardToTerraform(struct?: OneDashboardPageWidgetBillboard | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBillboardToHclTerraform(struct?: OneDashboardPageWidgetBillboard | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBillboardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBillboard | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBillboard | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _critical?;
    get critical(): string;
    set critical(value: string);
    resetCritical(): void;
    get criticalInput(): string | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _warning?;
    get warning(): string;
    set warning(value: string);
    resetWarning(): void;
    get warningInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _billboardSettings;
    get billboardSettings(): OneDashboardPageWidgetBillboardBillboardSettingsOutputReference;
    putBillboardSettings(value: OneDashboardPageWidgetBillboardBillboardSettings): void;
    resetBillboardSettings(): void;
    get billboardSettingsInput(): OneDashboardPageWidgetBillboardBillboardSettings | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetBillboardChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetBillboardChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetBillboardChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetBillboardColorsList;
    putColors(value: OneDashboardPageWidgetBillboardColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetBillboardColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetBillboardDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetBillboardDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetBillboardDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetBillboardInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetBillboardInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetBillboardInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetBillboardNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetBillboardNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetBillboardNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetBillboardNullValuesList;
    putNullValues(value: OneDashboardPageWidgetBillboardNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetBillboardNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetBillboardUnitsList;
    putUnits(value: OneDashboardPageWidgetBillboardUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetBillboardUnits[] | undefined;
}
export declare class OneDashboardPageWidgetBillboardList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBillboard[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBillboardOutputReference;
}
export interface OneDashboardPageWidgetBulletChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBulletChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetBulletChartStylesGradientOutputReference | OneDashboardPageWidgetBulletChartStylesGradient): any;
export declare function oneDashboardPageWidgetBulletChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetBulletChartStylesGradientOutputReference | OneDashboardPageWidgetBulletChartStylesGradient): any;
export declare class OneDashboardPageWidgetBulletChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBulletChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetBulletChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetBulletChartStylesGradient;
}
export declare function oneDashboardPageWidgetBulletChartStylesToTerraform(struct?: OneDashboardPageWidgetBulletChartStylesOutputReference | OneDashboardPageWidgetBulletChartStyles): any;
export declare function oneDashboardPageWidgetBulletChartStylesToHclTerraform(struct?: OneDashboardPageWidgetBulletChartStylesOutputReference | OneDashboardPageWidgetBulletChartStyles): any;
export declare class OneDashboardPageWidgetBulletChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBulletChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetBulletChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetBulletChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetBulletChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetBulletColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetBulletColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetBulletColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBulletColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetBulletColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBulletColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBulletColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBulletColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBulletColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBulletColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetBulletColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetBulletColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBulletColorsToTerraform(struct?: OneDashboardPageWidgetBulletColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBulletColorsToHclTerraform(struct?: OneDashboardPageWidgetBulletColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBulletColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBulletColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetBulletColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetBulletColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetBulletColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetBulletColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBulletColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBulletColorsOutputReference;
}
export interface OneDashboardPageWidgetBulletDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetBulletDataFormatToTerraform(struct?: OneDashboardPageWidgetBulletDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBulletDataFormatToHclTerraform(struct?: OneDashboardPageWidgetBulletDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBulletDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBulletDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBulletDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBulletDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBulletDataFormatOutputReference;
}
export interface OneDashboardPageWidgetBulletInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetBulletInitialSortingToTerraform(struct?: OneDashboardPageWidgetBulletInitialSortingOutputReference | OneDashboardPageWidgetBulletInitialSorting): any;
export declare function oneDashboardPageWidgetBulletInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetBulletInitialSortingOutputReference | OneDashboardPageWidgetBulletInitialSorting): any;
export declare class OneDashboardPageWidgetBulletInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetBulletInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetBulletNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetBulletNrqlQueryToTerraform(struct?: OneDashboardPageWidgetBulletNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBulletNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetBulletNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBulletNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBulletNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBulletNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBulletNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBulletNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetBulletNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetBulletNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetBulletNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBulletNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetBulletNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBulletNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBulletNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBulletNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBulletNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBulletNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetBulletNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetBulletNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBulletNullValuesToTerraform(struct?: OneDashboardPageWidgetBulletNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBulletNullValuesToHclTerraform(struct?: OneDashboardPageWidgetBulletNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBulletNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBulletNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetBulletNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetBulletNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetBulletNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetBulletNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBulletNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBulletNullValuesOutputReference;
}
export interface OneDashboardPageWidgetBulletUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetBulletUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetBulletUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBulletUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetBulletUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBulletUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBulletUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetBulletUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBulletUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBulletUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetBulletUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetBulletUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBulletUnitsToTerraform(struct?: OneDashboardPageWidgetBulletUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBulletUnitsToHclTerraform(struct?: OneDashboardPageWidgetBulletUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBulletUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBulletUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBulletUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetBulletUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetBulletUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetBulletUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetBulletUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBulletUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBulletUnitsOutputReference;
}
export interface OneDashboardPageWidgetBullet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * The maximum value for the visualization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#limit OneDashboard#limit}
    */
    readonly limit: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetBulletChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetBulletColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetBulletDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetBulletInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetBulletNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetBulletNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetBulletUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetBulletToTerraform(struct?: OneDashboardPageWidgetBullet | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetBulletToHclTerraform(struct?: OneDashboardPageWidgetBullet | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetBulletOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetBullet | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetBullet | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    get limitInput(): number | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetBulletChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetBulletChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetBulletChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetBulletColorsList;
    putColors(value: OneDashboardPageWidgetBulletColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetBulletColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetBulletDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetBulletDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetBulletDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetBulletInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetBulletInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetBulletInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetBulletNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetBulletNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetBulletNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetBulletNullValuesList;
    putNullValues(value: OneDashboardPageWidgetBulletNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetBulletNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetBulletUnitsList;
    putUnits(value: OneDashboardPageWidgetBulletUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetBulletUnits[] | undefined;
}
export declare class OneDashboardPageWidgetBulletList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetBullet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetBulletOutputReference;
}
export interface OneDashboardPageWidgetFunnelChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetFunnelChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetFunnelChartStylesGradientOutputReference | OneDashboardPageWidgetFunnelChartStylesGradient): any;
export declare function oneDashboardPageWidgetFunnelChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetFunnelChartStylesGradientOutputReference | OneDashboardPageWidgetFunnelChartStylesGradient): any;
export declare class OneDashboardPageWidgetFunnelChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetFunnelChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetFunnelChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetFunnelChartStylesGradient;
}
export declare function oneDashboardPageWidgetFunnelChartStylesToTerraform(struct?: OneDashboardPageWidgetFunnelChartStylesOutputReference | OneDashboardPageWidgetFunnelChartStyles): any;
export declare function oneDashboardPageWidgetFunnelChartStylesToHclTerraform(struct?: OneDashboardPageWidgetFunnelChartStylesOutputReference | OneDashboardPageWidgetFunnelChartStyles): any;
export declare class OneDashboardPageWidgetFunnelChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetFunnelChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetFunnelChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetFunnelChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetFunnelChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetFunnelColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetFunnelColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetFunnelColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetFunnelColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetFunnelColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetFunnelColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetFunnelColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetFunnelColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetFunnelColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetFunnelColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetFunnelColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetFunnelColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetFunnelColorsToTerraform(struct?: OneDashboardPageWidgetFunnelColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetFunnelColorsToHclTerraform(struct?: OneDashboardPageWidgetFunnelColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetFunnelColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetFunnelColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetFunnelColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetFunnelColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetFunnelColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetFunnelColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetFunnelColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetFunnelColorsOutputReference;
}
export interface OneDashboardPageWidgetFunnelDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetFunnelDataFormatToTerraform(struct?: OneDashboardPageWidgetFunnelDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetFunnelDataFormatToHclTerraform(struct?: OneDashboardPageWidgetFunnelDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetFunnelDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetFunnelDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetFunnelDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetFunnelDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetFunnelDataFormatOutputReference;
}
export interface OneDashboardPageWidgetFunnelInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetFunnelInitialSortingToTerraform(struct?: OneDashboardPageWidgetFunnelInitialSortingOutputReference | OneDashboardPageWidgetFunnelInitialSorting): any;
export declare function oneDashboardPageWidgetFunnelInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetFunnelInitialSortingOutputReference | OneDashboardPageWidgetFunnelInitialSorting): any;
export declare class OneDashboardPageWidgetFunnelInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetFunnelInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetFunnelNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetFunnelNrqlQueryToTerraform(struct?: OneDashboardPageWidgetFunnelNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetFunnelNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetFunnelNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetFunnelNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetFunnelNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetFunnelNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetFunnelNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetFunnelNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetFunnelNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetFunnelNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetFunnelNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetFunnelNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetFunnelNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetFunnelNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetFunnelNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetFunnelNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetFunnelNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetFunnelNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetFunnelNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetFunnelNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetFunnelNullValuesToTerraform(struct?: OneDashboardPageWidgetFunnelNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetFunnelNullValuesToHclTerraform(struct?: OneDashboardPageWidgetFunnelNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetFunnelNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetFunnelNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetFunnelNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetFunnelNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetFunnelNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetFunnelNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetFunnelNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetFunnelNullValuesOutputReference;
}
export interface OneDashboardPageWidgetFunnelUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetFunnelUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetFunnelUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetFunnelUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetFunnelUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetFunnelUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetFunnelUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetFunnelUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetFunnelUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetFunnelUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetFunnelUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetFunnelUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetFunnelUnitsToTerraform(struct?: OneDashboardPageWidgetFunnelUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetFunnelUnitsToHclTerraform(struct?: OneDashboardPageWidgetFunnelUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetFunnelUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetFunnelUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnelUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetFunnelUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetFunnelUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetFunnelUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetFunnelUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetFunnelUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetFunnelUnitsOutputReference;
}
export interface OneDashboardPageWidgetFunnel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetFunnelChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetFunnelColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetFunnelDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetFunnelInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetFunnelNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetFunnelNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetFunnelUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetFunnelToTerraform(struct?: OneDashboardPageWidgetFunnel | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetFunnelToHclTerraform(struct?: OneDashboardPageWidgetFunnel | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetFunnelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetFunnel | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetFunnel | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetFunnelChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetFunnelChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetFunnelChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetFunnelColorsList;
    putColors(value: OneDashboardPageWidgetFunnelColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetFunnelColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetFunnelDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetFunnelDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetFunnelDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetFunnelInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetFunnelInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetFunnelInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetFunnelNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetFunnelNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetFunnelNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetFunnelNullValuesList;
    putNullValues(value: OneDashboardPageWidgetFunnelNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetFunnelNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetFunnelUnitsList;
    putUnits(value: OneDashboardPageWidgetFunnelUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetFunnelUnits[] | undefined;
}
export declare class OneDashboardPageWidgetFunnelList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetFunnel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetFunnelOutputReference;
}
export interface OneDashboardPageWidgetHeatmapChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHeatmapChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetHeatmapChartStylesGradientOutputReference | OneDashboardPageWidgetHeatmapChartStylesGradient): any;
export declare function oneDashboardPageWidgetHeatmapChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetHeatmapChartStylesGradientOutputReference | OneDashboardPageWidgetHeatmapChartStylesGradient): any;
export declare class OneDashboardPageWidgetHeatmapChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetHeatmapChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetHeatmapChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetHeatmapChartStylesGradient;
}
export declare function oneDashboardPageWidgetHeatmapChartStylesToTerraform(struct?: OneDashboardPageWidgetHeatmapChartStylesOutputReference | OneDashboardPageWidgetHeatmapChartStyles): any;
export declare function oneDashboardPageWidgetHeatmapChartStylesToHclTerraform(struct?: OneDashboardPageWidgetHeatmapChartStylesOutputReference | OneDashboardPageWidgetHeatmapChartStyles): any;
export declare class OneDashboardPageWidgetHeatmapChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetHeatmapChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetHeatmapChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetHeatmapChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetHeatmapChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetHeatmapColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetHeatmapColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetHeatmapColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHeatmapColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetHeatmapColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHeatmapColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHeatmapColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHeatmapColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHeatmapColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHeatmapColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetHeatmapColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetHeatmapColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHeatmapColorsToTerraform(struct?: OneDashboardPageWidgetHeatmapColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHeatmapColorsToHclTerraform(struct?: OneDashboardPageWidgetHeatmapColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHeatmapColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHeatmapColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetHeatmapColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetHeatmapColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetHeatmapColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetHeatmapColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHeatmapColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHeatmapColorsOutputReference;
}
export interface OneDashboardPageWidgetHeatmapDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetHeatmapDataFormatToTerraform(struct?: OneDashboardPageWidgetHeatmapDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHeatmapDataFormatToHclTerraform(struct?: OneDashboardPageWidgetHeatmapDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHeatmapDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHeatmapDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHeatmapDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHeatmapDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHeatmapDataFormatOutputReference;
}
export interface OneDashboardPageWidgetHeatmapInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetHeatmapInitialSortingToTerraform(struct?: OneDashboardPageWidgetHeatmapInitialSortingOutputReference | OneDashboardPageWidgetHeatmapInitialSorting): any;
export declare function oneDashboardPageWidgetHeatmapInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetHeatmapInitialSortingOutputReference | OneDashboardPageWidgetHeatmapInitialSorting): any;
export declare class OneDashboardPageWidgetHeatmapInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetHeatmapInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetHeatmapNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetHeatmapNrqlQueryToTerraform(struct?: OneDashboardPageWidgetHeatmapNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHeatmapNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetHeatmapNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHeatmapNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHeatmapNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHeatmapNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHeatmapNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHeatmapNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetHeatmapNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetHeatmapNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetHeatmapNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHeatmapNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetHeatmapNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHeatmapNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHeatmapNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHeatmapNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHeatmapNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHeatmapNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetHeatmapNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetHeatmapNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHeatmapNullValuesToTerraform(struct?: OneDashboardPageWidgetHeatmapNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHeatmapNullValuesToHclTerraform(struct?: OneDashboardPageWidgetHeatmapNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHeatmapNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHeatmapNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetHeatmapNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetHeatmapNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetHeatmapNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetHeatmapNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHeatmapNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHeatmapNullValuesOutputReference;
}
export interface OneDashboardPageWidgetHeatmapUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetHeatmapUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetHeatmapUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHeatmapUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetHeatmapUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHeatmapUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHeatmapUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHeatmapUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHeatmapUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHeatmapUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetHeatmapUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetHeatmapUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHeatmapUnitsToTerraform(struct?: OneDashboardPageWidgetHeatmapUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHeatmapUnitsToHclTerraform(struct?: OneDashboardPageWidgetHeatmapUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHeatmapUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHeatmapUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmapUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetHeatmapUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetHeatmapUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetHeatmapUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetHeatmapUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHeatmapUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHeatmapUnitsOutputReference;
}
export interface OneDashboardPageWidgetHeatmap {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Use this item to filter the current dashboard
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#filter_current_dashboard OneDashboard#filter_current_dashboard}
    */
    readonly filterCurrentDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Related entities. Currently only supports Dashboard entities, but may allow other cases in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#linked_entity_guids OneDashboard#linked_entity_guids}
    */
    readonly linkedEntityGuids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetHeatmapChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetHeatmapColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetHeatmapDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetHeatmapInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetHeatmapNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetHeatmapNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetHeatmapUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHeatmapToTerraform(struct?: OneDashboardPageWidgetHeatmap | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHeatmapToHclTerraform(struct?: OneDashboardPageWidgetHeatmap | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHeatmapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHeatmap | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHeatmap | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _filterCurrentDashboard?;
    get filterCurrentDashboard(): boolean | cdktn.IResolvable;
    set filterCurrentDashboard(value: boolean | cdktn.IResolvable);
    resetFilterCurrentDashboard(): void;
    get filterCurrentDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _linkedEntityGuids?;
    get linkedEntityGuids(): string[];
    set linkedEntityGuids(value: string[]);
    resetLinkedEntityGuids(): void;
    get linkedEntityGuidsInput(): string[] | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetHeatmapChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetHeatmapChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetHeatmapChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetHeatmapColorsList;
    putColors(value: OneDashboardPageWidgetHeatmapColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetHeatmapColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetHeatmapDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetHeatmapDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetHeatmapDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetHeatmapInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetHeatmapInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetHeatmapInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetHeatmapNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetHeatmapNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetHeatmapNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetHeatmapNullValuesList;
    putNullValues(value: OneDashboardPageWidgetHeatmapNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetHeatmapNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetHeatmapUnitsList;
    putUnits(value: OneDashboardPageWidgetHeatmapUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetHeatmapUnits[] | undefined;
}
export declare class OneDashboardPageWidgetHeatmapList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHeatmap[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHeatmapOutputReference;
}
export interface OneDashboardPageWidgetHistogramChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHistogramChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetHistogramChartStylesGradientOutputReference | OneDashboardPageWidgetHistogramChartStylesGradient): any;
export declare function oneDashboardPageWidgetHistogramChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetHistogramChartStylesGradientOutputReference | OneDashboardPageWidgetHistogramChartStylesGradient): any;
export declare class OneDashboardPageWidgetHistogramChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetHistogramChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetHistogramChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetHistogramChartStylesGradient;
}
export declare function oneDashboardPageWidgetHistogramChartStylesToTerraform(struct?: OneDashboardPageWidgetHistogramChartStylesOutputReference | OneDashboardPageWidgetHistogramChartStyles): any;
export declare function oneDashboardPageWidgetHistogramChartStylesToHclTerraform(struct?: OneDashboardPageWidgetHistogramChartStylesOutputReference | OneDashboardPageWidgetHistogramChartStyles): any;
export declare class OneDashboardPageWidgetHistogramChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetHistogramChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetHistogramChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetHistogramChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetHistogramChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetHistogramColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetHistogramColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetHistogramColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHistogramColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetHistogramColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHistogramColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHistogramColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHistogramColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHistogramColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHistogramColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetHistogramColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetHistogramColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHistogramColorsToTerraform(struct?: OneDashboardPageWidgetHistogramColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHistogramColorsToHclTerraform(struct?: OneDashboardPageWidgetHistogramColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHistogramColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHistogramColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetHistogramColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetHistogramColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetHistogramColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetHistogramColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHistogramColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHistogramColorsOutputReference;
}
export interface OneDashboardPageWidgetHistogramDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetHistogramDataFormatToTerraform(struct?: OneDashboardPageWidgetHistogramDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHistogramDataFormatToHclTerraform(struct?: OneDashboardPageWidgetHistogramDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHistogramDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHistogramDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHistogramDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHistogramDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHistogramDataFormatOutputReference;
}
export interface OneDashboardPageWidgetHistogramInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetHistogramInitialSortingToTerraform(struct?: OneDashboardPageWidgetHistogramInitialSortingOutputReference | OneDashboardPageWidgetHistogramInitialSorting): any;
export declare function oneDashboardPageWidgetHistogramInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetHistogramInitialSortingOutputReference | OneDashboardPageWidgetHistogramInitialSorting): any;
export declare class OneDashboardPageWidgetHistogramInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetHistogramInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetHistogramNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetHistogramNrqlQueryToTerraform(struct?: OneDashboardPageWidgetHistogramNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHistogramNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetHistogramNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHistogramNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHistogramNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHistogramNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHistogramNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHistogramNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetHistogramNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetHistogramNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetHistogramNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHistogramNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetHistogramNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHistogramNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHistogramNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHistogramNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHistogramNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHistogramNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetHistogramNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetHistogramNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHistogramNullValuesToTerraform(struct?: OneDashboardPageWidgetHistogramNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHistogramNullValuesToHclTerraform(struct?: OneDashboardPageWidgetHistogramNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHistogramNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHistogramNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetHistogramNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetHistogramNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetHistogramNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetHistogramNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHistogramNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHistogramNullValuesOutputReference;
}
export interface OneDashboardPageWidgetHistogramUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetHistogramUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetHistogramUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHistogramUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetHistogramUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHistogramUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHistogramUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetHistogramUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHistogramUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHistogramUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetHistogramUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetHistogramUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHistogramUnitsToTerraform(struct?: OneDashboardPageWidgetHistogramUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHistogramUnitsToHclTerraform(struct?: OneDashboardPageWidgetHistogramUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHistogramUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHistogramUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogramUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetHistogramUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetHistogramUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetHistogramUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetHistogramUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHistogramUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHistogramUnitsOutputReference;
}
export interface OneDashboardPageWidgetHistogram {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetHistogramChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetHistogramColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetHistogramDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetHistogramInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetHistogramNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetHistogramNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetHistogramUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetHistogramToTerraform(struct?: OneDashboardPageWidgetHistogram | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetHistogramToHclTerraform(struct?: OneDashboardPageWidgetHistogram | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetHistogramOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetHistogram | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetHistogram | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetHistogramChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetHistogramChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetHistogramChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetHistogramColorsList;
    putColors(value: OneDashboardPageWidgetHistogramColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetHistogramColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetHistogramDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetHistogramDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetHistogramDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetHistogramInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetHistogramInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetHistogramInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetHistogramNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetHistogramNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetHistogramNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetHistogramNullValuesList;
    putNullValues(value: OneDashboardPageWidgetHistogramNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetHistogramNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetHistogramUnitsList;
    putUnits(value: OneDashboardPageWidgetHistogramUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetHistogramUnits[] | undefined;
}
export declare class OneDashboardPageWidgetHistogramList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetHistogram[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetHistogramOutputReference;
}
export interface OneDashboardPageWidgetJsonChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetJsonChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetJsonChartStylesGradientOutputReference | OneDashboardPageWidgetJsonChartStylesGradient): any;
export declare function oneDashboardPageWidgetJsonChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetJsonChartStylesGradientOutputReference | OneDashboardPageWidgetJsonChartStylesGradient): any;
export declare class OneDashboardPageWidgetJsonChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetJsonChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetJsonChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetJsonChartStylesGradient;
}
export declare function oneDashboardPageWidgetJsonChartStylesToTerraform(struct?: OneDashboardPageWidgetJsonChartStylesOutputReference | OneDashboardPageWidgetJsonChartStyles): any;
export declare function oneDashboardPageWidgetJsonChartStylesToHclTerraform(struct?: OneDashboardPageWidgetJsonChartStylesOutputReference | OneDashboardPageWidgetJsonChartStyles): any;
export declare class OneDashboardPageWidgetJsonChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetJsonChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetJsonChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetJsonChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetJsonChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetJsonColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetJsonColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetJsonColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetJsonColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetJsonColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetJsonColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetJsonColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetJsonColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetJsonColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetJsonColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetJsonColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetJsonColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetJsonColorsToTerraform(struct?: OneDashboardPageWidgetJsonColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetJsonColorsToHclTerraform(struct?: OneDashboardPageWidgetJsonColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetJsonColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetJsonColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetJsonColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetJsonColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetJsonColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetJsonColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetJsonColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetJsonColorsOutputReference;
}
export interface OneDashboardPageWidgetJsonDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetJsonDataFormatToTerraform(struct?: OneDashboardPageWidgetJsonDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetJsonDataFormatToHclTerraform(struct?: OneDashboardPageWidgetJsonDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetJsonDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetJsonDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetJsonDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetJsonDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetJsonDataFormatOutputReference;
}
export interface OneDashboardPageWidgetJsonInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetJsonInitialSortingToTerraform(struct?: OneDashboardPageWidgetJsonInitialSortingOutputReference | OneDashboardPageWidgetJsonInitialSorting): any;
export declare function oneDashboardPageWidgetJsonInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetJsonInitialSortingOutputReference | OneDashboardPageWidgetJsonInitialSorting): any;
export declare class OneDashboardPageWidgetJsonInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetJsonInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetJsonNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetJsonNrqlQueryToTerraform(struct?: OneDashboardPageWidgetJsonNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetJsonNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetJsonNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetJsonNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetJsonNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetJsonNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetJsonNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetJsonNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetJsonNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetJsonNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetJsonNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetJsonNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetJsonNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetJsonNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetJsonNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetJsonNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetJsonNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetJsonNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetJsonNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetJsonNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetJsonNullValuesToTerraform(struct?: OneDashboardPageWidgetJsonNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetJsonNullValuesToHclTerraform(struct?: OneDashboardPageWidgetJsonNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetJsonNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetJsonNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetJsonNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetJsonNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetJsonNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetJsonNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetJsonNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetJsonNullValuesOutputReference;
}
export interface OneDashboardPageWidgetJsonUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetJsonUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetJsonUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetJsonUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetJsonUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetJsonUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetJsonUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetJsonUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetJsonUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetJsonUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetJsonUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetJsonUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetJsonUnitsToTerraform(struct?: OneDashboardPageWidgetJsonUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetJsonUnitsToHclTerraform(struct?: OneDashboardPageWidgetJsonUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetJsonUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetJsonUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetJsonUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetJsonUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetJsonUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetJsonUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetJsonUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetJsonUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetJsonUnitsOutputReference;
}
export interface OneDashboardPageWidgetJson {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetJsonChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetJsonColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetJsonDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetJsonInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetJsonNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetJsonNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetJsonUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetJsonToTerraform(struct?: OneDashboardPageWidgetJson | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetJsonToHclTerraform(struct?: OneDashboardPageWidgetJson | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetJson | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetJson | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetJsonChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetJsonChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetJsonChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetJsonColorsList;
    putColors(value: OneDashboardPageWidgetJsonColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetJsonColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetJsonDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetJsonDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetJsonDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetJsonInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetJsonInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetJsonInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetJsonNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetJsonNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetJsonNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetJsonNullValuesList;
    putNullValues(value: OneDashboardPageWidgetJsonNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetJsonNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetJsonUnitsList;
    putUnits(value: OneDashboardPageWidgetJsonUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetJsonUnits[] | undefined;
}
export declare class OneDashboardPageWidgetJsonList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetJson[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetJsonOutputReference;
}
export interface OneDashboardPageWidgetLineChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLineChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetLineChartStylesGradientOutputReference | OneDashboardPageWidgetLineChartStylesGradient): any;
export declare function oneDashboardPageWidgetLineChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetLineChartStylesGradientOutputReference | OneDashboardPageWidgetLineChartStylesGradient): any;
export declare class OneDashboardPageWidgetLineChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetLineChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetLineChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetLineChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetLineChartStylesGradient;
}
export declare function oneDashboardPageWidgetLineChartStylesToTerraform(struct?: OneDashboardPageWidgetLineChartStylesOutputReference | OneDashboardPageWidgetLineChartStyles): any;
export declare function oneDashboardPageWidgetLineChartStylesToHclTerraform(struct?: OneDashboardPageWidgetLineChartStylesOutputReference | OneDashboardPageWidgetLineChartStyles): any;
export declare class OneDashboardPageWidgetLineChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetLineChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetLineChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetLineChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetLineChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetLineChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetLineColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetLineColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetLineColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetLineColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLineColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLineColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLineColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLineColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetLineColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetLineColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLineColorsToTerraform(struct?: OneDashboardPageWidgetLineColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineColorsToHclTerraform(struct?: OneDashboardPageWidgetLineColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLineColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLineColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetLineColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetLineColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetLineColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetLineColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLineColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineColorsOutputReference;
}
export interface OneDashboardPageWidgetLineDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetLineDataFormatToTerraform(struct?: OneDashboardPageWidgetLineDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineDataFormatToHclTerraform(struct?: OneDashboardPageWidgetLineDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLineDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLineDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLineDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLineDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineDataFormatOutputReference;
}
export interface OneDashboardPageWidgetLineInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetLineInitialSortingToTerraform(struct?: OneDashboardPageWidgetLineInitialSortingOutputReference | OneDashboardPageWidgetLineInitialSorting): any;
export declare function oneDashboardPageWidgetLineInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetLineInitialSortingOutputReference | OneDashboardPageWidgetLineInitialSorting): any;
export declare class OneDashboardPageWidgetLineInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetLineInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetLineInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetLineNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.99.3/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetLineNrqlQueryToTerraform(struct?: OneDashboardPageWidgetLineNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetLineNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLineNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLineNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLineNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLineNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineNrqlQueryOutputReference;
}
