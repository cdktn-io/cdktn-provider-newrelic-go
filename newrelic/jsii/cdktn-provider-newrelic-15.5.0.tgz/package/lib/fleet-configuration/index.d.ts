/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FleetConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The type of agent this configuration is for. Allowed values: NRInfra, NRDOT, FluentBit, NRPrometheusAgent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration#agent_type FleetConfiguration#agent_type}
    */
    readonly agentType: string;
    /**
    * The configuration content (YAML or JSON). Use file() to load from a file. Each change to this field creates a new immutable version on the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration#configuration_content FleetConfiguration#configuration_content}
    */
    readonly configurationContent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration#id FleetConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The type of entities this configuration manages. Allowed values: HOST, KUBERNETESCLUSTER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration#managed_entity_type FleetConfiguration#managed_entity_type}
    */
    readonly managedEntityType: string;
    /**
    * The name of the configuration. Changing this forces resource recreation because the API does not support renaming.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration#name FleetConfiguration#name}
    */
    readonly name: string;
    /**
    * The operating system this configuration targets. Required for HOST configurations. Allowed values: LINUX, WINDOWS. Must not be set for KUBERNETESCLUSTER configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration#operating_system FleetConfiguration#operating_system}
    */
    readonly operatingSystem?: string;
    /**
    * The organization ID. Auto-fetched from the account if not provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration#organization_id FleetConfiguration#organization_id}
    */
    readonly organizationId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration newrelic_fleet_configuration}
*/
export declare class FleetConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_fleet_configuration";
    /**
    * Generates CDKTN code for importing a FleetConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FleetConfiguration to import
    * @param importFromId The id of the existing FleetConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FleetConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/fleet_configuration newrelic_fleet_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FleetConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: FleetConfigurationConfig);
    private _agentType?;
    get agentType(): string;
    set agentType(value: string);
    get agentTypeInput(): string | undefined;
    private _configurationContent?;
    get configurationContent(): string;
    set configurationContent(value: string);
    get configurationContentInput(): string | undefined;
    get configurationId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get latestVersionEntityId(): string;
    get latestVersionNumber(): number;
    private _managedEntityType?;
    get managedEntityType(): string;
    set managedEntityType(value: string);
    get managedEntityTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operatingSystem?;
    get operatingSystem(): string;
    set operatingSystem(value: string);
    resetOperatingSystem(): void;
    get operatingSystemInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    resetOrganizationId(): void;
    get organizationIdInput(): string | undefined;
    get totalVersions(): number;
    get versionEntityIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
