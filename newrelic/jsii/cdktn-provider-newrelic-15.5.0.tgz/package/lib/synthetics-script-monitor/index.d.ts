/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsScriptMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the newrelic account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#account_id SyntheticsScriptMonitor#account_id}
    */
    readonly accountId?: number;
    /**
    * The multiple browsers list on which synthetic monitors will run. Valid values are array of CHROME,and FIREFOX
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#browsers SyntheticsScriptMonitor#browsers}
    */
    readonly browsers?: string[];
    /**
    * The device orientation the user would like to represent. Valid values are LANDSCAPE, PORTRAIT, or NONE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#device_orientation SyntheticsScriptMonitor#device_orientation}
    */
    readonly deviceOrientation?: string;
    /**
    * The device type that a user can select. Valid values are MOBILE, TABLET, or NONE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#device_type SyntheticsScriptMonitor#device_type}
    */
    readonly deviceType?: string;
    /**
    * The multiple devices list on which synthetic monitors will run. Valid values are array of DESKTOP, MOBILE_LANDSCAPE, MOBILE_PORTRAIT, TABLET_LANDSCAPE and TABLET_PORTRAIT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#devices SyntheticsScriptMonitor#devices}
    */
    readonly devices?: string[];
    /**
    * Capture a screenshot during job execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#enable_screenshot_on_failure_and_script SyntheticsScriptMonitor#enable_screenshot_on_failure_and_script}
    */
    readonly enableScreenshotOnFailureAndScript?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#id SyntheticsScriptMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The public location(s) that the monitor will run jobs from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#locations_public SyntheticsScriptMonitor#locations_public}
    */
    readonly locationsPublic?: string[];
    /**
    * The title of this monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#name SyntheticsScriptMonitor#name}
    */
    readonly name: string;
    /**
    * The interval at which this monitor should run. Valid values are EVERY_MINUTE, EVERY_5_MINUTES, EVERY_10_MINUTES, EVERY_15_MINUTES, EVERY_30_MINUTES, EVERY_HOUR, EVERY_6_HOURS, EVERY_12_HOURS, or EVERY_DAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#period SyntheticsScriptMonitor#period}
    */
    readonly period: string;
    /**
    * The runtime type that the monitor will run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#runtime_type SyntheticsScriptMonitor#runtime_type}
    */
    readonly runtimeType?: string;
    /**
    * The specific semver version of the runtime type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#runtime_type_version SyntheticsScriptMonitor#runtime_type_version}
    */
    readonly runtimeTypeVersion?: string;
    /**
    * The script that the monitor runs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#script SyntheticsScriptMonitor#script}
    */
    readonly script?: string;
    /**
    * The programing language that should execute the script.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#script_language SyntheticsScriptMonitor#script_language}
    */
    readonly scriptLanguage?: string;
    /**
    * The monitor status (ENABLED or DISABLED).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#status SyntheticsScriptMonitor#status}
    */
    readonly status: string;
    /**
    * The monitor type. Valid values are SCRIPT_BROWSER, and SCRIPT_API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#type SyntheticsScriptMonitor#type}
    */
    readonly type: string;
    /**
    * A boolean attribute to be set true by the customer, if they would like to use the unsupported legacy runtime of Synthetic Monitors by means of an exemption given until the October 22, 2024 Legacy Runtime EOL. Setting this attribute to true would allow skipping validation performed by the the New Relic Terraform Provider starting v3.43.0 to disallow using the legacy runtime with new monitors. This would, hence, allow creation of monitors in the legacy runtime until the October 22, 2024 Legacy Runtime EOL, if exempt by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#use_unsupported_legacy_runtime SyntheticsScriptMonitor#use_unsupported_legacy_runtime}
    */
    readonly useUnsupportedLegacyRuntime?: boolean | cdktn.IResolvable;
    /**
    * location_private block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#location_private SyntheticsScriptMonitor#location_private}
    */
    readonly locationPrivate?: SyntheticsScriptMonitorLocationPrivate[] | cdktn.IResolvable;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#tag SyntheticsScriptMonitor#tag}
    */
    readonly tag?: SyntheticsScriptMonitorTag[] | cdktn.IResolvable;
}
export interface SyntheticsScriptMonitorLocationPrivate {
    /**
    * The unique identifier for the Synthetics private location in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#guid SyntheticsScriptMonitor#guid}
    */
    readonly guid: string;
    /**
    * The location's Verified Script Execution password (Only necessary if Verified Script Execution is enabled for the location).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#vse_password SyntheticsScriptMonitor#vse_password}
    */
    readonly vsePassword?: string;
}
export declare function syntheticsScriptMonitorLocationPrivateToTerraform(struct?: SyntheticsScriptMonitorLocationPrivate | cdktn.IResolvable): any;
export declare function syntheticsScriptMonitorLocationPrivateToHclTerraform(struct?: SyntheticsScriptMonitorLocationPrivate | cdktn.IResolvable): any;
export declare class SyntheticsScriptMonitorLocationPrivateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsScriptMonitorLocationPrivate | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsScriptMonitorLocationPrivate | cdktn.IResolvable | undefined);
    private _guid?;
    get guid(): string;
    set guid(value: string);
    get guidInput(): string | undefined;
    private _vsePassword?;
    get vsePassword(): string;
    set vsePassword(value: string);
    resetVsePassword(): void;
    get vsePasswordInput(): string | undefined;
}
export declare class SyntheticsScriptMonitorLocationPrivateList extends cdktn.ComplexList {
    internalValue?: SyntheticsScriptMonitorLocationPrivate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsScriptMonitorLocationPrivateOutputReference;
}
export interface SyntheticsScriptMonitorTag {
    /**
    * Name of the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#key SyntheticsScriptMonitor#key}
    */
    readonly key: string;
    /**
    * Values associated with the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#values SyntheticsScriptMonitor#values}
    */
    readonly values: string[];
}
export declare function syntheticsScriptMonitorTagToTerraform(struct?: SyntheticsScriptMonitorTag | cdktn.IResolvable): any;
export declare function syntheticsScriptMonitorTagToHclTerraform(struct?: SyntheticsScriptMonitorTag | cdktn.IResolvable): any;
export declare class SyntheticsScriptMonitorTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsScriptMonitorTag | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsScriptMonitorTag | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class SyntheticsScriptMonitorTagList extends cdktn.ComplexList {
    internalValue?: SyntheticsScriptMonitorTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsScriptMonitorTagOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor newrelic_synthetics_script_monitor}
*/
export declare class SyntheticsScriptMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_synthetics_script_monitor";
    /**
    * Generates CDKTN code for importing a SyntheticsScriptMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsScriptMonitor to import
    * @param importFromId The id of the existing SyntheticsScriptMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsScriptMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.0/docs/resources/synthetics_script_monitor newrelic_synthetics_script_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsScriptMonitorConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsScriptMonitorConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _browsers?;
    get browsers(): string[];
    set browsers(value: string[]);
    resetBrowsers(): void;
    get browsersInput(): string[] | undefined;
    private _deviceOrientation?;
    get deviceOrientation(): string;
    set deviceOrientation(value: string);
    resetDeviceOrientation(): void;
    get deviceOrientationInput(): string | undefined;
    private _deviceType?;
    get deviceType(): string;
    set deviceType(value: string);
    resetDeviceType(): void;
    get deviceTypeInput(): string | undefined;
    private _devices?;
    get devices(): string[];
    set devices(value: string[]);
    resetDevices(): void;
    get devicesInput(): string[] | undefined;
    private _enableScreenshotOnFailureAndScript?;
    get enableScreenshotOnFailureAndScript(): boolean | cdktn.IResolvable;
    set enableScreenshotOnFailureAndScript(value: boolean | cdktn.IResolvable);
    resetEnableScreenshotOnFailureAndScript(): void;
    get enableScreenshotOnFailureAndScriptInput(): boolean | cdktn.IResolvable | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationsPublic?;
    get locationsPublic(): string[];
    set locationsPublic(value: string[]);
    resetLocationsPublic(): void;
    get locationsPublicInput(): string[] | undefined;
    get monitorId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    get periodInput(): string | undefined;
    get periodInMinutes(): number;
    private _runtimeType?;
    get runtimeType(): string;
    set runtimeType(value: string);
    resetRuntimeType(): void;
    get runtimeTypeInput(): string | undefined;
    private _runtimeTypeVersion?;
    get runtimeTypeVersion(): string;
    set runtimeTypeVersion(value: string);
    resetRuntimeTypeVersion(): void;
    get runtimeTypeVersionInput(): string | undefined;
    private _script?;
    get script(): string;
    set script(value: string);
    resetScript(): void;
    get scriptInput(): string | undefined;
    private _scriptLanguage?;
    get scriptLanguage(): string;
    set scriptLanguage(value: string);
    resetScriptLanguage(): void;
    get scriptLanguageInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _useUnsupportedLegacyRuntime?;
    get useUnsupportedLegacyRuntime(): boolean | cdktn.IResolvable;
    set useUnsupportedLegacyRuntime(value: boolean | cdktn.IResolvable);
    resetUseUnsupportedLegacyRuntime(): void;
    get useUnsupportedLegacyRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _locationPrivate;
    get locationPrivate(): SyntheticsScriptMonitorLocationPrivateList;
    putLocationPrivate(value: SyntheticsScriptMonitorLocationPrivate[] | cdktn.IResolvable): void;
    resetLocationPrivate(): void;
    get locationPrivateInput(): cdktn.IResolvable | SyntheticsScriptMonitorLocationPrivate[] | undefined;
    private _tag;
    get tag(): SyntheticsScriptMonitorTagList;
    putTag(value: SyntheticsScriptMonitorTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | SyntheticsScriptMonitorTag[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
