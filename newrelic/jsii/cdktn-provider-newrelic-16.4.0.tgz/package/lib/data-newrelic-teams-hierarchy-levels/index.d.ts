/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicTeamsHierarchyLevelsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/data-sources/teams_hierarchy_levels#id DataNewrelicTeamsHierarchyLevels#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataNewrelicTeamsHierarchyLevelsLevels {
}
export declare function dataNewrelicTeamsHierarchyLevelsLevelsToTerraform(struct?: DataNewrelicTeamsHierarchyLevelsLevels): any;
export declare function dataNewrelicTeamsHierarchyLevelsLevelsToHclTerraform(struct?: DataNewrelicTeamsHierarchyLevelsLevels): any;
export declare class DataNewrelicTeamsHierarchyLevelsLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNewrelicTeamsHierarchyLevelsLevels | undefined;
    set internalValue(value: DataNewrelicTeamsHierarchyLevelsLevels | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataNewrelicTeamsHierarchyLevelsLevelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNewrelicTeamsHierarchyLevelsLevelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/data-sources/teams_hierarchy_levels newrelic_teams_hierarchy_levels}
*/
export declare class DataNewrelicTeamsHierarchyLevels extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_teams_hierarchy_levels";
    /**
    * Generates CDKTN code for importing a DataNewrelicTeamsHierarchyLevels resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicTeamsHierarchyLevels to import
    * @param importFromId The id of the existing DataNewrelicTeamsHierarchyLevels that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/data-sources/teams_hierarchy_levels#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicTeamsHierarchyLevels to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/data-sources/teams_hierarchy_levels newrelic_teams_hierarchy_levels} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicTeamsHierarchyLevelsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataNewrelicTeamsHierarchyLevelsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _levels;
    get levels(): DataNewrelicTeamsHierarchyLevelsLevelsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
