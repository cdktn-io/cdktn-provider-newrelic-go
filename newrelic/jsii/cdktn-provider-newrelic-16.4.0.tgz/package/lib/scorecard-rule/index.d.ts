/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ScorecardRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#description ScorecardRule#description}
    */
    readonly description?: string;
    /**
    * Whether this rule is active. Set to false to pause evaluation without deleting the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#enabled ScorecardRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#id ScorecardRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Relative weight of this rule's contribution to the overall scorecard score. Must be a non-negative integer. Omit for equal weighting across all rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#impact_weight ScorecardRule#impact_weight}
    */
    readonly impactWeight?: number;
    /**
    * The name of the scorecard rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#name ScorecardRule#name}
    */
    readonly name: string;
    /**
    * The progress level ID from the parent scorecard this rule maps to (e.g. 'red'). Must match a progress_levels.id defined on the scorecard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#progress_level ScorecardRule#progress_level}
    */
    readonly progressLevel?: string;
    /**
    * Evaluation frequency in minutes. Must be one of: 60 (hourly), 360 (6h), 720 (12h), 1440 (daily). Omit to use the API default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#run_interval ScorecardRule#run_interval}
    */
    readonly runInterval?: number;
    /**
    * nrql_engine block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#nrql_engine ScorecardRule#nrql_engine}
    */
    readonly nrqlEngine: ScorecardRuleNrqlEngine;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#tags ScorecardRule#tags}
    */
    readonly tags?: ScorecardRuleTags[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#timeouts ScorecardRule#timeouts}
    */
    readonly timeouts?: ScorecardRuleTimeouts;
}
export interface ScorecardRuleNrqlEngine {
    /**
    * Account IDs where this rule runs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#accounts ScorecardRule#accounts}
    */
    readonly accounts: number[];
    /**
    * Additional account IDs to join with the query accounts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#join_accounts ScorecardRule#join_accounts}
    */
    readonly joinAccounts?: number[];
    /**
    * The NRQL query. Must be FACET-ed and alias the result as 'score'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#query ScorecardRule#query}
    */
    readonly query: string;
}
export declare function scorecardRuleNrqlEngineToTerraform(struct?: ScorecardRuleNrqlEngineOutputReference | ScorecardRuleNrqlEngine): any;
export declare function scorecardRuleNrqlEngineToHclTerraform(struct?: ScorecardRuleNrqlEngineOutputReference | ScorecardRuleNrqlEngine): any;
export declare class ScorecardRuleNrqlEngineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ScorecardRuleNrqlEngine | undefined;
    set internalValue(value: ScorecardRuleNrqlEngine | undefined);
    private _accounts?;
    get accounts(): number[];
    set accounts(value: number[]);
    get accountsInput(): number[] | undefined;
    private _joinAccounts?;
    get joinAccounts(): number[];
    set joinAccounts(value: number[]);
    resetJoinAccounts(): void;
    get joinAccountsInput(): number[] | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface ScorecardRuleTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#key ScorecardRule#key}
    */
    readonly key: string;
    /**
    * The tag values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#values ScorecardRule#values}
    */
    readonly values: string[];
}
export declare function scorecardRuleTagsToTerraform(struct?: ScorecardRuleTags | cdktn.IResolvable): any;
export declare function scorecardRuleTagsToHclTerraform(struct?: ScorecardRuleTags | cdktn.IResolvable): any;
export declare class ScorecardRuleTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScorecardRuleTags | cdktn.IResolvable | undefined;
    set internalValue(value: ScorecardRuleTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ScorecardRuleTagsList extends cdktn.ComplexList {
    internalValue?: ScorecardRuleTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScorecardRuleTagsOutputReference;
}
export interface ScorecardRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#create ScorecardRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#update ScorecardRule#update}
    */
    readonly update?: string;
}
export declare function scorecardRuleTimeoutsToTerraform(struct?: ScorecardRuleTimeouts | cdktn.IResolvable): any;
export declare function scorecardRuleTimeoutsToHclTerraform(struct?: ScorecardRuleTimeouts | cdktn.IResolvable): any;
export declare class ScorecardRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ScorecardRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ScorecardRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule newrelic_scorecard_rule}
*/
export declare class ScorecardRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_scorecard_rule";
    /**
    * Generates CDKTN code for importing a ScorecardRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ScorecardRule to import
    * @param importFromId The id of the existing ScorecardRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ScorecardRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.0/docs/resources/scorecard_rule newrelic_scorecard_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ScorecardRuleConfig
    */
    constructor(scope: Construct, id: string, config: ScorecardRuleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _impactWeight?;
    get impactWeight(): number;
    set impactWeight(value: number);
    resetImpactWeight(): void;
    get impactWeightInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _progressLevel?;
    get progressLevel(): string;
    set progressLevel(value: string);
    resetProgressLevel(): void;
    get progressLevelInput(): string | undefined;
    private _runInterval?;
    get runInterval(): number;
    set runInterval(value: number);
    resetRunInterval(): void;
    get runIntervalInput(): number | undefined;
    private _nrqlEngine;
    get nrqlEngine(): ScorecardRuleNrqlEngineOutputReference;
    putNrqlEngine(value: ScorecardRuleNrqlEngine): void;
    get nrqlEngineInput(): ScorecardRuleNrqlEngine | undefined;
    private _tags;
    get tags(): ScorecardRuleTagsList;
    putTags(value: ScorecardRuleTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ScorecardRuleTags[] | undefined;
    private _timeouts;
    get timeouts(): ScorecardRuleTimeoutsOutputReference;
    putTimeouts(value: ScorecardRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ScorecardRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
