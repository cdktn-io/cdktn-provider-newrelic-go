/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceLevelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#description ServiceLevel#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#guid ServiceLevel#guid}
    */
    readonly guid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#id ServiceLevel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#name ServiceLevel#name}
    */
    readonly name: string;
    /**
    * events block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#events ServiceLevel#events}
    */
    readonly events: ServiceLevelEvents;
    /**
    * objective block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#objective ServiceLevel#objective}
    */
    readonly objective: ServiceLevelObjective;
}
export interface ServiceLevelEventsBadEventsSelect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#attribute ServiceLevel#attribute}
    */
    readonly attribute?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#function ServiceLevel#function}
    */
    readonly function: string;
    /**
    * The event threshold to use in the SELECT clause
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#threshold ServiceLevel#threshold}
    */
    readonly threshold?: number;
}
export declare function serviceLevelEventsBadEventsSelectToTerraform(struct?: ServiceLevelEventsBadEventsSelectOutputReference | ServiceLevelEventsBadEventsSelect): any;
export declare function serviceLevelEventsBadEventsSelectToHclTerraform(struct?: ServiceLevelEventsBadEventsSelectOutputReference | ServiceLevelEventsBadEventsSelect): any;
export declare class ServiceLevelEventsBadEventsSelectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelEventsBadEventsSelect | undefined;
    set internalValue(value: ServiceLevelEventsBadEventsSelect | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _function?;
    get function(): string;
    set function(value: string);
    get functionInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
}
export interface ServiceLevelEventsBadEvents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#from ServiceLevel#from}
    */
    readonly from: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#where ServiceLevel#where}
    */
    readonly where?: string;
    /**
    * select block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#select ServiceLevel#select}
    */
    readonly select?: ServiceLevelEventsBadEventsSelect;
}
export declare function serviceLevelEventsBadEventsToTerraform(struct?: ServiceLevelEventsBadEventsOutputReference | ServiceLevelEventsBadEvents): any;
export declare function serviceLevelEventsBadEventsToHclTerraform(struct?: ServiceLevelEventsBadEventsOutputReference | ServiceLevelEventsBadEvents): any;
export declare class ServiceLevelEventsBadEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelEventsBadEvents | undefined;
    set internalValue(value: ServiceLevelEventsBadEvents | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    get fromInput(): string | undefined;
    private _where?;
    get where(): string;
    set where(value: string);
    resetWhere(): void;
    get whereInput(): string | undefined;
    private _select;
    get select(): ServiceLevelEventsBadEventsSelectOutputReference;
    putSelect(value: ServiceLevelEventsBadEventsSelect): void;
    resetSelect(): void;
    get selectInput(): ServiceLevelEventsBadEventsSelect | undefined;
}
export interface ServiceLevelEventsGoodEventsSelect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#attribute ServiceLevel#attribute}
    */
    readonly attribute?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#function ServiceLevel#function}
    */
    readonly function: string;
    /**
    * The event threshold to use in the SELECT clause
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#threshold ServiceLevel#threshold}
    */
    readonly threshold?: number;
}
export declare function serviceLevelEventsGoodEventsSelectToTerraform(struct?: ServiceLevelEventsGoodEventsSelectOutputReference | ServiceLevelEventsGoodEventsSelect): any;
export declare function serviceLevelEventsGoodEventsSelectToHclTerraform(struct?: ServiceLevelEventsGoodEventsSelectOutputReference | ServiceLevelEventsGoodEventsSelect): any;
export declare class ServiceLevelEventsGoodEventsSelectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelEventsGoodEventsSelect | undefined;
    set internalValue(value: ServiceLevelEventsGoodEventsSelect | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _function?;
    get function(): string;
    set function(value: string);
    get functionInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
}
export interface ServiceLevelEventsGoodEvents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#from ServiceLevel#from}
    */
    readonly from: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#where ServiceLevel#where}
    */
    readonly where?: string;
    /**
    * select block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#select ServiceLevel#select}
    */
    readonly select?: ServiceLevelEventsGoodEventsSelect;
}
export declare function serviceLevelEventsGoodEventsToTerraform(struct?: ServiceLevelEventsGoodEventsOutputReference | ServiceLevelEventsGoodEvents): any;
export declare function serviceLevelEventsGoodEventsToHclTerraform(struct?: ServiceLevelEventsGoodEventsOutputReference | ServiceLevelEventsGoodEvents): any;
export declare class ServiceLevelEventsGoodEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelEventsGoodEvents | undefined;
    set internalValue(value: ServiceLevelEventsGoodEvents | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    get fromInput(): string | undefined;
    private _where?;
    get where(): string;
    set where(value: string);
    resetWhere(): void;
    get whereInput(): string | undefined;
    private _select;
    get select(): ServiceLevelEventsGoodEventsSelectOutputReference;
    putSelect(value: ServiceLevelEventsGoodEventsSelect): void;
    resetSelect(): void;
    get selectInput(): ServiceLevelEventsGoodEventsSelect | undefined;
}
export interface ServiceLevelEventsValidEventsSelect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#attribute ServiceLevel#attribute}
    */
    readonly attribute?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#function ServiceLevel#function}
    */
    readonly function: string;
    /**
    * The event threshold to use in the SELECT clause
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#threshold ServiceLevel#threshold}
    */
    readonly threshold?: number;
}
export declare function serviceLevelEventsValidEventsSelectToTerraform(struct?: ServiceLevelEventsValidEventsSelectOutputReference | ServiceLevelEventsValidEventsSelect): any;
export declare function serviceLevelEventsValidEventsSelectToHclTerraform(struct?: ServiceLevelEventsValidEventsSelectOutputReference | ServiceLevelEventsValidEventsSelect): any;
export declare class ServiceLevelEventsValidEventsSelectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelEventsValidEventsSelect | undefined;
    set internalValue(value: ServiceLevelEventsValidEventsSelect | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _function?;
    get function(): string;
    set function(value: string);
    get functionInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
}
export interface ServiceLevelEventsValidEvents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#from ServiceLevel#from}
    */
    readonly from: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#where ServiceLevel#where}
    */
    readonly where?: string;
    /**
    * select block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#select ServiceLevel#select}
    */
    readonly select?: ServiceLevelEventsValidEventsSelect;
}
export declare function serviceLevelEventsValidEventsToTerraform(struct?: ServiceLevelEventsValidEventsOutputReference | ServiceLevelEventsValidEvents): any;
export declare function serviceLevelEventsValidEventsToHclTerraform(struct?: ServiceLevelEventsValidEventsOutputReference | ServiceLevelEventsValidEvents): any;
export declare class ServiceLevelEventsValidEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelEventsValidEvents | undefined;
    set internalValue(value: ServiceLevelEventsValidEvents | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    get fromInput(): string | undefined;
    private _where?;
    get where(): string;
    set where(value: string);
    resetWhere(): void;
    get whereInput(): string | undefined;
    private _select;
    get select(): ServiceLevelEventsValidEventsSelectOutputReference;
    putSelect(value: ServiceLevelEventsValidEventsSelect): void;
    resetSelect(): void;
    get selectInput(): ServiceLevelEventsValidEventsSelect | undefined;
}
export interface ServiceLevelEvents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#account_id ServiceLevel#account_id}
    */
    readonly accountId: number;
    /**
    * bad_events block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#bad_events ServiceLevel#bad_events}
    */
    readonly badEvents?: ServiceLevelEventsBadEvents;
    /**
    * good_events block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#good_events ServiceLevel#good_events}
    */
    readonly goodEvents?: ServiceLevelEventsGoodEvents;
    /**
    * valid_events block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#valid_events ServiceLevel#valid_events}
    */
    readonly validEvents: ServiceLevelEventsValidEvents;
}
export declare function serviceLevelEventsToTerraform(struct?: ServiceLevelEventsOutputReference | ServiceLevelEvents): any;
export declare function serviceLevelEventsToHclTerraform(struct?: ServiceLevelEventsOutputReference | ServiceLevelEvents): any;
export declare class ServiceLevelEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelEvents | undefined;
    set internalValue(value: ServiceLevelEvents | undefined);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    get accountIdInput(): number | undefined;
    private _badEvents;
    get badEvents(): ServiceLevelEventsBadEventsOutputReference;
    putBadEvents(value: ServiceLevelEventsBadEvents): void;
    resetBadEvents(): void;
    get badEventsInput(): ServiceLevelEventsBadEvents | undefined;
    private _goodEvents;
    get goodEvents(): ServiceLevelEventsGoodEventsOutputReference;
    putGoodEvents(value: ServiceLevelEventsGoodEvents): void;
    resetGoodEvents(): void;
    get goodEventsInput(): ServiceLevelEventsGoodEvents | undefined;
    private _validEvents;
    get validEvents(): ServiceLevelEventsValidEventsOutputReference;
    putValidEvents(value: ServiceLevelEventsValidEvents): void;
    get validEventsInput(): ServiceLevelEventsValidEvents | undefined;
}
export interface ServiceLevelObjectiveTimeWindowRolling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#count ServiceLevel#count}
    */
    readonly count: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#unit ServiceLevel#unit}
    */
    readonly unit: string;
}
export declare function serviceLevelObjectiveTimeWindowRollingToTerraform(struct?: ServiceLevelObjectiveTimeWindowRollingOutputReference | ServiceLevelObjectiveTimeWindowRolling): any;
export declare function serviceLevelObjectiveTimeWindowRollingToHclTerraform(struct?: ServiceLevelObjectiveTimeWindowRollingOutputReference | ServiceLevelObjectiveTimeWindowRolling): any;
export declare class ServiceLevelObjectiveTimeWindowRollingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveTimeWindowRolling | undefined;
    set internalValue(value: ServiceLevelObjectiveTimeWindowRolling | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    get countInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
}
export interface ServiceLevelObjectiveTimeWindow {
    /**
    * rolling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#rolling ServiceLevel#rolling}
    */
    readonly rolling: ServiceLevelObjectiveTimeWindowRolling;
}
export declare function serviceLevelObjectiveTimeWindowToTerraform(struct?: ServiceLevelObjectiveTimeWindowOutputReference | ServiceLevelObjectiveTimeWindow): any;
export declare function serviceLevelObjectiveTimeWindowToHclTerraform(struct?: ServiceLevelObjectiveTimeWindowOutputReference | ServiceLevelObjectiveTimeWindow): any;
export declare class ServiceLevelObjectiveTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveTimeWindow | undefined;
    set internalValue(value: ServiceLevelObjectiveTimeWindow | undefined);
    private _rolling;
    get rolling(): ServiceLevelObjectiveTimeWindowRollingOutputReference;
    putRolling(value: ServiceLevelObjectiveTimeWindowRolling): void;
    get rollingInput(): ServiceLevelObjectiveTimeWindowRolling | undefined;
}
export interface ServiceLevelObjective {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#description ServiceLevel#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#name ServiceLevel#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#target ServiceLevel#target}
    */
    readonly target: number;
    /**
    * time_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#time_window ServiceLevel#time_window}
    */
    readonly timeWindow: ServiceLevelObjectiveTimeWindow;
}
export declare function serviceLevelObjectiveToTerraform(struct?: ServiceLevelObjectiveOutputReference | ServiceLevelObjective): any;
export declare function serviceLevelObjectiveToHclTerraform(struct?: ServiceLevelObjectiveOutputReference | ServiceLevelObjective): any;
export declare class ServiceLevelObjectiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjective | undefined;
    set internalValue(value: ServiceLevelObjective | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _target?;
    get target(): number;
    set target(value: number);
    get targetInput(): number | undefined;
    private _timeWindow;
    get timeWindow(): ServiceLevelObjectiveTimeWindowOutputReference;
    putTimeWindow(value: ServiceLevelObjectiveTimeWindow): void;
    get timeWindowInput(): ServiceLevelObjectiveTimeWindow | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level newrelic_service_level}
*/
export declare class ServiceLevel extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_service_level";
    /**
    * Generates CDKTN code for importing a ServiceLevel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceLevel to import
    * @param importFromId The id of the existing ServiceLevel that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceLevel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/service_level newrelic_service_level} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceLevelConfig
    */
    constructor(scope: Construct, id: string, config: ServiceLevelConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _guid?;
    get guid(): string;
    set guid(value: string);
    get guidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get sliGuid(): string;
    get sliId(): string;
    private _events;
    get events(): ServiceLevelEventsOutputReference;
    putEvents(value: ServiceLevelEvents): void;
    get eventsInput(): ServiceLevelEvents | undefined;
    private _objective;
    get objective(): ServiceLevelObjectiveOutputReference;
    putObjective(value: ServiceLevelObjective): void;
    get objectiveInput(): ServiceLevelObjective | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
