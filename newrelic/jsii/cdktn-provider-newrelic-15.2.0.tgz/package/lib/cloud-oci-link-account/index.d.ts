/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudOciLinkAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where you want to link the OCI account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#account_id CloudOciLinkAccount#account_id}
    */
    readonly accountId?: number;
    /**
    * The New Relic compartment OCID in OCI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#compartment_ocid CloudOciLinkAccount#compartment_ocid}
    */
    readonly compartmentOcid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#id CloudOciLinkAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The OCI ingest secret OCID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#ingest_vault_ocid CloudOciLinkAccount#ingest_vault_ocid}
    */
    readonly ingestVaultOcid?: string;
    /**
    * Specifies the type of integration, such as metrics, logs, or a combination of logs and metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#instrumentation_type CloudOciLinkAccount#instrumentation_type}
    */
    readonly instrumentationType?: string;
    /**
    * The Logging stack identifier for the OCI account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#logging_stack_ocid CloudOciLinkAccount#logging_stack_ocid}
    */
    readonly loggingStackOcid?: string;
    /**
    * The metric stack identifier for the OCI account. This field is only used for updates, not during initial creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#metric_stack_ocid CloudOciLinkAccount#metric_stack_ocid}
    */
    readonly metricStackOcid?: string;
    /**
    * The linked account name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#name CloudOciLinkAccount#name}
    */
    readonly name: string;
    /**
    * The client ID for OCI WIF.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#oci_client_id CloudOciLinkAccount#oci_client_id}
    */
    readonly ociClientId: string;
    /**
    * The client secret for OCI WIF.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#oci_client_secret CloudOciLinkAccount#oci_client_secret}
    */
    readonly ociClientSecret: string;
    /**
    * The OCI domain URL for WIF.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#oci_domain_url CloudOciLinkAccount#oci_domain_url}
    */
    readonly ociDomainUrl: string;
    /**
    * The home region of the tenancy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#oci_home_region CloudOciLinkAccount#oci_home_region}
    */
    readonly ociHomeRegion: string;
    /**
    * The OCI region for the account. This field is only used for updates, not during initial creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#oci_region CloudOciLinkAccount#oci_region}
    */
    readonly ociRegion?: string;
    /**
    * Optional value propagated as the ext_resource_tag claim on the RPST for tag-based scoping in customer IAM policies. Ignored for UPST. Cannot be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#resource_tag CloudOciLinkAccount#resource_tag}
    */
    readonly resourceTag?: string;
    /**
    * The OCI tenant identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#tenant_id CloudOciLinkAccount#tenant_id}
    */
    readonly tenantId: string;
    /**
    * OCI WIF trust type. Allowed: UPST (default), RPST. RPST uses claim-based ephemeral principals; UPST impersonates a service user. Cannot be changed after creation — re-create the linked account to switch trust types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#trust_type CloudOciLinkAccount#trust_type}
    */
    readonly trustType?: string;
    /**
    * The user secret OCID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#user_vault_ocid CloudOciLinkAccount#user_vault_ocid}
    */
    readonly userVaultOcid?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account newrelic_cloud_oci_link_account}
*/
export declare class CloudOciLinkAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_cloud_oci_link_account";
    /**
    * Generates CDKTN code for importing a CloudOciLinkAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudOciLinkAccount to import
    * @param importFromId The id of the existing CloudOciLinkAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudOciLinkAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/resources/cloud_oci_link_account newrelic_cloud_oci_link_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudOciLinkAccountConfig
    */
    constructor(scope: Construct, id: string, config: CloudOciLinkAccountConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _compartmentOcid?;
    get compartmentOcid(): string;
    set compartmentOcid(value: string);
    get compartmentOcidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ingestVaultOcid?;
    get ingestVaultOcid(): string;
    set ingestVaultOcid(value: string);
    resetIngestVaultOcid(): void;
    get ingestVaultOcidInput(): string | undefined;
    private _instrumentationType?;
    get instrumentationType(): string;
    set instrumentationType(value: string);
    resetInstrumentationType(): void;
    get instrumentationTypeInput(): string | undefined;
    private _loggingStackOcid?;
    get loggingStackOcid(): string;
    set loggingStackOcid(value: string);
    resetLoggingStackOcid(): void;
    get loggingStackOcidInput(): string | undefined;
    private _metricStackOcid?;
    get metricStackOcid(): string;
    set metricStackOcid(value: string);
    resetMetricStackOcid(): void;
    get metricStackOcidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ociClientId?;
    get ociClientId(): string;
    set ociClientId(value: string);
    get ociClientIdInput(): string | undefined;
    private _ociClientSecret?;
    get ociClientSecret(): string;
    set ociClientSecret(value: string);
    get ociClientSecretInput(): string | undefined;
    private _ociDomainUrl?;
    get ociDomainUrl(): string;
    set ociDomainUrl(value: string);
    get ociDomainUrlInput(): string | undefined;
    private _ociHomeRegion?;
    get ociHomeRegion(): string;
    set ociHomeRegion(value: string);
    get ociHomeRegionInput(): string | undefined;
    private _ociRegion?;
    get ociRegion(): string;
    set ociRegion(value: string);
    resetOciRegion(): void;
    get ociRegionInput(): string | undefined;
    private _resourceTag?;
    get resourceTag(): string;
    set resourceTag(value: string);
    resetResourceTag(): void;
    get resourceTagInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
    private _trustType?;
    get trustType(): string;
    set trustType(value: string);
    resetTrustType(): void;
    get trustTypeInput(): string | undefined;
    private _userVaultOcid?;
    get userVaultOcid(): string;
    set userVaultOcid(value: string);
    resetUserVaultOcid(): void;
    get userVaultOcidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
