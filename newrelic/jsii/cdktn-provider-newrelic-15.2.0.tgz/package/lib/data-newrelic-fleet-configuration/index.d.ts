/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicFleetConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The GUID of the fleet configuration entity. Returns the content of the latest version. Populated automatically when looking up by version_entity_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/data-sources/fleet_configuration#configuration_id DataNewrelicFleetConfiguration#configuration_id}
    */
    readonly configurationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/data-sources/fleet_configuration#id DataNewrelicFleetConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the fleet configuration. The first matching configuration is returned. Returns the content of its latest version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/data-sources/fleet_configuration#name DataNewrelicFleetConfiguration#name}
    */
    readonly name?: string;
    /**
    * The organization ID. Resolved automatically from the provider when omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/data-sources/fleet_configuration#organization_id DataNewrelicFleetConfiguration#organization_id}
    */
    readonly organizationId?: string;
    /**
    * The GUID of a specific configuration version entity. Returns the content of that exact version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/data-sources/fleet_configuration#version_entity_id DataNewrelicFleetConfiguration#version_entity_id}
    */
    readonly versionEntityId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/data-sources/fleet_configuration newrelic_fleet_configuration}
*/
export declare class DataNewrelicFleetConfiguration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_fleet_configuration";
    /**
    * Generates CDKTN code for importing a DataNewrelicFleetConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicFleetConfiguration to import
    * @param importFromId The id of the existing DataNewrelicFleetConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/data-sources/fleet_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicFleetConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.92.0/docs/data-sources/fleet_configuration newrelic_fleet_configuration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicFleetConfigurationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataNewrelicFleetConfigurationConfig);
    get configurationContent(): string;
    private _configurationId?;
    get configurationId(): string;
    set configurationId(value: string);
    resetConfigurationId(): void;
    get configurationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get latestVersionEntityId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    resetOrganizationId(): void;
    get organizationIdInput(): string | undefined;
    private _versionEntityId?;
    get versionEntityId(): string;
    set versionEntityId(value: string);
    resetVersionEntityId(): void;
    get versionEntityIdInput(): string | undefined;
    get versionEntityIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
