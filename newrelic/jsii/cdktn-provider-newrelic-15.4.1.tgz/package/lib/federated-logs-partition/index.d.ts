/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FederatedLogsPartitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where the federated logs partition will live. Defaults to the provider's account_id. Changing this after creation is rejected by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#account_id FederatedLogsPartition#account_id}
    */
    readonly accountId?: number;
    /**
    * Whether the partition is active. When false, log routing to this partition is turned off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#active FederatedLogsPartition#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * The description of the partition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#description FederatedLogsPartition#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#id FederatedLogsPartition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the partition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#name FederatedLogsPartition#name}
    */
    readonly name: string;
    /**
    * The ID of the federated log setup this partition belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#setup_id FederatedLogsPartition#setup_id}
    */
    readonly setupId: string;
    /**
    * data_retention_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#data_retention_policy FederatedLogsPartition#data_retention_policy}
    */
    readonly dataRetentionPolicy?: FederatedLogsPartitionDataRetentionPolicy;
    /**
    * forwarder_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#forwarder_configuration FederatedLogsPartition#forwarder_configuration}
    */
    readonly forwarderConfiguration?: FederatedLogsPartitionForwarderConfiguration;
    /**
    * storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#storage FederatedLogsPartition#storage}
    */
    readonly storage: FederatedLogsPartitionStorage;
}
export interface FederatedLogsPartitionHealthCheckEnd2EndDataFlow {
}
export declare function federatedLogsPartitionHealthCheckEnd2EndDataFlowToTerraform(struct?: FederatedLogsPartitionHealthCheckEnd2EndDataFlow): any;
export declare function federatedLogsPartitionHealthCheckEnd2EndDataFlowToHclTerraform(struct?: FederatedLogsPartitionHealthCheckEnd2EndDataFlow): any;
export declare class FederatedLogsPartitionHealthCheckEnd2EndDataFlowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FederatedLogsPartitionHealthCheckEnd2EndDataFlow | undefined;
    set internalValue(value: FederatedLogsPartitionHealthCheckEnd2EndDataFlow | undefined);
    get lastUpdatedAt(): string;
    get message(): string;
    get status(): string;
}
export declare class FederatedLogsPartitionHealthCheckEnd2EndDataFlowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FederatedLogsPartitionHealthCheckEnd2EndDataFlowOutputReference;
}
export interface FederatedLogsPartitionHealthCheckQueryConnection {
}
export declare function federatedLogsPartitionHealthCheckQueryConnectionToTerraform(struct?: FederatedLogsPartitionHealthCheckQueryConnection): any;
export declare function federatedLogsPartitionHealthCheckQueryConnectionToHclTerraform(struct?: FederatedLogsPartitionHealthCheckQueryConnection): any;
export declare class FederatedLogsPartitionHealthCheckQueryConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FederatedLogsPartitionHealthCheckQueryConnection | undefined;
    set internalValue(value: FederatedLogsPartitionHealthCheckQueryConnection | undefined);
    get lastUpdatedAt(): string;
    get message(): string;
    get status(): string;
}
export declare class FederatedLogsPartitionHealthCheckQueryConnectionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FederatedLogsPartitionHealthCheckQueryConnectionOutputReference;
}
export interface FederatedLogsPartitionHealthCheck {
}
export declare function federatedLogsPartitionHealthCheckToTerraform(struct?: FederatedLogsPartitionHealthCheck): any;
export declare function federatedLogsPartitionHealthCheckToHclTerraform(struct?: FederatedLogsPartitionHealthCheck): any;
export declare class FederatedLogsPartitionHealthCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FederatedLogsPartitionHealthCheck | undefined;
    set internalValue(value: FederatedLogsPartitionHealthCheck | undefined);
    private _end2EndDataFlow;
    get end2EndDataFlow(): FederatedLogsPartitionHealthCheckEnd2EndDataFlowList;
    get lastUpdatedAt(): string;
    private _queryConnection;
    get queryConnection(): FederatedLogsPartitionHealthCheckQueryConnectionList;
}
export declare class FederatedLogsPartitionHealthCheckList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FederatedLogsPartitionHealthCheckOutputReference;
}
export interface FederatedLogsPartitionLifecycleStatus {
}
export declare function federatedLogsPartitionLifecycleStatusToTerraform(struct?: FederatedLogsPartitionLifecycleStatus): any;
export declare function federatedLogsPartitionLifecycleStatusToHclTerraform(struct?: FederatedLogsPartitionLifecycleStatus): any;
export declare class FederatedLogsPartitionLifecycleStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FederatedLogsPartitionLifecycleStatus | undefined;
    set internalValue(value: FederatedLogsPartitionLifecycleStatus | undefined);
    get lastUpdatedAt(): string;
    get message(): string;
    get status(): string;
}
export declare class FederatedLogsPartitionLifecycleStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FederatedLogsPartitionLifecycleStatusOutputReference;
}
export interface FederatedLogsPartitionDataRetentionPolicy {
    /**
    * The duration value for retention.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#duration FederatedLogsPartition#duration}
    */
    readonly duration: number;
    /**
    * The time unit for the retention duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#unit FederatedLogsPartition#unit}
    */
    readonly unit: string;
}
export declare function federatedLogsPartitionDataRetentionPolicyToTerraform(struct?: FederatedLogsPartitionDataRetentionPolicyOutputReference | FederatedLogsPartitionDataRetentionPolicy): any;
export declare function federatedLogsPartitionDataRetentionPolicyToHclTerraform(struct?: FederatedLogsPartitionDataRetentionPolicyOutputReference | FederatedLogsPartitionDataRetentionPolicy): any;
export declare class FederatedLogsPartitionDataRetentionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsPartitionDataRetentionPolicy | undefined;
    set internalValue(value: FederatedLogsPartitionDataRetentionPolicy | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    get durationInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
}
export interface FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRule {
    /**
    * OTTL expression for routing logs to this partition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#expression FederatedLogsPartition#expression}
    */
    readonly expression: string;
}
export declare function federatedLogsPartitionForwarderConfigurationPipelineControlPartitionRuleToTerraform(struct?: FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRuleOutputReference | FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRule): any;
export declare function federatedLogsPartitionForwarderConfigurationPipelineControlPartitionRuleToHclTerraform(struct?: FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRuleOutputReference | FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRule): any;
export declare class FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRule | undefined;
    set internalValue(value: FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRule | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface FederatedLogsPartitionForwarderConfigurationPipelineControl {
    /**
    * partition_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#partition_rule FederatedLogsPartition#partition_rule}
    */
    readonly partitionRule?: FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRule;
}
export declare function federatedLogsPartitionForwarderConfigurationPipelineControlToTerraform(struct?: FederatedLogsPartitionForwarderConfigurationPipelineControlOutputReference | FederatedLogsPartitionForwarderConfigurationPipelineControl): any;
export declare function federatedLogsPartitionForwarderConfigurationPipelineControlToHclTerraform(struct?: FederatedLogsPartitionForwarderConfigurationPipelineControlOutputReference | FederatedLogsPartitionForwarderConfigurationPipelineControl): any;
export declare class FederatedLogsPartitionForwarderConfigurationPipelineControlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsPartitionForwarderConfigurationPipelineControl | undefined;
    set internalValue(value: FederatedLogsPartitionForwarderConfigurationPipelineControl | undefined);
    private _partitionRule;
    get partitionRule(): FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRuleOutputReference;
    putPartitionRule(value: FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRule): void;
    resetPartitionRule(): void;
    get partitionRuleInput(): FederatedLogsPartitionForwarderConfigurationPipelineControlPartitionRule | undefined;
}
export interface FederatedLogsPartitionForwarderConfiguration {
    /**
    * The type of forwarder. Must match the parent setup's forwarder type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#type FederatedLogsPartition#type}
    */
    readonly type: string;
    /**
    * pipeline_control block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#pipeline_control FederatedLogsPartition#pipeline_control}
    */
    readonly pipelineControl?: FederatedLogsPartitionForwarderConfigurationPipelineControl;
}
export declare function federatedLogsPartitionForwarderConfigurationToTerraform(struct?: FederatedLogsPartitionForwarderConfigurationOutputReference | FederatedLogsPartitionForwarderConfiguration): any;
export declare function federatedLogsPartitionForwarderConfigurationToHclTerraform(struct?: FederatedLogsPartitionForwarderConfigurationOutputReference | FederatedLogsPartitionForwarderConfiguration): any;
export declare class FederatedLogsPartitionForwarderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsPartitionForwarderConfiguration | undefined;
    set internalValue(value: FederatedLogsPartitionForwarderConfiguration | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _pipelineControl;
    get pipelineControl(): FederatedLogsPartitionForwarderConfigurationPipelineControlOutputReference;
    putPipelineControl(value: FederatedLogsPartitionForwarderConfigurationPipelineControl): void;
    resetPipelineControl(): void;
    get pipelineControlInput(): FederatedLogsPartitionForwarderConfigurationPipelineControl | undefined;
}
export interface FederatedLogsPartitionStorage {
    /**
    * The URI location of the partition in object storage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#data_location_uri FederatedLogsPartition#data_location_uri}
    */
    readonly dataLocationUri: string;
    /**
    * The table name associated with the partition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#table FederatedLogsPartition#table}
    */
    readonly table: string;
}
export declare function federatedLogsPartitionStorageToTerraform(struct?: FederatedLogsPartitionStorageOutputReference | FederatedLogsPartitionStorage): any;
export declare function federatedLogsPartitionStorageToHclTerraform(struct?: FederatedLogsPartitionStorageOutputReference | FederatedLogsPartitionStorage): any;
export declare class FederatedLogsPartitionStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FederatedLogsPartitionStorage | undefined;
    set internalValue(value: FederatedLogsPartitionStorage | undefined);
    private _dataLocationUri?;
    get dataLocationUri(): string;
    set dataLocationUri(value: string);
    get dataLocationUriInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    get tableInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition newrelic_federated_logs_partition}
*/
export declare class FederatedLogsPartition extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_federated_logs_partition";
    /**
    * Generates CDKTN code for importing a FederatedLogsPartition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FederatedLogsPartition to import
    * @param importFromId The id of the existing FederatedLogsPartition that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FederatedLogsPartition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.2/docs/resources/federated_logs_partition newrelic_federated_logs_partition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FederatedLogsPartitionConfig
    */
    constructor(scope: Construct, id: string, config: FederatedLogsPartitionConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _healthCheck;
    get healthCheck(): FederatedLogsPartitionHealthCheckList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isDefault(): cdktn.IResolvable;
    private _lifecycleStatus;
    get lifecycleStatus(): FederatedLogsPartitionLifecycleStatusList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _setupId?;
    get setupId(): string;
    set setupId(value: string);
    get setupIdInput(): string | undefined;
    get updatedAt(): string;
    private _dataRetentionPolicy;
    get dataRetentionPolicy(): FederatedLogsPartitionDataRetentionPolicyOutputReference;
    putDataRetentionPolicy(value: FederatedLogsPartitionDataRetentionPolicy): void;
    resetDataRetentionPolicy(): void;
    get dataRetentionPolicyInput(): FederatedLogsPartitionDataRetentionPolicy | undefined;
    private _forwarderConfiguration;
    get forwarderConfiguration(): FederatedLogsPartitionForwarderConfigurationOutputReference;
    putForwarderConfiguration(value: FederatedLogsPartitionForwarderConfiguration): void;
    resetForwarderConfiguration(): void;
    get forwarderConfigurationInput(): FederatedLogsPartitionForwarderConfiguration | undefined;
    private _storage;
    get storage(): FederatedLogsPartitionStorageOutputReference;
    putStorage(value: FederatedLogsPartitionStorage): void;
    get storageInput(): FederatedLogsPartitionStorage | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
