/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NotificationDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account ID under which to put the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#account_id NotificationDestination#account_id}
    */
    readonly accountId?: number;
    /**
    * Indicates whether the destination is active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#active NotificationDestination#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#id NotificationDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * (Required) The name of the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#name NotificationDestination#name}
    */
    readonly name: string;
    /**
    * (Required) The type of the destination. One of: (WEBHOOK, EMAIL, SERVICE_NOW, SERVICE_NOW_APP, PAGERDUTY_ACCOUNT_INTEGRATION, PAGERDUTY_SERVICE_INTEGRATION, JIRA, SLACK, SLACK_COLLABORATION, SLACK_LEGACY, MOBILE_PUSH, EVENT_BRIDGE, MICROSOFT_TEAMS, WORKFLOW_AUTOMATION).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#type NotificationDestination#type}
    */
    readonly type: string;
    /**
    * auth_basic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#auth_basic NotificationDestination#auth_basic}
    */
    readonly authBasic?: NotificationDestinationAuthBasic;
    /**
    * auth_custom_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#auth_custom_header NotificationDestination#auth_custom_header}
    */
    readonly authCustomHeader?: NotificationDestinationAuthCustomHeader[] | cdktn.IResolvable;
    /**
    * auth_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#auth_token NotificationDestination#auth_token}
    */
    readonly authToken?: NotificationDestinationAuthToken;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#property NotificationDestination#property}
    */
    readonly property: NotificationDestinationProperty[] | cdktn.IResolvable;
    /**
    * secure_url block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#secure_url NotificationDestination#secure_url}
    */
    readonly secureUrl?: NotificationDestinationSecureUrl;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#timeouts NotificationDestination#timeouts}
    */
    readonly timeouts?: NotificationDestinationTimeouts;
}
export interface NotificationDestinationAuthBasic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#password NotificationDestination#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#user NotificationDestination#user}
    */
    readonly user: string;
}
export declare function notificationDestinationAuthBasicToTerraform(struct?: NotificationDestinationAuthBasicOutputReference | NotificationDestinationAuthBasic): any;
export declare function notificationDestinationAuthBasicToHclTerraform(struct?: NotificationDestinationAuthBasicOutputReference | NotificationDestinationAuthBasic): any;
export declare class NotificationDestinationAuthBasicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationAuthBasic | undefined;
    set internalValue(value: NotificationDestinationAuthBasic | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    get userInput(): string | undefined;
}
export interface NotificationDestinationAuthCustomHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#key NotificationDestination#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#value NotificationDestination#value}
    */
    readonly value: string;
}
export declare function notificationDestinationAuthCustomHeaderToTerraform(struct?: NotificationDestinationAuthCustomHeader | cdktn.IResolvable): any;
export declare function notificationDestinationAuthCustomHeaderToHclTerraform(struct?: NotificationDestinationAuthCustomHeader | cdktn.IResolvable): any;
export declare class NotificationDestinationAuthCustomHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationDestinationAuthCustomHeader | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationDestinationAuthCustomHeader | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class NotificationDestinationAuthCustomHeaderList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NotificationDestinationAuthCustomHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationDestinationAuthCustomHeaderOutputReference;
}
export interface NotificationDestinationAuthToken {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#prefix NotificationDestination#prefix}
    */
    readonly prefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#token NotificationDestination#token}
    */
    readonly token: string;
}
export declare function notificationDestinationAuthTokenToTerraform(struct?: NotificationDestinationAuthTokenOutputReference | NotificationDestinationAuthToken): any;
export declare function notificationDestinationAuthTokenToHclTerraform(struct?: NotificationDestinationAuthTokenOutputReference | NotificationDestinationAuthToken): any;
export declare class NotificationDestinationAuthTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationAuthToken | undefined;
    set internalValue(value: NotificationDestinationAuthToken | undefined);
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    get tokenInput(): string | undefined;
}
export interface NotificationDestinationProperty {
    /**
    * Notification property display key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#display_value NotificationDestination#display_value}
    */
    readonly displayValue?: string;
    /**
    * Notification property key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#key NotificationDestination#key}
    */
    readonly key: string;
    /**
    * Notification property label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#label NotificationDestination#label}
    */
    readonly label?: string;
    /**
    * Notification property value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#value NotificationDestination#value}
    */
    readonly value: string;
}
export declare function notificationDestinationPropertyToTerraform(struct?: NotificationDestinationProperty | cdktn.IResolvable): any;
export declare function notificationDestinationPropertyToHclTerraform(struct?: NotificationDestinationProperty | cdktn.IResolvable): any;
export declare class NotificationDestinationPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationDestinationProperty | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationDestinationProperty | cdktn.IResolvable | undefined);
    private _displayValue?;
    get displayValue(): string;
    set displayValue(value: string);
    resetDisplayValue(): void;
    get displayValueInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class NotificationDestinationPropertyList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NotificationDestinationProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationDestinationPropertyOutputReference;
}
export interface NotificationDestinationSecureUrl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#prefix NotificationDestination#prefix}
    */
    readonly prefix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#secure_suffix NotificationDestination#secure_suffix}
    */
    readonly secureSuffix: string;
}
export declare function notificationDestinationSecureUrlToTerraform(struct?: NotificationDestinationSecureUrlOutputReference | NotificationDestinationSecureUrl): any;
export declare function notificationDestinationSecureUrlToHclTerraform(struct?: NotificationDestinationSecureUrlOutputReference | NotificationDestinationSecureUrl): any;
export declare class NotificationDestinationSecureUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationSecureUrl | undefined;
    set internalValue(value: NotificationDestinationSecureUrl | undefined);
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
    private _secureSuffix?;
    get secureSuffix(): string;
    set secureSuffix(value: string);
    get secureSuffixInput(): string | undefined;
}
export interface NotificationDestinationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#create NotificationDestination#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#update NotificationDestination#update}
    */
    readonly update?: string;
}
export declare function notificationDestinationTimeoutsToTerraform(struct?: NotificationDestinationTimeouts | cdktn.IResolvable): any;
export declare function notificationDestinationTimeoutsToHclTerraform(struct?: NotificationDestinationTimeouts | cdktn.IResolvable): any;
export declare class NotificationDestinationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationDestinationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination newrelic_notification_destination}
*/
export declare class NotificationDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_notification_destination";
    /**
    * Generates CDKTN code for importing a NotificationDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NotificationDestination to import
    * @param importFromId The id of the existing NotificationDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NotificationDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.81.0/docs/resources/notification_destination newrelic_notification_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotificationDestinationConfig
    */
    constructor(scope: Construct, id: string, config: NotificationDestinationConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastSent(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _authBasic;
    get authBasic(): NotificationDestinationAuthBasicOutputReference;
    putAuthBasic(value: NotificationDestinationAuthBasic): void;
    resetAuthBasic(): void;
    get authBasicInput(): NotificationDestinationAuthBasic | undefined;
    private _authCustomHeader;
    get authCustomHeader(): NotificationDestinationAuthCustomHeaderList;
    putAuthCustomHeader(value: NotificationDestinationAuthCustomHeader[] | cdktn.IResolvable): void;
    resetAuthCustomHeader(): void;
    get authCustomHeaderInput(): cdktn.IResolvable | NotificationDestinationAuthCustomHeader[] | undefined;
    private _authToken;
    get authToken(): NotificationDestinationAuthTokenOutputReference;
    putAuthToken(value: NotificationDestinationAuthToken): void;
    resetAuthToken(): void;
    get authTokenInput(): NotificationDestinationAuthToken | undefined;
    private _property;
    get property(): NotificationDestinationPropertyList;
    putProperty(value: NotificationDestinationProperty[] | cdktn.IResolvable): void;
    get propertyInput(): cdktn.IResolvable | NotificationDestinationProperty[] | undefined;
    private _secureUrl;
    get secureUrl(): NotificationDestinationSecureUrlOutputReference;
    putSecureUrl(value: NotificationDestinationSecureUrl): void;
    resetSecureUrl(): void;
    get secureUrlInput(): NotificationDestinationSecureUrl | undefined;
    private _timeouts;
    get timeouts(): NotificationDestinationTimeoutsOutputReference;
    putTimeouts(value: NotificationDestinationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | NotificationDestinationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
