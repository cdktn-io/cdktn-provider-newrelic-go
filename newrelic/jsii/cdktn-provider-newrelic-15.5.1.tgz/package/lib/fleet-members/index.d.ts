/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FleetMembersConfig extends cdktn.TerraformMetaArguments {
    /**
    * The GUID of the fleet to manage entity assignments for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/fleet_members#fleet_id FleetMembers#fleet_id}
    */
    readonly fleetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/fleet_members#id FleetMembers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ring block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/fleet_members#ring FleetMembers#ring}
    */
    readonly ring: FleetMembersRing[] | cdktn.IResolvable;
}
export interface FleetMembersRing {
    /**
    * Ordered list of entity GUIDs to assign to this ring. Only the entities listed here are tracked by Terraform; any other entities already in the ring through other means are not affected. Removing a GUID from this list will remove that entity from the fleet ring on the next apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/fleet_members#entity_ids FleetMembers#entity_ids}
    */
    readonly entityIds: string[];
    /**
    * The name of the ring as configured on the fleet (e.g. "default", "canary").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/fleet_members#name FleetMembers#name}
    */
    readonly name: string;
}
export declare function fleetMembersRingToTerraform(struct?: FleetMembersRing | cdktn.IResolvable): any;
export declare function fleetMembersRingToHclTerraform(struct?: FleetMembersRing | cdktn.IResolvable): any;
export declare class FleetMembersRingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FleetMembersRing | cdktn.IResolvable | undefined;
    set internalValue(value: FleetMembersRing | cdktn.IResolvable | undefined);
    private _entityIds?;
    get entityIds(): string[];
    set entityIds(value: string[]);
    get entityIdsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class FleetMembersRingList extends cdktn.ComplexList {
    internalValue?: FleetMembersRing[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FleetMembersRingOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/fleet_members newrelic_fleet_members}
*/
export declare class FleetMembers extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_fleet_members";
    /**
    * Generates CDKTN code for importing a FleetMembers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FleetMembers to import
    * @param importFromId The id of the existing FleetMembers that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/fleet_members#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FleetMembers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/fleet_members newrelic_fleet_members} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FleetMembersConfig
    */
    constructor(scope: Construct, id: string, config: FleetMembersConfig);
    private _fleetId?;
    get fleetId(): string;
    set fleetId(value: string);
    get fleetIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ring;
    get ring(): FleetMembersRingList;
    putRing(value: FleetMembersRing[] | cdktn.IResolvable): void;
    get ringInput(): cdktn.IResolvable | FleetMembersRing[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
