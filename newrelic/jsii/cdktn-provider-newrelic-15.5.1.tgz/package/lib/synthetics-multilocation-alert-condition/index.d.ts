/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsMultilocationAlertConditionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Set whether to enable the alert condition. Defaults to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#enabled SyntheticsMultilocationAlertCondition#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The GUIDs of the Synthetics monitors to alert on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#entities SyntheticsMultilocationAlertCondition#entities}
    */
    readonly entities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#id SyntheticsMultilocationAlertCondition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The title of this condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#name SyntheticsMultilocationAlertCondition#name}
    */
    readonly name: string;
    /**
    * The ID of the policy where this condition will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#policy_id SyntheticsMultilocationAlertCondition#policy_id}
    */
    readonly policyId: number;
    /**
    * Runbook URL to display in notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#runbook_url SyntheticsMultilocationAlertCondition#runbook_url}
    */
    readonly runbookUrl?: string;
    /**
    * Sets a time limit, in seconds, that will automatically force-close a long-lasting incident after the time limit you select.  Must be in the range of 300 to 2592000 (inclusive)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#violation_time_limit_seconds SyntheticsMultilocationAlertCondition#violation_time_limit_seconds}
    */
    readonly violationTimeLimitSeconds?: number;
    /**
    * critical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#critical SyntheticsMultilocationAlertCondition#critical}
    */
    readonly critical: SyntheticsMultilocationAlertConditionCritical;
    /**
    * warning block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#warning SyntheticsMultilocationAlertCondition#warning}
    */
    readonly warning?: SyntheticsMultilocationAlertConditionWarning;
}
export interface SyntheticsMultilocationAlertConditionCritical {
    /**
    * The minimum number of monitor locations that must be concurrently failing before an incident is opened.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#threshold SyntheticsMultilocationAlertCondition#threshold}
    */
    readonly threshold: number;
}
export declare function syntheticsMultilocationAlertConditionCriticalToTerraform(struct?: SyntheticsMultilocationAlertConditionCriticalOutputReference | SyntheticsMultilocationAlertConditionCritical): any;
export declare function syntheticsMultilocationAlertConditionCriticalToHclTerraform(struct?: SyntheticsMultilocationAlertConditionCriticalOutputReference | SyntheticsMultilocationAlertConditionCritical): any;
export declare class SyntheticsMultilocationAlertConditionCriticalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsMultilocationAlertConditionCritical | undefined;
    set internalValue(value: SyntheticsMultilocationAlertConditionCritical | undefined);
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
}
export interface SyntheticsMultilocationAlertConditionWarning {
    /**
    * The minimum number of monitor locations that must be concurrently failing before an incident is opened.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#threshold SyntheticsMultilocationAlertCondition#threshold}
    */
    readonly threshold: number;
}
export declare function syntheticsMultilocationAlertConditionWarningToTerraform(struct?: SyntheticsMultilocationAlertConditionWarningOutputReference | SyntheticsMultilocationAlertConditionWarning): any;
export declare function syntheticsMultilocationAlertConditionWarningToHclTerraform(struct?: SyntheticsMultilocationAlertConditionWarningOutputReference | SyntheticsMultilocationAlertConditionWarning): any;
export declare class SyntheticsMultilocationAlertConditionWarningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsMultilocationAlertConditionWarning | undefined;
    set internalValue(value: SyntheticsMultilocationAlertConditionWarning | undefined);
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition newrelic_synthetics_multilocation_alert_condition}
*/
export declare class SyntheticsMultilocationAlertCondition extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_synthetics_multilocation_alert_condition";
    /**
    * Generates CDKTN code for importing a SyntheticsMultilocationAlertCondition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsMultilocationAlertCondition to import
    * @param importFromId The id of the existing SyntheticsMultilocationAlertCondition that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsMultilocationAlertCondition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/resources/synthetics_multilocation_alert_condition newrelic_synthetics_multilocation_alert_condition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsMultilocationAlertConditionConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsMultilocationAlertConditionConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _entities?;
    get entities(): string[];
    set entities(value: string[]);
    get entitiesInput(): string[] | undefined;
    get entityGuid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyId?;
    get policyId(): number;
    set policyId(value: number);
    get policyIdInput(): number | undefined;
    private _runbookUrl?;
    get runbookUrl(): string;
    set runbookUrl(value: string);
    resetRunbookUrl(): void;
    get runbookUrlInput(): string | undefined;
    private _violationTimeLimitSeconds?;
    get violationTimeLimitSeconds(): number;
    set violationTimeLimitSeconds(value: number);
    resetViolationTimeLimitSeconds(): void;
    get violationTimeLimitSecondsInput(): number | undefined;
    private _critical;
    get critical(): SyntheticsMultilocationAlertConditionCriticalOutputReference;
    putCritical(value: SyntheticsMultilocationAlertConditionCritical): void;
    get criticalInput(): SyntheticsMultilocationAlertConditionCritical | undefined;
    private _warning;
    get warning(): SyntheticsMultilocationAlertConditionWarningOutputReference;
    putWarning(value: SyntheticsMultilocationAlertConditionWarning): void;
    resetWarning(): void;
    get warningInput(): SyntheticsMultilocationAlertConditionWarning | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
