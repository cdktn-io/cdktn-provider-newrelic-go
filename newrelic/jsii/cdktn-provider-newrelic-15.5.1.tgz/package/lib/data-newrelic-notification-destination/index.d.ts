/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicNotificationDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account ID under which the particular destination belong to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#account_id DataNewrelicNotificationDestination#account_id}
    */
    readonly accountId?: number;
    /**
    * The exact name of the destination. Uses an exact match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#exact_name DataNewrelicNotificationDestination#exact_name}
    */
    readonly exactName?: string;
    /**
    * The ID of the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#id DataNewrelicNotificationDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the destination. Uses a contains match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#name DataNewrelicNotificationDestination#name}
    */
    readonly name?: string;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#scope DataNewrelicNotificationDestination#scope}
    */
    readonly scope?: DataNewrelicNotificationDestinationScope;
    /**
    * secure_url block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#secure_url DataNewrelicNotificationDestination#secure_url}
    */
    readonly secureUrl?: DataNewrelicNotificationDestinationSecureUrl[] | cdktn.IResolvable;
}
export interface DataNewrelicNotificationDestinationProperty {
}
export declare function dataNewrelicNotificationDestinationPropertyToTerraform(struct?: DataNewrelicNotificationDestinationProperty): any;
export declare function dataNewrelicNotificationDestinationPropertyToHclTerraform(struct?: DataNewrelicNotificationDestinationProperty): any;
export declare class DataNewrelicNotificationDestinationPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNewrelicNotificationDestinationProperty | undefined;
    set internalValue(value: DataNewrelicNotificationDestinationProperty | undefined);
    get displayValue(): string;
    get key(): string;
    get label(): string;
    get value(): string;
}
export declare class DataNewrelicNotificationDestinationPropertyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNewrelicNotificationDestinationPropertyOutputReference;
}
export interface DataNewrelicNotificationDestinationScope {
    /**
    * The ID of the Scope (Organization UUID for ORGANIZATION scope, Account ID for ACCOUNT scope)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#id DataNewrelicNotificationDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * (Required) The scope type of the destination. One of: (ACCOUNT, ORGANIZATION).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#type DataNewrelicNotificationDestination#type}
    */
    readonly type: string;
}
export declare function dataNewrelicNotificationDestinationScopeToTerraform(struct?: DataNewrelicNotificationDestinationScopeOutputReference | DataNewrelicNotificationDestinationScope): any;
export declare function dataNewrelicNotificationDestinationScopeToHclTerraform(struct?: DataNewrelicNotificationDestinationScopeOutputReference | DataNewrelicNotificationDestinationScope): any;
export declare class DataNewrelicNotificationDestinationScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataNewrelicNotificationDestinationScope | undefined;
    set internalValue(value: DataNewrelicNotificationDestinationScope | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface DataNewrelicNotificationDestinationSecureUrl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#prefix DataNewrelicNotificationDestination#prefix}
    */
    readonly prefix: string;
}
export declare function dataNewrelicNotificationDestinationSecureUrlToTerraform(struct?: DataNewrelicNotificationDestinationSecureUrl | cdktn.IResolvable): any;
export declare function dataNewrelicNotificationDestinationSecureUrlToHclTerraform(struct?: DataNewrelicNotificationDestinationSecureUrl | cdktn.IResolvable): any;
export declare class DataNewrelicNotificationDestinationSecureUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNewrelicNotificationDestinationSecureUrl | cdktn.IResolvable | undefined;
    set internalValue(value: DataNewrelicNotificationDestinationSecureUrl | cdktn.IResolvable | undefined);
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
}
export declare class DataNewrelicNotificationDestinationSecureUrlList extends cdktn.ComplexList {
    internalValue?: DataNewrelicNotificationDestinationSecureUrl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNewrelicNotificationDestinationSecureUrlOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination newrelic_notification_destination}
*/
export declare class DataNewrelicNotificationDestination extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_notification_destination";
    /**
    * Generates CDKTN code for importing a DataNewrelicNotificationDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicNotificationDestination to import
    * @param importFromId The id of the existing DataNewrelicNotificationDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicNotificationDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.1/docs/data-sources/notification_destination newrelic_notification_destination} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicNotificationDestinationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataNewrelicNotificationDestinationConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    get active(): cdktn.IResolvable;
    private _exactName?;
    get exactName(): string;
    set exactName(value: string);
    resetExactName(): void;
    get exactNameInput(): string | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _property;
    get property(): DataNewrelicNotificationDestinationPropertyList;
    get status(): string;
    get type(): string;
    private _scope;
    get scope(): DataNewrelicNotificationDestinationScopeOutputReference;
    putScope(value: DataNewrelicNotificationDestinationScope): void;
    resetScope(): void;
    get scopeInput(): DataNewrelicNotificationDestinationScope | undefined;
    private _secureUrl;
    get secureUrl(): DataNewrelicNotificationDestinationSecureUrlList;
    putSecureUrl(value: DataNewrelicNotificationDestinationSecureUrl[] | cdktn.IResolvable): void;
    resetSecureUrl(): void;
    get secureUrlInput(): cdktn.IResolvable | DataNewrelicNotificationDestinationSecureUrl[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
