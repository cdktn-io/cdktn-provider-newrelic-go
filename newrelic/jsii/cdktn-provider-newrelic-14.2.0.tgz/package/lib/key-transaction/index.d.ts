/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KeyTransactionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The acceptable amount of the time spent in the backend before customers get frustrated (Apdex target)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.82.0/docs/resources/key_transaction#apdex_index KeyTransaction#apdex_index}
    */
    readonly apdexIndex: number;
    /**
    * The GUID of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.82.0/docs/resources/key_transaction#application_guid KeyTransaction#application_guid}
    */
    readonly applicationGuid: string;
    /**
    * The acceptable amount of time for rendering a page in a browser before customers get frustrated (browser Apdex target).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.82.0/docs/resources/key_transaction#browser_apdex_target KeyTransaction#browser_apdex_target}
    */
    readonly browserApdexTarget: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.82.0/docs/resources/key_transaction#id KeyTransaction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the metric underlying this key transaction
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.82.0/docs/resources/key_transaction#metric_name KeyTransaction#metric_name}
    */
    readonly metricName: string;
    /**
    * The name of the key transaction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.82.0/docs/resources/key_transaction#name KeyTransaction#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.82.0/docs/resources/key_transaction newrelic_key_transaction}
*/
export declare class KeyTransaction extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_key_transaction";
    /**
    * Generates CDKTN code for importing a KeyTransaction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KeyTransaction to import
    * @param importFromId The id of the existing KeyTransaction that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.82.0/docs/resources/key_transaction#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KeyTransaction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.82.0/docs/resources/key_transaction newrelic_key_transaction} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KeyTransactionConfig
    */
    constructor(scope: Construct, id: string, config: KeyTransactionConfig);
    private _apdexIndex?;
    get apdexIndex(): number;
    set apdexIndex(value: number);
    get apdexIndexInput(): number | undefined;
    private _applicationGuid?;
    get applicationGuid(): string;
    set applicationGuid(value: string);
    get applicationGuidInput(): string | undefined;
    private _browserApdexTarget?;
    get browserApdexTarget(): number;
    set browserApdexTarget(value: number);
    get browserApdexTargetInput(): number | undefined;
    get domain(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    get metricNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
