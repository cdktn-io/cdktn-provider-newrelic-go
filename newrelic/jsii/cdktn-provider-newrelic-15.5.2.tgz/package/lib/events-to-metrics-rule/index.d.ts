/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EventsToMetricsRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account with the event and where the metrics will be put.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/events_to_metrics_rule#account_id EventsToMetricsRule#account_id}
    */
    readonly accountId?: number;
    /**
    * Provides additional information about the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/events_to_metrics_rule#description EventsToMetricsRule#description}
    */
    readonly description?: string;
    /**
    * True means this rule is enabled. False means the rule is currently not creating metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/events_to_metrics_rule#enabled EventsToMetricsRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/events_to_metrics_rule#id EventsToMetricsRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the rule. This must be unique within an account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/events_to_metrics_rule#name EventsToMetricsRule#name}
    */
    readonly name: string;
    /**
    * Explains how to create metrics from events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/events_to_metrics_rule#nrql EventsToMetricsRule#nrql}
    */
    readonly nrql: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/events_to_metrics_rule newrelic_events_to_metrics_rule}
*/
export declare class EventsToMetricsRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_events_to_metrics_rule";
    /**
    * Generates CDKTN code for importing a EventsToMetricsRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventsToMetricsRule to import
    * @param importFromId The id of the existing EventsToMetricsRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/events_to_metrics_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventsToMetricsRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/events_to_metrics_rule newrelic_events_to_metrics_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventsToMetricsRuleConfig
    */
    constructor(scope: Construct, id: string, config: EventsToMetricsRuleConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
    get ruleId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
