/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NotificationChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id of the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#account_id NotificationChannel#account_id}
    */
    readonly accountId?: number;
    /**
    * Indicates whether the channel is active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#active NotificationChannel#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * (Required) The id of the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#destination_id NotificationChannel#destination_id}
    */
    readonly destinationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#id NotificationChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * (Required) The name of the channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#name NotificationChannel#name}
    */
    readonly name: string;
    /**
    * (Required) The type of the channel product. One of: (DISCUSSIONS, ERROR_TRACKING, IINT).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#product NotificationChannel#product}
    */
    readonly product: string;
    /**
    * (Required) The type of the channel. One of: (WEBHOOK, EMAIL, SERVICENOW_INCIDENTS, SERVICE_NOW_APP, PAGERDUTY_ACCOUNT_INTEGRATION, PAGERDUTY_SERVICE_INTEGRATION, JIRA_CLASSIC, SLACK, SLACK_COLLABORATION, SLACK_LEGACY, MOBILE_PUSH, EVENT_BRIDGE, MICROSOFT_TEAMS, WORKFLOW_AUTOMATION).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#type NotificationChannel#type}
    */
    readonly type: string;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#property NotificationChannel#property}
    */
    readonly property: NotificationChannelProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#timeouts NotificationChannel#timeouts}
    */
    readonly timeouts?: NotificationChannelTimeouts;
}
export interface NotificationChannelProperty {
    /**
    * Notification property display key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#display_value NotificationChannel#display_value}
    */
    readonly displayValue?: string;
    /**
    * Notification property key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#key NotificationChannel#key}
    */
    readonly key: string;
    /**
    * Notification property label.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#label NotificationChannel#label}
    */
    readonly label?: string;
    /**
    * Notification property value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#value NotificationChannel#value}
    */
    readonly value: string;
}
export declare function notificationChannelPropertyToTerraform(struct?: NotificationChannelProperty | cdktn.IResolvable): any;
export declare function notificationChannelPropertyToHclTerraform(struct?: NotificationChannelProperty | cdktn.IResolvable): any;
export declare class NotificationChannelPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationChannelProperty | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationChannelProperty | cdktn.IResolvable | undefined);
    private _displayValue?;
    get displayValue(): string;
    set displayValue(value: string);
    resetDisplayValue(): void;
    get displayValueInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class NotificationChannelPropertyList extends cdktn.ComplexList {
    internalValue?: NotificationChannelProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationChannelPropertyOutputReference;
}
export interface NotificationChannelTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#create NotificationChannel#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#update NotificationChannel#update}
    */
    readonly update?: string;
}
export declare function notificationChannelTimeoutsToTerraform(struct?: NotificationChannelTimeouts | cdktn.IResolvable): any;
export declare function notificationChannelTimeoutsToHclTerraform(struct?: NotificationChannelTimeouts | cdktn.IResolvable): any;
export declare class NotificationChannelTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationChannelTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationChannelTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel newrelic_notification_channel}
*/
export declare class NotificationChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_notification_channel";
    /**
    * Generates CDKTN code for importing a NotificationChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NotificationChannel to import
    * @param importFromId The id of the existing NotificationChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NotificationChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.95.2/docs/resources/notification_channel newrelic_notification_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotificationChannelConfig
    */
    constructor(scope: Construct, id: string, config: NotificationChannelConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    get destinationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _product?;
    get product(): string;
    set product(value: string);
    get productInput(): string | undefined;
    get status(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _property;
    get property(): NotificationChannelPropertyList;
    putProperty(value: NotificationChannelProperty[] | cdktn.IResolvable): void;
    get propertyInput(): cdktn.IResolvable | NotificationChannelProperty[] | undefined;
    private _timeouts;
    get timeouts(): NotificationChannelTimeoutsOutputReference;
    putTimeouts(value: NotificationChannelTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | NotificationChannelTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
