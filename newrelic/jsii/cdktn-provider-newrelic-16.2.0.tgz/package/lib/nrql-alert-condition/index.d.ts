/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NrqlAlertConditionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID for managing your NRQL alert conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#account_id NrqlAlertCondition#account_id}
    */
    readonly accountId?: number;
    /**
    * How long we wait for data that belongs in each aggregation window. Depending on your data, a longer delay may increase accuracy but delay notifications. Use aggregationDelay with the EVENT_FLOW and CADENCE aggregation methods.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#aggregation_delay NrqlAlertCondition#aggregation_delay}
    */
    readonly aggregationDelay?: string;
    /**
    * The method that determines when we consider an aggregation window to be complete so that we can evaluate the signal for incidents. Default is EVENT_FLOW.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#aggregation_method NrqlAlertCondition#aggregation_method}
    */
    readonly aggregationMethod?: string;
    /**
    * How long we wait after each data point arrives to make sure we've processed the whole batch. Use aggregationTimer with the EVENT_TIMER aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#aggregation_timer NrqlAlertCondition#aggregation_timer}
    */
    readonly aggregationTimer?: string;
    /**
    * The duration of the time window used to evaluate the NRQL query, in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#aggregation_window NrqlAlertCondition#aggregation_window}
    */
    readonly aggregationWindow?: number;
    /**
    * The baseline direction of a baseline NRQL alert condition. Valid values are: 'LOWER_ONLY', 'UPPER_AND_LOWER', 'UPPER_ONLY' (case insensitive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#baseline_direction NrqlAlertCondition#baseline_direction}
    */
    readonly baselineDirection?: string;
    /**
    * Whether to close all open incidents when the signal expires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#close_violations_on_expiration NrqlAlertCondition#close_violations_on_expiration}
    */
    readonly closeViolationsOnExpiration?: boolean | cdktn.IResolvable;
    /**
    * The description of the NRQL alert condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#description NrqlAlertCondition#description}
    */
    readonly description?: string;
    /**
    * Whether or not to enable the alert condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#enabled NrqlAlertCondition#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * How long we wait until the signal starts evaluating. The maximum delay is 7200 seconds (120 minutes)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#evaluation_delay NrqlAlertCondition#evaluation_delay}
    */
    readonly evaluationDelay?: number;
    /**
    * The amount of time (in seconds) to wait before considering the signal expired.  Must be in the range of 30 to 172800 (inclusive)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#expiration_duration NrqlAlertCondition#expiration_duration}
    */
    readonly expirationDuration?: number;
    /**
    * Which strategy to use when filling gaps in the signal. If static, the 'fill value' will be used for filling gaps in the signal. Valid values are: 'NONE', 'LAST_VALUE', or 'STATIC' (case insensitive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#fill_option NrqlAlertCondition#fill_option}
    */
    readonly fillOption?: string;
    /**
    * If using the 'static' fill option, this value will be used for filling gaps in the signal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#fill_value NrqlAlertCondition#fill_value}
    */
    readonly fillValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#id NrqlAlertCondition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to ignore expected termination of a signal when considering whether to create a loss of signal incident
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#ignore_on_expected_termination NrqlAlertCondition#ignore_on_expected_termination}
    */
    readonly ignoreOnExpectedTermination?: boolean | cdktn.IResolvable;
    /**
    * The title of the condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#name NrqlAlertCondition#name}
    */
    readonly name: string;
    /**
    * Whether to create a new incident to capture that the signal expired.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#open_violation_on_expiration NrqlAlertCondition#open_violation_on_expiration}
    */
    readonly openViolationOnExpiration?: boolean | cdktn.IResolvable;
    /**
    * The ID of the policy where this condition should be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#policy_id NrqlAlertCondition#policy_id}
    */
    readonly policyId: number;
    /**
    * Runbook URL to display in notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#runbook_url NrqlAlertCondition#runbook_url}
    */
    readonly runbookUrl?: string;
    /**
    * Seasonality under which a condition's signal(s) are evaluated. Valid values are: 'NEW_RELIC_CALCULATION', 'HOURLY', 'DAILY', 'WEEKLY', or 'NONE'. To have New Relic calculate seasonality automatically, set to 'NEW_RELIC_CALCULATION' (default). To turn off seasonality completely, set to 'NONE'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#signal_seasonality NrqlAlertCondition#signal_seasonality}
    */
    readonly signalSeasonality?: string;
    /**
    * The duration of overlapping time windows used to smooth the chart line, in seconds. Must be a factor of `aggregation_window` and less than the aggregation window. If `aggregation_window` is less than or equal to 3600 seconds, it should be greater or equal to 30 seconds. If `aggregation_window` is greater than 3600 seconds but less than 7200 seconds, it should be greater or equal to `aggregation_window / 120`.  If `aggregation_window` is greater than 7200 seconds, it should be greater or equal to `aggregation_window / 24
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#slide_by NrqlAlertCondition#slide_by}
    */
    readonly slideBy?: number;
    /**
    * BETA PREVIEW: the `target_entity` field is in limited release and only enabled for preview on a per-account basis. - The GUID of the entity explicitly targeted by the condition. Issues triggered by this condition will affect the health status of this entity instead of having the affected entity detected automatically
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#target_entity NrqlAlertCondition#target_entity}
    */
    readonly targetEntity?: string;
    /**
    * This field allows you to create a custom title to be used when incidents are opened by the condition. Setting this field will override the default title. Must be Handlebars format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#title_template NrqlAlertCondition#title_template}
    */
    readonly titleTemplate?: string;
    /**
    * The type of NRQL alert condition to create. Valid values are: 'static', 'baseline', 'outlier'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#type NrqlAlertCondition#type}
    */
    readonly type?: string;
    /**
    * Sets a time limit, in hours, that will automatically force-close a long-lasting incident after the time limit you select. Possible values are 'ONE_HOUR', 'TWO_HOURS', 'FOUR_HOURS', 'EIGHT_HOURS', 'TWELVE_HOURS', 'TWENTY_FOUR_HOURS', 'THIRTY_DAYS' (case insensitive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#violation_time_limit NrqlAlertCondition#violation_time_limit}
    */
    readonly violationTimeLimit?: string;
    /**
    * Sets a time limit, in seconds, that will automatically force-close a long-lasting incident after the time limit you select.  Must be in the range of 300 to 2592000 (inclusive)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#violation_time_limit_seconds NrqlAlertCondition#violation_time_limit_seconds}
    */
    readonly violationTimeLimitSeconds?: number;
    /**
    * critical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#critical NrqlAlertCondition#critical}
    */
    readonly critical?: NrqlAlertConditionCritical;
    /**
    * nrql block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#nrql NrqlAlertCondition#nrql}
    */
    readonly nrql: NrqlAlertConditionNrql;
    /**
    * outlier_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#outlier_configuration NrqlAlertCondition#outlier_configuration}
    */
    readonly outlierConfiguration?: NrqlAlertConditionOutlierConfiguration;
    /**
    * term block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#term NrqlAlertCondition#term}
    */
    readonly term?: NrqlAlertConditionTerm[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#timeouts NrqlAlertCondition#timeouts}
    */
    readonly timeouts?: NrqlAlertConditionTimeouts;
    /**
    * warning block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#warning NrqlAlertCondition#warning}
    */
    readonly warning?: NrqlAlertConditionWarning;
}
export interface NrqlAlertConditionCriticalPrediction {
    /**
    * BETA PREVIEW: the `predict_by` field is in limited release and only enabled for preview on a per-account basis. - The duration, in seconds, that the prediction should look into the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
    */
    readonly predictBy?: number;
    /**
    * BETA PREVIEW: the `prefer_prediction_violation` field is in limited release and only enabled for preview on a per-account basis. - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting `prefer_prediction_violation` to `true` overrides this behavior leaving the prediction incident open and preventing a static incident from opening.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
    */
    readonly preferPredictionViolation?: boolean | cdktn.IResolvable;
}
export declare function nrqlAlertConditionCriticalPredictionToTerraform(struct?: NrqlAlertConditionCriticalPredictionOutputReference | NrqlAlertConditionCriticalPrediction): any;
export declare function nrqlAlertConditionCriticalPredictionToHclTerraform(struct?: NrqlAlertConditionCriticalPredictionOutputReference | NrqlAlertConditionCriticalPrediction): any;
export declare class NrqlAlertConditionCriticalPredictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlAlertConditionCriticalPrediction | undefined;
    set internalValue(value: NrqlAlertConditionCriticalPrediction | undefined);
    private _predictBy?;
    get predictBy(): number;
    set predictBy(value: number);
    resetPredictBy(): void;
    get predictByInput(): number | undefined;
    private _preferPredictionViolation?;
    get preferPredictionViolation(): boolean | cdktn.IResolvable;
    set preferPredictionViolation(value: boolean | cdktn.IResolvable);
    resetPreferPredictionViolation(): void;
    get preferPredictionViolationInput(): boolean | cdktn.IResolvable | undefined;
}
export interface NrqlAlertConditionCritical {
    /**
    * BETA PREVIEW: the `disable_event_creation` field is in limited release and only enabled for preview on a per-account basis. When set to true, violations will not create events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#disable_event_creation NrqlAlertCondition#disable_event_creation}
    */
    readonly disableEventCreation?: boolean | cdktn.IResolvable;
    /**
    * Violations will not change system health status for this term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
    */
    readonly disableHealthStatusReporting?: boolean | cdktn.IResolvable;
    /**
    * In minutes, must be in the range of 1 to 120 (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
    */
    readonly duration?: number;
    /**
    * One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
    */
    readonly operator?: string;
    /**
    * For baseline conditions must be in range [1, 1000].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
    */
    readonly threshold: number;
    /**
    * The duration, in seconds, that the threshold must violate in order to create an incident. Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
    */
    readonly thresholdDuration?: number;
    /**
    * The criteria for how many data points must be in violation for the specified threshold duration. Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
    */
    readonly thresholdOccurrences?: string;
    /**
    * Valid values are: 'all' or 'any'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
    */
    readonly timeFunction?: string;
    /**
    * prediction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
    */
    readonly prediction?: NrqlAlertConditionCriticalPrediction;
}
export declare function nrqlAlertConditionCriticalToTerraform(struct?: NrqlAlertConditionCriticalOutputReference | NrqlAlertConditionCritical): any;
export declare function nrqlAlertConditionCriticalToHclTerraform(struct?: NrqlAlertConditionCriticalOutputReference | NrqlAlertConditionCritical): any;
export declare class NrqlAlertConditionCriticalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlAlertConditionCritical | undefined;
    set internalValue(value: NrqlAlertConditionCritical | undefined);
    private _disableEventCreation?;
    get disableEventCreation(): boolean | cdktn.IResolvable;
    set disableEventCreation(value: boolean | cdktn.IResolvable);
    resetDisableEventCreation(): void;
    get disableEventCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableHealthStatusReporting?;
    get disableHealthStatusReporting(): boolean | cdktn.IResolvable;
    set disableHealthStatusReporting(value: boolean | cdktn.IResolvable);
    resetDisableHealthStatusReporting(): void;
    get disableHealthStatusReportingInput(): boolean | cdktn.IResolvable | undefined;
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _thresholdDuration?;
    get thresholdDuration(): number;
    set thresholdDuration(value: number);
    resetThresholdDuration(): void;
    get thresholdDurationInput(): number | undefined;
    private _thresholdOccurrences?;
    get thresholdOccurrences(): string;
    set thresholdOccurrences(value: string);
    resetThresholdOccurrences(): void;
    get thresholdOccurrencesInput(): string | undefined;
    private _timeFunction?;
    get timeFunction(): string;
    set timeFunction(value: string);
    resetTimeFunction(): void;
    get timeFunctionInput(): string | undefined;
    private _prediction;
    get prediction(): NrqlAlertConditionCriticalPredictionOutputReference;
    putPrediction(value: NrqlAlertConditionCriticalPrediction): void;
    resetPrediction(): void;
    get predictionInput(): NrqlAlertConditionCriticalPrediction | undefined;
}
export interface NrqlAlertConditionNrql {
    /**
    * The New Relic account ID to use as the basis for the NRQL alert condition's `query`; will default to `account_id` if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#data_account_id NrqlAlertCondition#data_account_id}
    */
    readonly dataAccountId?: number;
    /**
    * NRQL queries are evaluated in one-minute time windows. The start time depends on the value you provide in the NRQL condition's `evaluation_offset`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#evaluation_offset NrqlAlertCondition#evaluation_offset}
    */
    readonly evaluationOffset?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#query NrqlAlertCondition#query}
    */
    readonly query: string;
    /**
    * NRQL queries are evaluated in one-minute time windows. The start time depends on the value you provide in the NRQL condition's `since_value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#since_value NrqlAlertCondition#since_value}
    */
    readonly sinceValue?: string;
}
export declare function nrqlAlertConditionNrqlToTerraform(struct?: NrqlAlertConditionNrqlOutputReference | NrqlAlertConditionNrql): any;
export declare function nrqlAlertConditionNrqlToHclTerraform(struct?: NrqlAlertConditionNrqlOutputReference | NrqlAlertConditionNrql): any;
export declare class NrqlAlertConditionNrqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlAlertConditionNrql | undefined;
    set internalValue(value: NrqlAlertConditionNrql | undefined);
    private _dataAccountId?;
    get dataAccountId(): number;
    set dataAccountId(value: number);
    resetDataAccountId(): void;
    get dataAccountIdInput(): number | undefined;
    private _evaluationOffset?;
    get evaluationOffset(): number;
    set evaluationOffset(value: number);
    resetEvaluationOffset(): void;
    get evaluationOffsetInput(): number | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _sinceValue?;
    get sinceValue(): string;
    set sinceValue(value: string);
    resetSinceValue(): void;
    get sinceValueInput(): string | undefined;
}
export interface NrqlAlertConditionOutlierConfigurationDbscan {
    /**
    * BETA PREVIEW: the `epsilon` field is in limited release and only enabled for preview on a per-account basis. - Radius (distance threshold) for DBSCAN in the units of the query result. Smaller values tighten clusters; larger values broaden them. Must be > 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#epsilon NrqlAlertCondition#epsilon}
    */
    readonly epsilon: number;
    /**
    * BETA PREVIEW: the `evaluation_group_facet` field is in limited release and only enabled for preview on a per-account basis. - Optional NRQL facet attribute used to segment data into groups (e.g. `host`, `region`) before running outlier detection. Omit to evaluate all results together.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#evaluation_group_facet NrqlAlertCondition#evaluation_group_facet}
    */
    readonly evaluationGroupFacet?: string;
    /**
    * BETA PREVIEW: the `minimum_points` field is in limited release and only enabled for preview on a per-account basis. - Minimum number of neighboring points needed to form a cluster. Must be >= 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#minimum_points NrqlAlertCondition#minimum_points}
    */
    readonly minimumPoints: number;
}
export declare function nrqlAlertConditionOutlierConfigurationDbscanToTerraform(struct?: NrqlAlertConditionOutlierConfigurationDbscanOutputReference | NrqlAlertConditionOutlierConfigurationDbscan): any;
export declare function nrqlAlertConditionOutlierConfigurationDbscanToHclTerraform(struct?: NrqlAlertConditionOutlierConfigurationDbscanOutputReference | NrqlAlertConditionOutlierConfigurationDbscan): any;
export declare class NrqlAlertConditionOutlierConfigurationDbscanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlAlertConditionOutlierConfigurationDbscan | undefined;
    set internalValue(value: NrqlAlertConditionOutlierConfigurationDbscan | undefined);
    private _epsilon?;
    get epsilon(): number;
    set epsilon(value: number);
    get epsilonInput(): number | undefined;
    private _evaluationGroupFacet?;
    get evaluationGroupFacet(): string;
    set evaluationGroupFacet(value: string);
    resetEvaluationGroupFacet(): void;
    get evaluationGroupFacetInput(): string | undefined;
    private _minimumPoints?;
    get minimumPoints(): number;
    set minimumPoints(value: number);
    get minimumPointsInput(): number | undefined;
}
export interface NrqlAlertConditionOutlierConfiguration {
    /**
    * dbscan block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#dbscan NrqlAlertCondition#dbscan}
    */
    readonly dbscan: NrqlAlertConditionOutlierConfigurationDbscan;
}
export declare function nrqlAlertConditionOutlierConfigurationToTerraform(struct?: NrqlAlertConditionOutlierConfigurationOutputReference | NrqlAlertConditionOutlierConfiguration): any;
export declare function nrqlAlertConditionOutlierConfigurationToHclTerraform(struct?: NrqlAlertConditionOutlierConfigurationOutputReference | NrqlAlertConditionOutlierConfiguration): any;
export declare class NrqlAlertConditionOutlierConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlAlertConditionOutlierConfiguration | undefined;
    set internalValue(value: NrqlAlertConditionOutlierConfiguration | undefined);
    private _dbscan;
    get dbscan(): NrqlAlertConditionOutlierConfigurationDbscanOutputReference;
    putDbscan(value: NrqlAlertConditionOutlierConfigurationDbscan): void;
    get dbscanInput(): NrqlAlertConditionOutlierConfigurationDbscan | undefined;
}
export interface NrqlAlertConditionTermPrediction {
    /**
    * BETA PREVIEW: the `predict_by` field is in limited release and only enabled for preview on a per-account basis. - The duration, in seconds, that the prediction should look into the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
    */
    readonly predictBy?: number;
    /**
    * BETA PREVIEW: the `prefer_prediction_violation` field is in limited release and only enabled for preview on a per-account basis. - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting `prefer_prediction_violation` to `true` overrides this behavior leaving the prediction incident open and preventing a static incident from opening.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
    */
    readonly preferPredictionViolation?: boolean | cdktn.IResolvable;
}
export declare function nrqlAlertConditionTermPredictionToTerraform(struct?: NrqlAlertConditionTermPredictionOutputReference | NrqlAlertConditionTermPrediction): any;
export declare function nrqlAlertConditionTermPredictionToHclTerraform(struct?: NrqlAlertConditionTermPredictionOutputReference | NrqlAlertConditionTermPrediction): any;
export declare class NrqlAlertConditionTermPredictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlAlertConditionTermPrediction | undefined;
    set internalValue(value: NrqlAlertConditionTermPrediction | undefined);
    private _predictBy?;
    get predictBy(): number;
    set predictBy(value: number);
    resetPredictBy(): void;
    get predictByInput(): number | undefined;
    private _preferPredictionViolation?;
    get preferPredictionViolation(): boolean | cdktn.IResolvable;
    set preferPredictionViolation(value: boolean | cdktn.IResolvable);
    resetPreferPredictionViolation(): void;
    get preferPredictionViolationInput(): boolean | cdktn.IResolvable | undefined;
}
export interface NrqlAlertConditionTerm {
    /**
    * BETA PREVIEW: the `disable_event_creation` field is in limited release and only enabled for preview on a per-account basis. When set to true, violations will not create events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#disable_event_creation NrqlAlertCondition#disable_event_creation}
    */
    readonly disableEventCreation?: boolean | cdktn.IResolvable;
    /**
    * Violations will not change system health status for this term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
    */
    readonly disableHealthStatusReporting?: boolean | cdktn.IResolvable;
    /**
    * In minutes, must be in the range of 1 to 120 (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
    */
    readonly duration?: number;
    /**
    * One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
    */
    readonly operator?: string;
    /**
    * One of (critical, warning). Defaults to 'critical'. At least one condition term must have priority set to 'critical'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#priority NrqlAlertCondition#priority}
    */
    readonly priority?: string;
    /**
    * For baseline conditions must be in range [1, 1000].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
    */
    readonly threshold: number;
    /**
    * The duration, in seconds, that the threshold must violate in order to create an incident. Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
    */
    readonly thresholdDuration?: number;
    /**
    * The criteria for how many data points must be in violation for the specified threshold duration. Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
    */
    readonly thresholdOccurrences?: string;
    /**
    * Valid values are: 'all' or 'any'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
    */
    readonly timeFunction?: string;
    /**
    * prediction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
    */
    readonly prediction?: NrqlAlertConditionTermPrediction;
}
export declare function nrqlAlertConditionTermToTerraform(struct?: NrqlAlertConditionTerm | cdktn.IResolvable): any;
export declare function nrqlAlertConditionTermToHclTerraform(struct?: NrqlAlertConditionTerm | cdktn.IResolvable): any;
export declare class NrqlAlertConditionTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NrqlAlertConditionTerm | cdktn.IResolvable | undefined;
    set internalValue(value: NrqlAlertConditionTerm | cdktn.IResolvable | undefined);
    private _disableEventCreation?;
    get disableEventCreation(): boolean | cdktn.IResolvable;
    set disableEventCreation(value: boolean | cdktn.IResolvable);
    resetDisableEventCreation(): void;
    get disableEventCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableHealthStatusReporting?;
    get disableHealthStatusReporting(): boolean | cdktn.IResolvable;
    set disableHealthStatusReporting(value: boolean | cdktn.IResolvable);
    resetDisableHealthStatusReporting(): void;
    get disableHealthStatusReportingInput(): boolean | cdktn.IResolvable | undefined;
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _thresholdDuration?;
    get thresholdDuration(): number;
    set thresholdDuration(value: number);
    resetThresholdDuration(): void;
    get thresholdDurationInput(): number | undefined;
    private _thresholdOccurrences?;
    get thresholdOccurrences(): string;
    set thresholdOccurrences(value: string);
    resetThresholdOccurrences(): void;
    get thresholdOccurrencesInput(): string | undefined;
    private _timeFunction?;
    get timeFunction(): string;
    set timeFunction(value: string);
    resetTimeFunction(): void;
    get timeFunctionInput(): string | undefined;
    private _prediction;
    get prediction(): NrqlAlertConditionTermPredictionOutputReference;
    putPrediction(value: NrqlAlertConditionTermPrediction): void;
    resetPrediction(): void;
    get predictionInput(): NrqlAlertConditionTermPrediction | undefined;
}
export declare class NrqlAlertConditionTermList extends cdktn.ComplexList {
    internalValue?: NrqlAlertConditionTerm[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NrqlAlertConditionTermOutputReference;
}
export interface NrqlAlertConditionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#create NrqlAlertCondition#create}
    */
    readonly create?: string;
}
export declare function nrqlAlertConditionTimeoutsToTerraform(struct?: NrqlAlertConditionTimeouts | cdktn.IResolvable): any;
export declare function nrqlAlertConditionTimeoutsToHclTerraform(struct?: NrqlAlertConditionTimeouts | cdktn.IResolvable): any;
export declare class NrqlAlertConditionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlAlertConditionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: NrqlAlertConditionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
export interface NrqlAlertConditionWarningPrediction {
    /**
    * BETA PREVIEW: the `predict_by` field is in limited release and only enabled for preview on a per-account basis. - The duration, in seconds, that the prediction should look into the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#predict_by NrqlAlertCondition#predict_by}
    */
    readonly predictBy?: number;
    /**
    * BETA PREVIEW: the `prefer_prediction_violation` field is in limited release and only enabled for preview on a per-account basis. - If a prediction incident is open when a term's static threshold is breached by the actual signal, default behavior is to close the prediction incident and open a static incident. Setting `prefer_prediction_violation` to `true` overrides this behavior leaving the prediction incident open and preventing a static incident from opening.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#prefer_prediction_violation NrqlAlertCondition#prefer_prediction_violation}
    */
    readonly preferPredictionViolation?: boolean | cdktn.IResolvable;
}
export declare function nrqlAlertConditionWarningPredictionToTerraform(struct?: NrqlAlertConditionWarningPredictionOutputReference | NrqlAlertConditionWarningPrediction): any;
export declare function nrqlAlertConditionWarningPredictionToHclTerraform(struct?: NrqlAlertConditionWarningPredictionOutputReference | NrqlAlertConditionWarningPrediction): any;
export declare class NrqlAlertConditionWarningPredictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlAlertConditionWarningPrediction | undefined;
    set internalValue(value: NrqlAlertConditionWarningPrediction | undefined);
    private _predictBy?;
    get predictBy(): number;
    set predictBy(value: number);
    resetPredictBy(): void;
    get predictByInput(): number | undefined;
    private _preferPredictionViolation?;
    get preferPredictionViolation(): boolean | cdktn.IResolvable;
    set preferPredictionViolation(value: boolean | cdktn.IResolvable);
    resetPreferPredictionViolation(): void;
    get preferPredictionViolationInput(): boolean | cdktn.IResolvable | undefined;
}
export interface NrqlAlertConditionWarning {
    /**
    * BETA PREVIEW: the `disable_event_creation` field is in limited release and only enabled for preview on a per-account basis. When set to true, violations will not create events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#disable_event_creation NrqlAlertCondition#disable_event_creation}
    */
    readonly disableEventCreation?: boolean | cdktn.IResolvable;
    /**
    * Violations will not change system health status for this term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#disable_health_status_reporting NrqlAlertCondition#disable_health_status_reporting}
    */
    readonly disableHealthStatusReporting?: boolean | cdktn.IResolvable;
    /**
    * In minutes, must be in the range of 1 to 120 (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#duration NrqlAlertCondition#duration}
    */
    readonly duration?: number;
    /**
    * One of (above, above_or_equals, below, below_or_equals, equals, not_equals). Defaults to 'equals'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#operator NrqlAlertCondition#operator}
    */
    readonly operator?: string;
    /**
    * For baseline conditions must be in range [1, 1000].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#threshold NrqlAlertCondition#threshold}
    */
    readonly threshold: number;
    /**
    * The duration, in seconds, that the threshold must violate in order to create an incident. Value must be a multiple of the 'aggregation_window' (which has a default of 60 seconds). Value must be within 120-86400 seconds for baseline conditions, and within 60-86400 seconds for static conditions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#threshold_duration NrqlAlertCondition#threshold_duration}
    */
    readonly thresholdDuration?: number;
    /**
    * The criteria for how many data points must be in violation for the specified threshold duration. Valid values are: 'ALL' or 'AT_LEAST_ONCE' (case insensitive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#threshold_occurrences NrqlAlertCondition#threshold_occurrences}
    */
    readonly thresholdOccurrences?: string;
    /**
    * Valid values are: 'all' or 'any'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#time_function NrqlAlertCondition#time_function}
    */
    readonly timeFunction?: string;
    /**
    * prediction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#prediction NrqlAlertCondition#prediction}
    */
    readonly prediction?: NrqlAlertConditionWarningPrediction;
}
export declare function nrqlAlertConditionWarningToTerraform(struct?: NrqlAlertConditionWarningOutputReference | NrqlAlertConditionWarning): any;
export declare function nrqlAlertConditionWarningToHclTerraform(struct?: NrqlAlertConditionWarningOutputReference | NrqlAlertConditionWarning): any;
export declare class NrqlAlertConditionWarningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlAlertConditionWarning | undefined;
    set internalValue(value: NrqlAlertConditionWarning | undefined);
    private _disableEventCreation?;
    get disableEventCreation(): boolean | cdktn.IResolvable;
    set disableEventCreation(value: boolean | cdktn.IResolvable);
    resetDisableEventCreation(): void;
    get disableEventCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableHealthStatusReporting?;
    get disableHealthStatusReporting(): boolean | cdktn.IResolvable;
    set disableHealthStatusReporting(value: boolean | cdktn.IResolvable);
    resetDisableHealthStatusReporting(): void;
    get disableHealthStatusReportingInput(): boolean | cdktn.IResolvable | undefined;
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _thresholdDuration?;
    get thresholdDuration(): number;
    set thresholdDuration(value: number);
    resetThresholdDuration(): void;
    get thresholdDurationInput(): number | undefined;
    private _thresholdOccurrences?;
    get thresholdOccurrences(): string;
    set thresholdOccurrences(value: string);
    resetThresholdOccurrences(): void;
    get thresholdOccurrencesInput(): string | undefined;
    private _timeFunction?;
    get timeFunction(): string;
    set timeFunction(value: string);
    resetTimeFunction(): void;
    get timeFunctionInput(): string | undefined;
    private _prediction;
    get prediction(): NrqlAlertConditionWarningPredictionOutputReference;
    putPrediction(value: NrqlAlertConditionWarningPrediction): void;
    resetPrediction(): void;
    get predictionInput(): NrqlAlertConditionWarningPrediction | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition newrelic_nrql_alert_condition}
*/
export declare class NrqlAlertCondition extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_nrql_alert_condition";
    /**
    * Generates CDKTN code for importing a NrqlAlertCondition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NrqlAlertCondition to import
    * @param importFromId The id of the existing NrqlAlertCondition that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NrqlAlertCondition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/nrql_alert_condition newrelic_nrql_alert_condition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NrqlAlertConditionConfig
    */
    constructor(scope: Construct, id: string, config: NrqlAlertConditionConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _aggregationDelay?;
    get aggregationDelay(): string;
    set aggregationDelay(value: string);
    resetAggregationDelay(): void;
    get aggregationDelayInput(): string | undefined;
    private _aggregationMethod?;
    get aggregationMethod(): string;
    set aggregationMethod(value: string);
    resetAggregationMethod(): void;
    get aggregationMethodInput(): string | undefined;
    private _aggregationTimer?;
    get aggregationTimer(): string;
    set aggregationTimer(value: string);
    resetAggregationTimer(): void;
    get aggregationTimerInput(): string | undefined;
    private _aggregationWindow?;
    get aggregationWindow(): number;
    set aggregationWindow(value: number);
    resetAggregationWindow(): void;
    get aggregationWindowInput(): number | undefined;
    private _baselineDirection?;
    get baselineDirection(): string;
    set baselineDirection(value: string);
    resetBaselineDirection(): void;
    get baselineDirectionInput(): string | undefined;
    private _closeViolationsOnExpiration?;
    get closeViolationsOnExpiration(): boolean | cdktn.IResolvable;
    set closeViolationsOnExpiration(value: boolean | cdktn.IResolvable);
    resetCloseViolationsOnExpiration(): void;
    get closeViolationsOnExpirationInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get entityGuid(): string;
    private _evaluationDelay?;
    get evaluationDelay(): number;
    set evaluationDelay(value: number);
    resetEvaluationDelay(): void;
    get evaluationDelayInput(): number | undefined;
    private _expirationDuration?;
    get expirationDuration(): number;
    set expirationDuration(value: number);
    resetExpirationDuration(): void;
    get expirationDurationInput(): number | undefined;
    private _fillOption?;
    get fillOption(): string;
    set fillOption(value: string);
    resetFillOption(): void;
    get fillOptionInput(): string | undefined;
    private _fillValue?;
    get fillValue(): number;
    set fillValue(value: number);
    resetFillValue(): void;
    get fillValueInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreOnExpectedTermination?;
    get ignoreOnExpectedTermination(): boolean | cdktn.IResolvable;
    set ignoreOnExpectedTermination(value: boolean | cdktn.IResolvable);
    resetIgnoreOnExpectedTermination(): void;
    get ignoreOnExpectedTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _openViolationOnExpiration?;
    get openViolationOnExpiration(): boolean | cdktn.IResolvable;
    set openViolationOnExpiration(value: boolean | cdktn.IResolvable);
    resetOpenViolationOnExpiration(): void;
    get openViolationOnExpirationInput(): boolean | cdktn.IResolvable | undefined;
    private _policyId?;
    get policyId(): number;
    set policyId(value: number);
    get policyIdInput(): number | undefined;
    private _runbookUrl?;
    get runbookUrl(): string;
    set runbookUrl(value: string);
    resetRunbookUrl(): void;
    get runbookUrlInput(): string | undefined;
    private _signalSeasonality?;
    get signalSeasonality(): string;
    set signalSeasonality(value: string);
    resetSignalSeasonality(): void;
    get signalSeasonalityInput(): string | undefined;
    private _slideBy?;
    get slideBy(): number;
    set slideBy(value: number);
    resetSlideBy(): void;
    get slideByInput(): number | undefined;
    private _targetEntity?;
    get targetEntity(): string;
    set targetEntity(value: string);
    resetTargetEntity(): void;
    get targetEntityInput(): string | undefined;
    private _titleTemplate?;
    get titleTemplate(): string;
    set titleTemplate(value: string);
    resetTitleTemplate(): void;
    get titleTemplateInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _violationTimeLimit?;
    get violationTimeLimit(): string;
    set violationTimeLimit(value: string);
    resetViolationTimeLimit(): void;
    get violationTimeLimitInput(): string | undefined;
    private _violationTimeLimitSeconds?;
    get violationTimeLimitSeconds(): number;
    set violationTimeLimitSeconds(value: number);
    resetViolationTimeLimitSeconds(): void;
    get violationTimeLimitSecondsInput(): number | undefined;
    private _critical;
    get critical(): NrqlAlertConditionCriticalOutputReference;
    putCritical(value: NrqlAlertConditionCritical): void;
    resetCritical(): void;
    get criticalInput(): NrqlAlertConditionCritical | undefined;
    private _nrql;
    get nrql(): NrqlAlertConditionNrqlOutputReference;
    putNrql(value: NrqlAlertConditionNrql): void;
    get nrqlInput(): NrqlAlertConditionNrql | undefined;
    private _outlierConfiguration;
    get outlierConfiguration(): NrqlAlertConditionOutlierConfigurationOutputReference;
    putOutlierConfiguration(value: NrqlAlertConditionOutlierConfiguration): void;
    resetOutlierConfiguration(): void;
    get outlierConfigurationInput(): NrqlAlertConditionOutlierConfiguration | undefined;
    private _term;
    get term(): NrqlAlertConditionTermList;
    putTerm(value: NrqlAlertConditionTerm[] | cdktn.IResolvable): void;
    resetTerm(): void;
    get termInput(): cdktn.IResolvable | NrqlAlertConditionTerm[] | undefined;
    private _timeouts;
    get timeouts(): NrqlAlertConditionTimeoutsOutputReference;
    putTimeouts(value: NrqlAlertConditionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | NrqlAlertConditionTimeouts | undefined;
    private _warning;
    get warning(): NrqlAlertConditionWarningOutputReference;
    putWarning(value: NrqlAlertConditionWarning): void;
    resetWarning(): void;
    get warningInput(): NrqlAlertConditionWarning | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
