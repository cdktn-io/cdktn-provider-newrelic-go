/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertConditionConfig extends cdktn.TerraformMetaArguments {
    /**
    * One of (application, instance). Choose application for most scenarios. If you are using the JVM plugin in New Relic, the instance setting allows your condition to trigger for specific app instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#condition_scope AlertCondition#condition_scope}
    */
    readonly conditionScope?: string;
    /**
    * Whether the condition is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#enabled AlertCondition#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The instance IDs associated with this condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#entities AlertCondition#entities}
    */
    readonly entities: number[];
    /**
    * A valid Garbage Collection metric e.g. GC/G1 Young Generation. This is required if you are using apm_jvm_metric with gc_cpu_time condition type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#gc_metric AlertCondition#gc_metric}
    */
    readonly gcMetric?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#id AlertCondition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The metric field accepts parameters based on the type set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#metric AlertCondition#metric}
    */
    readonly metric: string;
    /**
    * The title of the condition. Must be between 1 and 128 characters, inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#name AlertCondition#name}
    */
    readonly name: string;
    /**
    * The ID of the policy where this condition should be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#policy_id AlertCondition#policy_id}
    */
    readonly policyId: number;
    /**
    * Runbook URL to display in notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#runbook_url AlertCondition#runbook_url}
    */
    readonly runbookUrl?: string;
    /**
    * The type of condition. One of: (apm_app_metric, apm_jvm_metric, apm_kt_metric, browser_metric, mobile_metric, servers_metric).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#type AlertCondition#type}
    */
    readonly type: string;
    /**
    * A custom metric to be evaluated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#user_defined_metric AlertCondition#user_defined_metric}
    */
    readonly userDefinedMetric?: string;
    /**
    * One of: (average, min, max, total, sample_size, percent, rate).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#user_defined_value_function AlertCondition#user_defined_value_function}
    */
    readonly userDefinedValueFunction?: string;
    /**
    * Automatically close instance-based incidents, including JVM health metric incidents, after the number of hours specified. Must be between 1 and 720 hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#violation_close_timer AlertCondition#violation_close_timer}
    */
    readonly violationCloseTimer?: number;
    /**
    * term block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#term AlertCondition#term}
    */
    readonly term: AlertConditionTerm[] | cdktn.IResolvable;
}
export interface AlertConditionTerm {
    /**
    * In minutes, must be in the range of 5 to 120, inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#duration AlertCondition#duration}
    */
    readonly duration: number;
    /**
    * One of (above, below, equal). Defaults to equal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#operator AlertCondition#operator}
    */
    readonly operator?: string;
    /**
    * One of (critical, warning). Defaults to critical.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#priority AlertCondition#priority}
    */
    readonly priority?: string;
    /**
    * Must be 0 or greater.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#threshold AlertCondition#threshold}
    */
    readonly threshold: number;
    /**
    * One of (all, any).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#time_function AlertCondition#time_function}
    */
    readonly timeFunction: string;
}
export declare function alertConditionTermToTerraform(struct?: AlertConditionTerm | cdktn.IResolvable): any;
export declare function alertConditionTermToHclTerraform(struct?: AlertConditionTerm | cdktn.IResolvable): any;
export declare class AlertConditionTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertConditionTerm | cdktn.IResolvable | undefined;
    set internalValue(value: AlertConditionTerm | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    get durationInput(): number | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _timeFunction?;
    get timeFunction(): string;
    set timeFunction(value: string);
    get timeFunctionInput(): string | undefined;
}
export declare class AlertConditionTermList extends cdktn.ComplexList {
    internalValue?: AlertConditionTerm[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertConditionTermOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition newrelic_alert_condition}
*/
export declare class AlertCondition extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_alert_condition";
    /**
    * Generates CDKTN code for importing a AlertCondition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertCondition to import
    * @param importFromId The id of the existing AlertCondition that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertCondition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/alert_condition newrelic_alert_condition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertConditionConfig
    */
    constructor(scope: Construct, id: string, config: AlertConditionConfig);
    private _conditionScope?;
    get conditionScope(): string;
    set conditionScope(value: string);
    resetConditionScope(): void;
    get conditionScopeInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _entities?;
    get entities(): number[];
    set entities(value: number[]);
    get entitiesInput(): number[] | undefined;
    get entityGuid(): string;
    private _gcMetric?;
    get gcMetric(): string;
    set gcMetric(value: string);
    resetGcMetric(): void;
    get gcMetricInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyId?;
    get policyId(): number;
    set policyId(value: number);
    get policyIdInput(): number | undefined;
    private _runbookUrl?;
    get runbookUrl(): string;
    set runbookUrl(value: string);
    resetRunbookUrl(): void;
    get runbookUrlInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _userDefinedMetric?;
    get userDefinedMetric(): string;
    set userDefinedMetric(value: string);
    resetUserDefinedMetric(): void;
    get userDefinedMetricInput(): string | undefined;
    private _userDefinedValueFunction?;
    get userDefinedValueFunction(): string;
    set userDefinedValueFunction(value: string);
    resetUserDefinedValueFunction(): void;
    get userDefinedValueFunctionInput(): string | undefined;
    private _violationCloseTimer?;
    get violationCloseTimer(): number;
    set violationCloseTimer(value: number);
    resetViolationCloseTimer(): void;
    get violationCloseTimerInput(): number | undefined;
    private _term;
    get term(): AlertConditionTermList;
    putTerm(value: AlertConditionTerm[] | cdktn.IResolvable): void;
    get termInput(): cdktn.IResolvable | AlertConditionTerm[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
