/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { OneDashboardPage, OneDashboardPageList, OneDashboardVariable, OneDashboardVariableList } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OneDashboardConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where you want to create the dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: number;
    /**
    * The dashboard's description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard#description OneDashboard#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard#id OneDashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The dashboard's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * Determines who can see or edit the dashboard. Valid values are private, public_read_only, public_read_write. Defaults to public_read_only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard#permissions OneDashboard#permissions}
    */
    readonly permissions?: string;
    /**
    * page block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard#page OneDashboard#page}
    */
    readonly page: OneDashboardPage[] | cdktn.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard#variable OneDashboard#variable}
    */
    readonly variable?: OneDashboardVariable[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard newrelic_one_dashboard}
*/
export declare class OneDashboard extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_one_dashboard";
    /**
    * Generates CDKTN code for importing a OneDashboard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OneDashboard to import
    * @param importFromId The id of the existing OneDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OneDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.98.0/docs/resources/one_dashboard newrelic_one_dashboard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OneDashboardConfig
    */
    constructor(scope: Construct, id: string, config: OneDashboardConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get permalink(): string;
    private _permissions?;
    get permissions(): string;
    set permissions(value: string);
    resetPermissions(): void;
    get permissionsInput(): string | undefined;
    private _page;
    get page(): OneDashboardPageList;
    putPage(value: OneDashboardPage[] | cdktn.IResolvable): void;
    get pageInput(): cdktn.IResolvable | OneDashboardPage[] | undefined;
    private _variable;
    get variable(): OneDashboardVariableList;
    putVariable(value: OneDashboardVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | OneDashboardVariable[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
