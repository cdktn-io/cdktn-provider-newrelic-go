/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ScorecardConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the scorecard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#description Scorecard#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#id Scorecard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the scorecard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#name Scorecard#name}
    */
    readonly name: string;
    /**
    * Set of newrelic_scorecard_rule GUIDs to attach to this scorecard. Rules must exist before being attached. Removing a GUID detaches the rule without deleting it — rules are standalone entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#rule_ids Scorecard#rule_ids}
    */
    readonly ruleIds?: string[];
    /**
    * progress_levels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#progress_levels Scorecard#progress_levels}
    */
    readonly progressLevels?: ScorecardProgressLevels[] | cdktn.IResolvable;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#tags Scorecard#tags}
    */
    readonly tags?: ScorecardTags[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#timeouts Scorecard#timeouts}
    */
    readonly timeouts?: ScorecardTimeouts;
}
export interface ScorecardProgressLevels {
    /**
    * Description of what this level means.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#description Scorecard#description}
    */
    readonly description?: string;
    /**
    * Hex colour for this level, e.g. '#FF0000'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#hex_color_code Scorecard#hex_color_code}
    */
    readonly hexColorCode?: string;
    /**
    * A unique identifier for this level (e.g. 'red', 'green').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#id Scorecard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Display name of the level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#name Scorecard#name}
    */
    readonly name: string;
}
export declare function scorecardProgressLevelsToTerraform(struct?: ScorecardProgressLevels | cdktn.IResolvable): any;
export declare function scorecardProgressLevelsToHclTerraform(struct?: ScorecardProgressLevels | cdktn.IResolvable): any;
export declare class ScorecardProgressLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScorecardProgressLevels | cdktn.IResolvable | undefined;
    set internalValue(value: ScorecardProgressLevels | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hexColorCode?;
    get hexColorCode(): string;
    set hexColorCode(value: string);
    resetHexColorCode(): void;
    get hexColorCodeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ScorecardProgressLevelsList extends cdktn.ComplexList {
    internalValue?: ScorecardProgressLevels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScorecardProgressLevelsOutputReference;
}
export interface ScorecardTags {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#key Scorecard#key}
    */
    readonly key: string;
    /**
    * The tag values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#values Scorecard#values}
    */
    readonly values: string[];
}
export declare function scorecardTagsToTerraform(struct?: ScorecardTags | cdktn.IResolvable): any;
export declare function scorecardTagsToHclTerraform(struct?: ScorecardTags | cdktn.IResolvable): any;
export declare class ScorecardTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScorecardTags | cdktn.IResolvable | undefined;
    set internalValue(value: ScorecardTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ScorecardTagsList extends cdktn.ComplexList {
    internalValue?: ScorecardTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScorecardTagsOutputReference;
}
export interface ScorecardTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#create Scorecard#create}
    */
    readonly create?: string;
}
export declare function scorecardTimeoutsToTerraform(struct?: ScorecardTimeouts | cdktn.IResolvable): any;
export declare function scorecardTimeoutsToHclTerraform(struct?: ScorecardTimeouts | cdktn.IResolvable): any;
export declare class ScorecardTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ScorecardTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ScorecardTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard newrelic_scorecard}
*/
export declare class Scorecard extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_scorecard";
    /**
    * Generates CDKTN code for importing a Scorecard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Scorecard to import
    * @param importFromId The id of the existing Scorecard that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Scorecard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/scorecard newrelic_scorecard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ScorecardConfig
    */
    constructor(scope: Construct, id: string, config: ScorecardConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _ruleIds?;
    get ruleIds(): string[];
    set ruleIds(value: string[]);
    resetRuleIds(): void;
    get ruleIdsInput(): string[] | undefined;
    get rulesCollectionId(): string;
    private _progressLevels;
    get progressLevels(): ScorecardProgressLevelsList;
    putProgressLevels(value: ScorecardProgressLevels[] | cdktn.IResolvable): void;
    resetProgressLevels(): void;
    get progressLevelsInput(): cdktn.IResolvable | ScorecardProgressLevels[] | undefined;
    private _tags;
    get tags(): ScorecardTagsList;
    putTags(value: ScorecardTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ScorecardTags[] | undefined;
    private _timeouts;
    get timeouts(): ScorecardTimeoutsOutputReference;
    putTimeouts(value: ScorecardTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ScorecardTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
