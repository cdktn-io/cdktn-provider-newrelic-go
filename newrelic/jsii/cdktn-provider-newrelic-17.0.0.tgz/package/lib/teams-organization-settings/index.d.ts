/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TeamsOrganizationSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether tag-based entity discovery is enabled. When true, entities with a matching tag are automatically assigned to teams.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#discovery_enabled TeamsOrganizationSettings#discovery_enabled}
    */
    readonly discoveryEnabled?: boolean | cdktn.IResolvable;
    /**
    * Tag keys used for entity discovery (e.g. ["team"]). Entities with these tags are auto-assigned to the team whose name or alias matches the tag value. Must contain at least one key when declared.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#discovery_tag_keys TeamsOrganizationSettings#discovery_tag_keys}
    */
    readonly discoveryTagKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#id TeamsOrganizationSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether automatic team creation from IdP groups is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#sync_groups_enabled TeamsOrganizationSettings#sync_groups_enabled}
    */
    readonly syncGroupsEnabled?: boolean | cdktn.IResolvable;
    /**
    * hierarchy_levels block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#hierarchy_levels TeamsOrganizationSettings#hierarchy_levels}
    */
    readonly hierarchyLevels?: TeamsOrganizationSettingsHierarchyLevels[] | cdktn.IResolvable;
    /**
    * sync_group_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#sync_group_rules TeamsOrganizationSettings#sync_group_rules}
    */
    readonly syncGroupRules?: TeamsOrganizationSettingsSyncGroupRules;
}
export interface TeamsOrganizationSettingsHierarchyLevels {
    /**
    * GUID of the hierarchy level entity. Obtain from the newrelic_teams_hierarchy_levels data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#id TeamsOrganizationSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Display name of this hierarchy level (e.g. 'Division', 'Squad'). Renaming here updates the entity in the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#name TeamsOrganizationSettings#name}
    */
    readonly name: string;
}
export declare function teamsOrganizationSettingsHierarchyLevelsToTerraform(struct?: TeamsOrganizationSettingsHierarchyLevels | cdktn.IResolvable): any;
export declare function teamsOrganizationSettingsHierarchyLevelsToHclTerraform(struct?: TeamsOrganizationSettingsHierarchyLevels | cdktn.IResolvable): any;
export declare class TeamsOrganizationSettingsHierarchyLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TeamsOrganizationSettingsHierarchyLevels | cdktn.IResolvable | undefined;
    set internalValue(value: TeamsOrganizationSettingsHierarchyLevels | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class TeamsOrganizationSettingsHierarchyLevelsList extends cdktn.ComplexList {
    internalValue?: TeamsOrganizationSettingsHierarchyLevels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TeamsOrganizationSettingsHierarchyLevelsOutputReference;
}
export interface TeamsOrganizationSettingsSyncGroupRulesConditions {
    /**
    * Match type: STARTS_WITH, ENDS_WITH, or CONTAINS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#type TeamsOrganizationSettings#type}
    */
    readonly type: string;
    /**
    * The string to match against the group name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#value TeamsOrganizationSettings#value}
    */
    readonly value: string;
}
export declare function teamsOrganizationSettingsSyncGroupRulesConditionsToTerraform(struct?: TeamsOrganizationSettingsSyncGroupRulesConditions | cdktn.IResolvable): any;
export declare function teamsOrganizationSettingsSyncGroupRulesConditionsToHclTerraform(struct?: TeamsOrganizationSettingsSyncGroupRulesConditions | cdktn.IResolvable): any;
export declare class TeamsOrganizationSettingsSyncGroupRulesConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TeamsOrganizationSettingsSyncGroupRulesConditions | cdktn.IResolvable | undefined;
    set internalValue(value: TeamsOrganizationSettingsSyncGroupRulesConditions | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class TeamsOrganizationSettingsSyncGroupRulesConditionsList extends cdktn.ComplexList {
    internalValue?: TeamsOrganizationSettingsSyncGroupRulesConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TeamsOrganizationSettingsSyncGroupRulesConditionsOutputReference;
}
export interface TeamsOrganizationSettingsSyncGroupRules {
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#conditions TeamsOrganizationSettings#conditions}
    */
    readonly conditions: TeamsOrganizationSettingsSyncGroupRulesConditions[] | cdktn.IResolvable;
}
export declare function teamsOrganizationSettingsSyncGroupRulesToTerraform(struct?: TeamsOrganizationSettingsSyncGroupRulesOutputReference | TeamsOrganizationSettingsSyncGroupRules): any;
export declare function teamsOrganizationSettingsSyncGroupRulesToHclTerraform(struct?: TeamsOrganizationSettingsSyncGroupRulesOutputReference | TeamsOrganizationSettingsSyncGroupRules): any;
export declare class TeamsOrganizationSettingsSyncGroupRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamsOrganizationSettingsSyncGroupRules | undefined;
    set internalValue(value: TeamsOrganizationSettingsSyncGroupRules | undefined);
    private _conditions;
    get conditions(): TeamsOrganizationSettingsSyncGroupRulesConditionsList;
    putConditions(value: TeamsOrganizationSettingsSyncGroupRulesConditions[] | cdktn.IResolvable): void;
    get conditionsInput(): cdktn.IResolvable | TeamsOrganizationSettingsSyncGroupRulesConditions[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings newrelic_teams_organization_settings}
*/
export declare class TeamsOrganizationSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_teams_organization_settings";
    /**
    * Generates CDKTN code for importing a TeamsOrganizationSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamsOrganizationSettings to import
    * @param importFromId The id of the existing TeamsOrganizationSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamsOrganizationSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.6/docs/resources/teams_organization_settings newrelic_teams_organization_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamsOrganizationSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TeamsOrganizationSettingsConfig);
    private _discoveryEnabled?;
    get discoveryEnabled(): boolean | cdktn.IResolvable;
    set discoveryEnabled(value: boolean | cdktn.IResolvable);
    resetDiscoveryEnabled(): void;
    get discoveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _discoveryTagKeys?;
    get discoveryTagKeys(): string[];
    set discoveryTagKeys(value: string[]);
    resetDiscoveryTagKeys(): void;
    get discoveryTagKeysInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _syncGroupsEnabled?;
    get syncGroupsEnabled(): boolean | cdktn.IResolvable;
    set syncGroupsEnabled(value: boolean | cdktn.IResolvable);
    resetSyncGroupsEnabled(): void;
    get syncGroupsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _hierarchyLevels;
    get hierarchyLevels(): TeamsOrganizationSettingsHierarchyLevelsList;
    putHierarchyLevels(value: TeamsOrganizationSettingsHierarchyLevels[] | cdktn.IResolvable): void;
    resetHierarchyLevels(): void;
    get hierarchyLevelsInput(): cdktn.IResolvable | TeamsOrganizationSettingsHierarchyLevels[] | undefined;
    private _syncGroupRules;
    get syncGroupRules(): TeamsOrganizationSettingsSyncGroupRulesOutputReference;
    putSyncGroupRules(value: TeamsOrganizationSettingsSyncGroupRules): void;
    resetSyncGroupRules(): void;
    get syncGroupRulesInput(): TeamsOrganizationSettingsSyncGroupRules | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
