/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicTestGrokPatternConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id associated with the test grok.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/data-sources/test_grok_pattern#account_id DataNewrelicTestGrokPattern#account_id}
    */
    readonly accountId?: number;
    /**
    * The Grok pattern to test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/data-sources/test_grok_pattern#grok DataNewrelicTestGrokPattern#grok}
    */
    readonly grok: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/data-sources/test_grok_pattern#id DataNewrelicTestGrokPattern#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The log lines to test the Grok pattern against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/data-sources/test_grok_pattern#log_lines DataNewrelicTestGrokPattern#log_lines}
    */
    readonly logLines: string[];
}
export interface DataNewrelicTestGrokPatternTestGrokAttributes {
}
export declare function dataNewrelicTestGrokPatternTestGrokAttributesToTerraform(struct?: DataNewrelicTestGrokPatternTestGrokAttributes): any;
export declare function dataNewrelicTestGrokPatternTestGrokAttributesToHclTerraform(struct?: DataNewrelicTestGrokPatternTestGrokAttributes): any;
export declare class DataNewrelicTestGrokPatternTestGrokAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNewrelicTestGrokPatternTestGrokAttributes | undefined;
    set internalValue(value: DataNewrelicTestGrokPatternTestGrokAttributes | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataNewrelicTestGrokPatternTestGrokAttributesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNewrelicTestGrokPatternTestGrokAttributesOutputReference;
}
export interface DataNewrelicTestGrokPatternTestGrok {
}
export declare function dataNewrelicTestGrokPatternTestGrokToTerraform(struct?: DataNewrelicTestGrokPatternTestGrok): any;
export declare function dataNewrelicTestGrokPatternTestGrokToHclTerraform(struct?: DataNewrelicTestGrokPatternTestGrok): any;
export declare class DataNewrelicTestGrokPatternTestGrokOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNewrelicTestGrokPatternTestGrok | undefined;
    set internalValue(value: DataNewrelicTestGrokPatternTestGrok | undefined);
    private _attributes;
    get attributes(): DataNewrelicTestGrokPatternTestGrokAttributesList;
    get logLine(): string;
    get matched(): cdktn.IResolvable;
}
export declare class DataNewrelicTestGrokPatternTestGrokList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNewrelicTestGrokPatternTestGrokOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/data-sources/test_grok_pattern newrelic_test_grok_pattern}
*/
export declare class DataNewrelicTestGrokPattern extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_test_grok_pattern";
    /**
    * Generates CDKTN code for importing a DataNewrelicTestGrokPattern resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicTestGrokPattern to import
    * @param importFromId The id of the existing DataNewrelicTestGrokPattern that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/data-sources/test_grok_pattern#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicTestGrokPattern to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/data-sources/test_grok_pattern newrelic_test_grok_pattern} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicTestGrokPatternConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicTestGrokPatternConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _grok?;
    get grok(): string;
    set grok(value: string);
    get grokInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logLines?;
    get logLines(): string[];
    set logLines(value: string[]);
    get logLinesInput(): string[] | undefined;
    private _testGrok;
    get testGrok(): DataNewrelicTestGrokPatternTestGrokList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
