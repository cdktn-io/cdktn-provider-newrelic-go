/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudAwsIntegrationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the account in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#account_id CloudAwsIntegrations#account_id}
    */
    readonly accountId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#id CloudAwsIntegrations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the linked AWS account in New Relic
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#linked_account_id CloudAwsIntegrations#linked_account_id}
    */
    readonly linkedAccountId: number;
    /**
    * alb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#alb CloudAwsIntegrations#alb}
    */
    readonly alb?: CloudAwsIntegrationsAlb;
    /**
    * api_gateway block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#api_gateway CloudAwsIntegrations#api_gateway}
    */
    readonly apiGateway?: CloudAwsIntegrationsApiGateway;
    /**
    * auto_scaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#auto_scaling CloudAwsIntegrations#auto_scaling}
    */
    readonly autoScaling?: CloudAwsIntegrationsAutoScaling;
    /**
    * aws_app_sync block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_app_sync CloudAwsIntegrations#aws_app_sync}
    */
    readonly awsAppSync?: CloudAwsIntegrationsAwsAppSync;
    /**
    * aws_athena block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_athena CloudAwsIntegrations#aws_athena}
    */
    readonly awsAthena?: CloudAwsIntegrationsAwsAthena;
    /**
    * aws_auto_discovery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_auto_discovery CloudAwsIntegrations#aws_auto_discovery}
    */
    readonly awsAutoDiscovery?: CloudAwsIntegrationsAwsAutoDiscovery;
    /**
    * aws_cognito block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_cognito CloudAwsIntegrations#aws_cognito}
    */
    readonly awsCognito?: CloudAwsIntegrationsAwsCognito;
    /**
    * aws_connect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_connect CloudAwsIntegrations#aws_connect}
    */
    readonly awsConnect?: CloudAwsIntegrationsAwsConnect;
    /**
    * aws_direct_connect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_direct_connect CloudAwsIntegrations#aws_direct_connect}
    */
    readonly awsDirectConnect?: CloudAwsIntegrationsAwsDirectConnect;
    /**
    * aws_fsx block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_fsx CloudAwsIntegrations#aws_fsx}
    */
    readonly awsFsx?: CloudAwsIntegrationsAwsFsx;
    /**
    * aws_glue block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_glue CloudAwsIntegrations#aws_glue}
    */
    readonly awsGlue?: CloudAwsIntegrationsAwsGlue;
    /**
    * aws_kinesis_analytics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_kinesis_analytics CloudAwsIntegrations#aws_kinesis_analytics}
    */
    readonly awsKinesisAnalytics?: CloudAwsIntegrationsAwsKinesisAnalytics;
    /**
    * aws_media_convert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_media_convert CloudAwsIntegrations#aws_media_convert}
    */
    readonly awsMediaConvert?: CloudAwsIntegrationsAwsMediaConvert;
    /**
    * aws_media_package_vod block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_media_package_vod CloudAwsIntegrations#aws_media_package_vod}
    */
    readonly awsMediaPackageVod?: CloudAwsIntegrationsAwsMediaPackageVod;
    /**
    * aws_mq block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_mq CloudAwsIntegrations#aws_mq}
    */
    readonly awsMq?: CloudAwsIntegrationsAwsMq;
    /**
    * aws_msk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_msk CloudAwsIntegrations#aws_msk}
    */
    readonly awsMsk?: CloudAwsIntegrationsAwsMsk;
    /**
    * aws_neptune block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_neptune CloudAwsIntegrations#aws_neptune}
    */
    readonly awsNeptune?: CloudAwsIntegrationsAwsNeptune;
    /**
    * aws_qldb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_qldb CloudAwsIntegrations#aws_qldb}
    */
    readonly awsQldb?: CloudAwsIntegrationsAwsQldb;
    /**
    * aws_route53resolver block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_route53resolver CloudAwsIntegrations#aws_route53resolver}
    */
    readonly awsRoute53Resolver?: CloudAwsIntegrationsAwsRoute53Resolver;
    /**
    * aws_states block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_states CloudAwsIntegrations#aws_states}
    */
    readonly awsStates?: CloudAwsIntegrationsAwsStates;
    /**
    * aws_transit_gateway block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_transit_gateway CloudAwsIntegrations#aws_transit_gateway}
    */
    readonly awsTransitGateway?: CloudAwsIntegrationsAwsTransitGateway;
    /**
    * aws_waf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_waf CloudAwsIntegrations#aws_waf}
    */
    readonly awsWaf?: CloudAwsIntegrationsAwsWaf;
    /**
    * aws_wafv2 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_wafv2 CloudAwsIntegrations#aws_wafv2}
    */
    readonly awsWafv2?: CloudAwsIntegrationsAwsWafv2;
    /**
    * billing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#billing CloudAwsIntegrations#billing}
    */
    readonly billing?: CloudAwsIntegrationsBilling;
    /**
    * cloudfront block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#cloudfront CloudAwsIntegrations#cloudfront}
    */
    readonly cloudfront?: CloudAwsIntegrationsCloudfront;
    /**
    * cloudtrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#cloudtrail CloudAwsIntegrations#cloudtrail}
    */
    readonly cloudtrail?: CloudAwsIntegrationsCloudtrail;
    /**
    * doc_db block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#doc_db CloudAwsIntegrations#doc_db}
    */
    readonly docDb?: CloudAwsIntegrationsDocDb;
    /**
    * dynamodb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#dynamodb CloudAwsIntegrations#dynamodb}
    */
    readonly dynamodb?: CloudAwsIntegrationsDynamodb;
    /**
    * ebs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#ebs CloudAwsIntegrations#ebs}
    */
    readonly ebs?: CloudAwsIntegrationsEbs;
    /**
    * ec2 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#ec2 CloudAwsIntegrations#ec2}
    */
    readonly ec2?: CloudAwsIntegrationsEc2;
    /**
    * ecs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#ecs CloudAwsIntegrations#ecs}
    */
    readonly ecs?: CloudAwsIntegrationsEcs;
    /**
    * efs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#efs CloudAwsIntegrations#efs}
    */
    readonly efs?: CloudAwsIntegrationsEfs;
    /**
    * elasticache block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#elasticache CloudAwsIntegrations#elasticache}
    */
    readonly elasticache?: CloudAwsIntegrationsElasticache;
    /**
    * elasticbeanstalk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#elasticbeanstalk CloudAwsIntegrations#elasticbeanstalk}
    */
    readonly elasticbeanstalk?: CloudAwsIntegrationsElasticbeanstalk;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#elasticsearch CloudAwsIntegrations#elasticsearch}
    */
    readonly elasticsearch?: CloudAwsIntegrationsElasticsearch;
    /**
    * elb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#elb CloudAwsIntegrations#elb}
    */
    readonly elb?: CloudAwsIntegrationsElb;
    /**
    * emr block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#emr CloudAwsIntegrations#emr}
    */
    readonly emr?: CloudAwsIntegrationsEmr;
    /**
    * health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#health CloudAwsIntegrations#health}
    */
    readonly health?: CloudAwsIntegrationsHealth;
    /**
    * iam block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#iam CloudAwsIntegrations#iam}
    */
    readonly iam?: CloudAwsIntegrationsIam;
    /**
    * iot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#iot CloudAwsIntegrations#iot}
    */
    readonly iot?: CloudAwsIntegrationsIot;
    /**
    * kinesis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#kinesis CloudAwsIntegrations#kinesis}
    */
    readonly kinesis?: CloudAwsIntegrationsKinesis;
    /**
    * kinesis_firehose block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#kinesis_firehose CloudAwsIntegrations#kinesis_firehose}
    */
    readonly kinesisFirehose?: CloudAwsIntegrationsKinesisFirehose;
    /**
    * lambda block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#lambda CloudAwsIntegrations#lambda}
    */
    readonly lambda?: CloudAwsIntegrationsLambda;
    /**
    * rds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#rds CloudAwsIntegrations#rds}
    */
    readonly rds?: CloudAwsIntegrationsRds;
    /**
    * redshift block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#redshift CloudAwsIntegrations#redshift}
    */
    readonly redshift?: CloudAwsIntegrationsRedshift;
    /**
    * route53 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#route53 CloudAwsIntegrations#route53}
    */
    readonly route53?: CloudAwsIntegrationsRoute53;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#s3 CloudAwsIntegrations#s3}
    */
    readonly s3?: CloudAwsIntegrationsS3;
    /**
    * security_hub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#security_hub CloudAwsIntegrations#security_hub}
    */
    readonly securityHub?: CloudAwsIntegrationsSecurityHub;
    /**
    * ses block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#ses CloudAwsIntegrations#ses}
    */
    readonly ses?: CloudAwsIntegrationsSes;
    /**
    * sns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#sns CloudAwsIntegrations#sns}
    */
    readonly sns?: CloudAwsIntegrationsSns;
    /**
    * sqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#sqs CloudAwsIntegrations#sqs}
    */
    readonly sqs?: CloudAwsIntegrationsSqs;
    /**
    * trusted_advisor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#trusted_advisor CloudAwsIntegrations#trusted_advisor}
    */
    readonly trustedAdvisor?: CloudAwsIntegrationsTrustedAdvisor;
    /**
    * vpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#vpc CloudAwsIntegrations#vpc}
    */
    readonly vpc?: CloudAwsIntegrationsVpc;
    /**
    * x_ray block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#x_ray CloudAwsIntegrations#x_ray}
    */
    readonly xRay?: CloudAwsIntegrationsXRay;
}
export interface CloudAwsIntegrationsAlb {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_extended_inventory CloudAwsIntegrations#fetch_extended_inventory}
    */
    readonly fetchExtendedInventory?: boolean | cdktn.IResolvable;
    /**
    * Specify if tags should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * Specify each name or prefix for the LBs that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#load_balancer_prefixes CloudAwsIntegrations#load_balancer_prefixes}
    */
    readonly loadBalancerPrefixes?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsAlbToTerraform(struct?: CloudAwsIntegrationsAlbOutputReference | CloudAwsIntegrationsAlb): any;
export declare function cloudAwsIntegrationsAlbToHclTerraform(struct?: CloudAwsIntegrationsAlbOutputReference | CloudAwsIntegrationsAlb): any;
export declare class CloudAwsIntegrationsAlbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAlb | undefined;
    set internalValue(value: CloudAwsIntegrationsAlb | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchExtendedInventory?;
    get fetchExtendedInventory(): boolean | cdktn.IResolvable;
    set fetchExtendedInventory(value: boolean | cdktn.IResolvable);
    resetFetchExtendedInventory(): void;
    get fetchExtendedInventoryInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _loadBalancerPrefixes?;
    get loadBalancerPrefixes(): string[];
    set loadBalancerPrefixes(value: string[]);
    resetLoadBalancerPrefixes(): void;
    get loadBalancerPrefixesInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsApiGateway {
    /**
    * Specify each AWS region that includes the resources that you want to monitor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#stage_prefixes CloudAwsIntegrations#stage_prefixes}
    */
    readonly stagePrefixes?: string[];
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsApiGatewayToTerraform(struct?: CloudAwsIntegrationsApiGatewayOutputReference | CloudAwsIntegrationsApiGateway): any;
export declare function cloudAwsIntegrationsApiGatewayToHclTerraform(struct?: CloudAwsIntegrationsApiGatewayOutputReference | CloudAwsIntegrationsApiGateway): any;
export declare class CloudAwsIntegrationsApiGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsApiGateway | undefined;
    set internalValue(value: CloudAwsIntegrationsApiGateway | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _stagePrefixes?;
    get stagePrefixes(): string[];
    set stagePrefixes(value: string[]);
    resetStagePrefixes(): void;
    get stagePrefixesInput(): string[] | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsAutoScaling {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAutoScalingToTerraform(struct?: CloudAwsIntegrationsAutoScalingOutputReference | CloudAwsIntegrationsAutoScaling): any;
export declare function cloudAwsIntegrationsAutoScalingToHclTerraform(struct?: CloudAwsIntegrationsAutoScalingOutputReference | CloudAwsIntegrationsAutoScaling): any;
export declare class CloudAwsIntegrationsAutoScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAutoScaling | undefined;
    set internalValue(value: CloudAwsIntegrationsAutoScaling | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsAppSync {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsAppSyncToTerraform(struct?: CloudAwsIntegrationsAwsAppSyncOutputReference | CloudAwsIntegrationsAwsAppSync): any;
export declare function cloudAwsIntegrationsAwsAppSyncToHclTerraform(struct?: CloudAwsIntegrationsAwsAppSyncOutputReference | CloudAwsIntegrationsAwsAppSync): any;
export declare class CloudAwsIntegrationsAwsAppSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsAppSync | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsAppSync | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsAthena {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsAthenaToTerraform(struct?: CloudAwsIntegrationsAwsAthenaOutputReference | CloudAwsIntegrationsAwsAthena): any;
export declare function cloudAwsIntegrationsAwsAthenaToHclTerraform(struct?: CloudAwsIntegrationsAwsAthenaOutputReference | CloudAwsIntegrationsAwsAthena): any;
export declare class CloudAwsIntegrationsAwsAthenaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsAthena | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsAthena | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsAutoDiscovery {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsAutoDiscoveryToTerraform(struct?: CloudAwsIntegrationsAwsAutoDiscoveryOutputReference | CloudAwsIntegrationsAwsAutoDiscovery): any;
export declare function cloudAwsIntegrationsAwsAutoDiscoveryToHclTerraform(struct?: CloudAwsIntegrationsAwsAutoDiscoveryOutputReference | CloudAwsIntegrationsAwsAutoDiscovery): any;
export declare class CloudAwsIntegrationsAwsAutoDiscoveryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsAutoDiscovery | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsAutoDiscovery | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsCognito {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsCognitoToTerraform(struct?: CloudAwsIntegrationsAwsCognitoOutputReference | CloudAwsIntegrationsAwsCognito): any;
export declare function cloudAwsIntegrationsAwsCognitoToHclTerraform(struct?: CloudAwsIntegrationsAwsCognitoOutputReference | CloudAwsIntegrationsAwsCognito): any;
export declare class CloudAwsIntegrationsAwsCognitoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsCognito | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsCognito | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsConnect {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsConnectToTerraform(struct?: CloudAwsIntegrationsAwsConnectOutputReference | CloudAwsIntegrationsAwsConnect): any;
export declare function cloudAwsIntegrationsAwsConnectToHclTerraform(struct?: CloudAwsIntegrationsAwsConnectOutputReference | CloudAwsIntegrationsAwsConnect): any;
export declare class CloudAwsIntegrationsAwsConnectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsConnect | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsConnect | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsDirectConnect {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsDirectConnectToTerraform(struct?: CloudAwsIntegrationsAwsDirectConnectOutputReference | CloudAwsIntegrationsAwsDirectConnect): any;
export declare function cloudAwsIntegrationsAwsDirectConnectToHclTerraform(struct?: CloudAwsIntegrationsAwsDirectConnectOutputReference | CloudAwsIntegrationsAwsDirectConnect): any;
export declare class CloudAwsIntegrationsAwsDirectConnectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsDirectConnect | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsDirectConnect | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsFsx {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsFsxToTerraform(struct?: CloudAwsIntegrationsAwsFsxOutputReference | CloudAwsIntegrationsAwsFsx): any;
export declare function cloudAwsIntegrationsAwsFsxToHclTerraform(struct?: CloudAwsIntegrationsAwsFsxOutputReference | CloudAwsIntegrationsAwsFsx): any;
export declare class CloudAwsIntegrationsAwsFsxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsFsx | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsFsx | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsGlue {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsGlueToTerraform(struct?: CloudAwsIntegrationsAwsGlueOutputReference | CloudAwsIntegrationsAwsGlue): any;
export declare function cloudAwsIntegrationsAwsGlueToHclTerraform(struct?: CloudAwsIntegrationsAwsGlueOutputReference | CloudAwsIntegrationsAwsGlue): any;
export declare class CloudAwsIntegrationsAwsGlueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsGlue | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsGlue | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsKinesisAnalytics {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsKinesisAnalyticsToTerraform(struct?: CloudAwsIntegrationsAwsKinesisAnalyticsOutputReference | CloudAwsIntegrationsAwsKinesisAnalytics): any;
export declare function cloudAwsIntegrationsAwsKinesisAnalyticsToHclTerraform(struct?: CloudAwsIntegrationsAwsKinesisAnalyticsOutputReference | CloudAwsIntegrationsAwsKinesisAnalytics): any;
export declare class CloudAwsIntegrationsAwsKinesisAnalyticsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsKinesisAnalytics | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsKinesisAnalytics | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsMediaConvert {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsMediaConvertToTerraform(struct?: CloudAwsIntegrationsAwsMediaConvertOutputReference | CloudAwsIntegrationsAwsMediaConvert): any;
export declare function cloudAwsIntegrationsAwsMediaConvertToHclTerraform(struct?: CloudAwsIntegrationsAwsMediaConvertOutputReference | CloudAwsIntegrationsAwsMediaConvert): any;
export declare class CloudAwsIntegrationsAwsMediaConvertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsMediaConvert | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsMediaConvert | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsMediaPackageVod {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsMediaPackageVodToTerraform(struct?: CloudAwsIntegrationsAwsMediaPackageVodOutputReference | CloudAwsIntegrationsAwsMediaPackageVod): any;
export declare function cloudAwsIntegrationsAwsMediaPackageVodToHclTerraform(struct?: CloudAwsIntegrationsAwsMediaPackageVodOutputReference | CloudAwsIntegrationsAwsMediaPackageVod): any;
export declare class CloudAwsIntegrationsAwsMediaPackageVodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsMediaPackageVod | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsMediaPackageVod | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsMq {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsMqToTerraform(struct?: CloudAwsIntegrationsAwsMqOutputReference | CloudAwsIntegrationsAwsMq): any;
export declare function cloudAwsIntegrationsAwsMqToHclTerraform(struct?: CloudAwsIntegrationsAwsMqOutputReference | CloudAwsIntegrationsAwsMq): any;
export declare class CloudAwsIntegrationsAwsMqOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsMq | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsMq | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsMsk {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsMskToTerraform(struct?: CloudAwsIntegrationsAwsMskOutputReference | CloudAwsIntegrationsAwsMsk): any;
export declare function cloudAwsIntegrationsAwsMskToHclTerraform(struct?: CloudAwsIntegrationsAwsMskOutputReference | CloudAwsIntegrationsAwsMsk): any;
export declare class CloudAwsIntegrationsAwsMskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsMsk | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsMsk | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsNeptune {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsNeptuneToTerraform(struct?: CloudAwsIntegrationsAwsNeptuneOutputReference | CloudAwsIntegrationsAwsNeptune): any;
export declare function cloudAwsIntegrationsAwsNeptuneToHclTerraform(struct?: CloudAwsIntegrationsAwsNeptuneOutputReference | CloudAwsIntegrationsAwsNeptune): any;
export declare class CloudAwsIntegrationsAwsNeptuneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsNeptune | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsNeptune | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsQldb {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsQldbToTerraform(struct?: CloudAwsIntegrationsAwsQldbOutputReference | CloudAwsIntegrationsAwsQldb): any;
export declare function cloudAwsIntegrationsAwsQldbToHclTerraform(struct?: CloudAwsIntegrationsAwsQldbOutputReference | CloudAwsIntegrationsAwsQldb): any;
export declare class CloudAwsIntegrationsAwsQldbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsQldb | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsQldb | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsRoute53Resolver {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsRoute53ResolverToTerraform(struct?: CloudAwsIntegrationsAwsRoute53ResolverOutputReference | CloudAwsIntegrationsAwsRoute53Resolver): any;
export declare function cloudAwsIntegrationsAwsRoute53ResolverToHclTerraform(struct?: CloudAwsIntegrationsAwsRoute53ResolverOutputReference | CloudAwsIntegrationsAwsRoute53Resolver): any;
export declare class CloudAwsIntegrationsAwsRoute53ResolverOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsRoute53Resolver | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsRoute53Resolver | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsStates {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsStatesToTerraform(struct?: CloudAwsIntegrationsAwsStatesOutputReference | CloudAwsIntegrationsAwsStates): any;
export declare function cloudAwsIntegrationsAwsStatesToHclTerraform(struct?: CloudAwsIntegrationsAwsStatesOutputReference | CloudAwsIntegrationsAwsStates): any;
export declare class CloudAwsIntegrationsAwsStatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsStates | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsStates | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsTransitGateway {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsTransitGatewayToTerraform(struct?: CloudAwsIntegrationsAwsTransitGatewayOutputReference | CloudAwsIntegrationsAwsTransitGateway): any;
export declare function cloudAwsIntegrationsAwsTransitGatewayToHclTerraform(struct?: CloudAwsIntegrationsAwsTransitGatewayOutputReference | CloudAwsIntegrationsAwsTransitGateway): any;
export declare class CloudAwsIntegrationsAwsTransitGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsTransitGateway | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsTransitGateway | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsWaf {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsWafToTerraform(struct?: CloudAwsIntegrationsAwsWafOutputReference | CloudAwsIntegrationsAwsWaf): any;
export declare function cloudAwsIntegrationsAwsWafToHclTerraform(struct?: CloudAwsIntegrationsAwsWafOutputReference | CloudAwsIntegrationsAwsWaf): any;
export declare class CloudAwsIntegrationsAwsWafOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsWaf | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsWaf | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsAwsWafv2 {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsAwsWafv2ToTerraform(struct?: CloudAwsIntegrationsAwsWafv2OutputReference | CloudAwsIntegrationsAwsWafv2): any;
export declare function cloudAwsIntegrationsAwsWafv2ToHclTerraform(struct?: CloudAwsIntegrationsAwsWafv2OutputReference | CloudAwsIntegrationsAwsWafv2): any;
export declare class CloudAwsIntegrationsAwsWafv2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsAwsWafv2 | undefined;
    set internalValue(value: CloudAwsIntegrationsAwsWafv2 | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsBilling {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsBillingToTerraform(struct?: CloudAwsIntegrationsBillingOutputReference | CloudAwsIntegrationsBilling): any;
export declare function cloudAwsIntegrationsBillingToHclTerraform(struct?: CloudAwsIntegrationsBillingOutputReference | CloudAwsIntegrationsBilling): any;
export declare class CloudAwsIntegrationsBillingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsBilling | undefined;
    set internalValue(value: CloudAwsIntegrationsBilling | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsCloudfront {
    /**
    * Specify if Lambdas@Edge should be monitored. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_lambdas_at_edge CloudAwsIntegrations#fetch_lambdas_at_edge}
    */
    readonly fetchLambdasAtEdge?: boolean | cdktn.IResolvable;
    /**
    * Specify if tags should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsCloudfrontToTerraform(struct?: CloudAwsIntegrationsCloudfrontOutputReference | CloudAwsIntegrationsCloudfront): any;
export declare function cloudAwsIntegrationsCloudfrontToHclTerraform(struct?: CloudAwsIntegrationsCloudfrontOutputReference | CloudAwsIntegrationsCloudfront): any;
export declare class CloudAwsIntegrationsCloudfrontOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsCloudfront | undefined;
    set internalValue(value: CloudAwsIntegrationsCloudfront | undefined);
    private _fetchLambdasAtEdge?;
    get fetchLambdasAtEdge(): boolean | cdktn.IResolvable;
    set fetchLambdasAtEdge(value: boolean | cdktn.IResolvable);
    resetFetchLambdasAtEdge(): void;
    get fetchLambdasAtEdgeInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsCloudtrail {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsCloudtrailToTerraform(struct?: CloudAwsIntegrationsCloudtrailOutputReference | CloudAwsIntegrationsCloudtrail): any;
export declare function cloudAwsIntegrationsCloudtrailToHclTerraform(struct?: CloudAwsIntegrationsCloudtrailOutputReference | CloudAwsIntegrationsCloudtrail): any;
export declare class CloudAwsIntegrationsCloudtrailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsCloudtrail | undefined;
    set internalValue(value: CloudAwsIntegrationsCloudtrail | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsDocDb {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsDocDbToTerraform(struct?: CloudAwsIntegrationsDocDbOutputReference | CloudAwsIntegrationsDocDb): any;
export declare function cloudAwsIntegrationsDocDbToHclTerraform(struct?: CloudAwsIntegrationsDocDbOutputReference | CloudAwsIntegrationsDocDb): any;
export declare class CloudAwsIntegrationsDocDbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsDocDb | undefined;
    set internalValue(value: CloudAwsIntegrationsDocDb | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsDynamodb {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_extended_inventory CloudAwsIntegrations#fetch_extended_inventory}
    */
    readonly fetchExtendedInventory?: boolean | cdktn.IResolvable;
    /**
    * Specify if tags and the extended inventory should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsDynamodbToTerraform(struct?: CloudAwsIntegrationsDynamodbOutputReference | CloudAwsIntegrationsDynamodb): any;
export declare function cloudAwsIntegrationsDynamodbToHclTerraform(struct?: CloudAwsIntegrationsDynamodbOutputReference | CloudAwsIntegrationsDynamodb): any;
export declare class CloudAwsIntegrationsDynamodbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsDynamodb | undefined;
    set internalValue(value: CloudAwsIntegrationsDynamodb | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchExtendedInventory?;
    get fetchExtendedInventory(): boolean | cdktn.IResolvable;
    set fetchExtendedInventory(value: boolean | cdktn.IResolvable);
    resetFetchExtendedInventory(): void;
    get fetchExtendedInventoryInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsEbs {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_extended_inventory CloudAwsIntegrations#fetch_extended_inventory}
    */
    readonly fetchExtendedInventory?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsEbsToTerraform(struct?: CloudAwsIntegrationsEbsOutputReference | CloudAwsIntegrationsEbs): any;
export declare function cloudAwsIntegrationsEbsToHclTerraform(struct?: CloudAwsIntegrationsEbsOutputReference | CloudAwsIntegrationsEbs): any;
export declare class CloudAwsIntegrationsEbsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsEbs | undefined;
    set internalValue(value: CloudAwsIntegrationsEbs | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchExtendedInventory?;
    get fetchExtendedInventory(): boolean | cdktn.IResolvable;
    set fetchExtendedInventory(value: boolean | cdktn.IResolvable);
    resetFetchExtendedInventory(): void;
    get fetchExtendedInventoryInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsEc2 {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if the old legacy metadata and tag names have to be kept, it will consume more ingest data size
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#duplicate_ec2_tags CloudAwsIntegrations#duplicate_ec2_tags}
    */
    readonly duplicateEc2Tags?: boolean | cdktn.IResolvable;
    /**
    * Specify if IP addresses of ec2 instance should be collected
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_ip_addresses CloudAwsIntegrations#fetch_ip_addresses}
    */
    readonly fetchIpAddresses?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsEc2ToTerraform(struct?: CloudAwsIntegrationsEc2OutputReference | CloudAwsIntegrationsEc2): any;
export declare function cloudAwsIntegrationsEc2ToHclTerraform(struct?: CloudAwsIntegrationsEc2OutputReference | CloudAwsIntegrationsEc2): any;
export declare class CloudAwsIntegrationsEc2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsEc2 | undefined;
    set internalValue(value: CloudAwsIntegrationsEc2 | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _duplicateEc2Tags?;
    get duplicateEc2Tags(): boolean | cdktn.IResolvable;
    set duplicateEc2Tags(value: boolean | cdktn.IResolvable);
    resetDuplicateEc2Tags(): void;
    get duplicateEc2TagsInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchIpAddresses?;
    get fetchIpAddresses(): boolean | cdktn.IResolvable;
    set fetchIpAddresses(value: boolean | cdktn.IResolvable);
    resetFetchIpAddresses(): void;
    get fetchIpAddressesInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsEcs {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if tags and the extended inventory should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsEcsToTerraform(struct?: CloudAwsIntegrationsEcsOutputReference | CloudAwsIntegrationsEcs): any;
export declare function cloudAwsIntegrationsEcsToHclTerraform(struct?: CloudAwsIntegrationsEcsOutputReference | CloudAwsIntegrationsEcs): any;
export declare class CloudAwsIntegrationsEcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsEcs | undefined;
    set internalValue(value: CloudAwsIntegrationsEcs | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsEfs {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if tags and the extended inventory should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsEfsToTerraform(struct?: CloudAwsIntegrationsEfsOutputReference | CloudAwsIntegrationsEfs): any;
export declare function cloudAwsIntegrationsEfsToHclTerraform(struct?: CloudAwsIntegrationsEfsOutputReference | CloudAwsIntegrationsEfs): any;
export declare class CloudAwsIntegrationsEfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsEfs | undefined;
    set internalValue(value: CloudAwsIntegrationsEfs | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsElasticache {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if tags should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsElasticacheToTerraform(struct?: CloudAwsIntegrationsElasticacheOutputReference | CloudAwsIntegrationsElasticache): any;
export declare function cloudAwsIntegrationsElasticacheToHclTerraform(struct?: CloudAwsIntegrationsElasticacheOutputReference | CloudAwsIntegrationsElasticache): any;
export declare class CloudAwsIntegrationsElasticacheOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsElasticache | undefined;
    set internalValue(value: CloudAwsIntegrationsElasticache | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsElasticbeanstalk {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_extended_inventory CloudAwsIntegrations#fetch_extended_inventory}
    */
    readonly fetchExtendedInventory?: boolean | cdktn.IResolvable;
    /**
    * Specify if tags and the extended inventory should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsElasticbeanstalkToTerraform(struct?: CloudAwsIntegrationsElasticbeanstalkOutputReference | CloudAwsIntegrationsElasticbeanstalk): any;
export declare function cloudAwsIntegrationsElasticbeanstalkToHclTerraform(struct?: CloudAwsIntegrationsElasticbeanstalkOutputReference | CloudAwsIntegrationsElasticbeanstalk): any;
export declare class CloudAwsIntegrationsElasticbeanstalkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsElasticbeanstalk | undefined;
    set internalValue(value: CloudAwsIntegrationsElasticbeanstalk | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchExtendedInventory?;
    get fetchExtendedInventory(): boolean | cdktn.IResolvable;
    set fetchExtendedInventory(value: boolean | cdktn.IResolvable);
    resetFetchExtendedInventory(): void;
    get fetchExtendedInventoryInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsElasticsearch {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if metrics should be collected for nodes. Turning it on will increase the number of API calls made to CloudWatch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_nodes CloudAwsIntegrations#fetch_nodes}
    */
    readonly fetchNodes?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsElasticsearchToTerraform(struct?: CloudAwsIntegrationsElasticsearchOutputReference | CloudAwsIntegrationsElasticsearch): any;
export declare function cloudAwsIntegrationsElasticsearchToHclTerraform(struct?: CloudAwsIntegrationsElasticsearchOutputReference | CloudAwsIntegrationsElasticsearch): any;
export declare class CloudAwsIntegrationsElasticsearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsElasticsearch | undefined;
    set internalValue(value: CloudAwsIntegrationsElasticsearch | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchNodes?;
    get fetchNodes(): boolean | cdktn.IResolvable;
    set fetchNodes(value: boolean | cdktn.IResolvable);
    resetFetchNodes(): void;
    get fetchNodesInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsElb {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_extended_inventory CloudAwsIntegrations#fetch_extended_inventory}
    */
    readonly fetchExtendedInventory?: boolean | cdktn.IResolvable;
    /**
    * Specify if tags should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsElbToTerraform(struct?: CloudAwsIntegrationsElbOutputReference | CloudAwsIntegrationsElb): any;
export declare function cloudAwsIntegrationsElbToHclTerraform(struct?: CloudAwsIntegrationsElbOutputReference | CloudAwsIntegrationsElb): any;
export declare class CloudAwsIntegrationsElbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsElb | undefined;
    set internalValue(value: CloudAwsIntegrationsElb | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchExtendedInventory?;
    get fetchExtendedInventory(): boolean | cdktn.IResolvable;
    set fetchExtendedInventory(value: boolean | cdktn.IResolvable);
    resetFetchExtendedInventory(): void;
    get fetchExtendedInventoryInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsEmr {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if tags and the extended inventory should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsEmrToTerraform(struct?: CloudAwsIntegrationsEmrOutputReference | CloudAwsIntegrationsEmr): any;
export declare function cloudAwsIntegrationsEmrToHclTerraform(struct?: CloudAwsIntegrationsEmrOutputReference | CloudAwsIntegrationsEmr): any;
export declare class CloudAwsIntegrationsEmrOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsEmr | undefined;
    set internalValue(value: CloudAwsIntegrationsEmr | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsHealth {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsHealthToTerraform(struct?: CloudAwsIntegrationsHealthOutputReference | CloudAwsIntegrationsHealth): any;
export declare function cloudAwsIntegrationsHealthToHclTerraform(struct?: CloudAwsIntegrationsHealthOutputReference | CloudAwsIntegrationsHealth): any;
export declare class CloudAwsIntegrationsHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsHealth | undefined;
    set internalValue(value: CloudAwsIntegrationsHealth | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsIam {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsIamToTerraform(struct?: CloudAwsIntegrationsIamOutputReference | CloudAwsIntegrationsIam): any;
export declare function cloudAwsIntegrationsIamToHclTerraform(struct?: CloudAwsIntegrationsIamOutputReference | CloudAwsIntegrationsIam): any;
export declare class CloudAwsIntegrationsIamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsIam | undefined;
    set internalValue(value: CloudAwsIntegrationsIam | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsIot {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsIotToTerraform(struct?: CloudAwsIntegrationsIotOutputReference | CloudAwsIntegrationsIot): any;
export declare function cloudAwsIntegrationsIotToHclTerraform(struct?: CloudAwsIntegrationsIotOutputReference | CloudAwsIntegrationsIot): any;
export declare class CloudAwsIntegrationsIotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsIot | undefined;
    set internalValue(value: CloudAwsIntegrationsIot | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsKinesis {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if Shards should be monitored. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_shards CloudAwsIntegrations#fetch_shards}
    */
    readonly fetchShards?: boolean | cdktn.IResolvable;
    /**
    * Specify if tags and the extended inventory should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsKinesisToTerraform(struct?: CloudAwsIntegrationsKinesisOutputReference | CloudAwsIntegrationsKinesis): any;
export declare function cloudAwsIntegrationsKinesisToHclTerraform(struct?: CloudAwsIntegrationsKinesisOutputReference | CloudAwsIntegrationsKinesis): any;
export declare class CloudAwsIntegrationsKinesisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsKinesis | undefined;
    set internalValue(value: CloudAwsIntegrationsKinesis | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchShards?;
    get fetchShards(): boolean | cdktn.IResolvable;
    set fetchShards(value: boolean | cdktn.IResolvable);
    resetFetchShards(): void;
    get fetchShardsInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsKinesisFirehose {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsKinesisFirehoseToTerraform(struct?: CloudAwsIntegrationsKinesisFirehoseOutputReference | CloudAwsIntegrationsKinesisFirehose): any;
export declare function cloudAwsIntegrationsKinesisFirehoseToHclTerraform(struct?: CloudAwsIntegrationsKinesisFirehoseOutputReference | CloudAwsIntegrationsKinesisFirehose): any;
export declare class CloudAwsIntegrationsKinesisFirehoseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsKinesisFirehose | undefined;
    set internalValue(value: CloudAwsIntegrationsKinesisFirehose | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsLambda {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if tags and the extended inventory should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsLambdaToTerraform(struct?: CloudAwsIntegrationsLambdaOutputReference | CloudAwsIntegrationsLambda): any;
export declare function cloudAwsIntegrationsLambdaToHclTerraform(struct?: CloudAwsIntegrationsLambdaOutputReference | CloudAwsIntegrationsLambda): any;
export declare class CloudAwsIntegrationsLambdaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsLambda | undefined;
    set internalValue(value: CloudAwsIntegrationsLambda | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsRds {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if tags and the extended inventory should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsRdsToTerraform(struct?: CloudAwsIntegrationsRdsOutputReference | CloudAwsIntegrationsRds): any;
export declare function cloudAwsIntegrationsRdsToHclTerraform(struct?: CloudAwsIntegrationsRdsOutputReference | CloudAwsIntegrationsRds): any;
export declare class CloudAwsIntegrationsRdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsRds | undefined;
    set internalValue(value: CloudAwsIntegrationsRds | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsRedshift {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsRedshiftToTerraform(struct?: CloudAwsIntegrationsRedshiftOutputReference | CloudAwsIntegrationsRedshift): any;
export declare function cloudAwsIntegrationsRedshiftToHclTerraform(struct?: CloudAwsIntegrationsRedshiftOutputReference | CloudAwsIntegrationsRedshift): any;
export declare class CloudAwsIntegrationsRedshiftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsRedshift | undefined;
    set internalValue(value: CloudAwsIntegrationsRedshift | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsRoute53 {
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_extended_inventory CloudAwsIntegrations#fetch_extended_inventory}
    */
    readonly fetchExtendedInventory?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsRoute53ToTerraform(struct?: CloudAwsIntegrationsRoute53OutputReference | CloudAwsIntegrationsRoute53): any;
export declare function cloudAwsIntegrationsRoute53ToHclTerraform(struct?: CloudAwsIntegrationsRoute53OutputReference | CloudAwsIntegrationsRoute53): any;
export declare class CloudAwsIntegrationsRoute53OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsRoute53 | undefined;
    set internalValue(value: CloudAwsIntegrationsRoute53 | undefined);
    private _fetchExtendedInventory?;
    get fetchExtendedInventory(): boolean | cdktn.IResolvable;
    set fetchExtendedInventory(value: boolean | cdktn.IResolvable);
    resetFetchExtendedInventory(): void;
    get fetchExtendedInventoryInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsS3 {
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_extended_inventory CloudAwsIntegrations#fetch_extended_inventory}
    */
    readonly fetchExtendedInventory?: boolean | cdktn.IResolvable;
    /**
    * Specify if tags should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsS3ToTerraform(struct?: CloudAwsIntegrationsS3OutputReference | CloudAwsIntegrationsS3): any;
export declare function cloudAwsIntegrationsS3ToHclTerraform(struct?: CloudAwsIntegrationsS3OutputReference | CloudAwsIntegrationsS3): any;
export declare class CloudAwsIntegrationsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsS3 | undefined;
    set internalValue(value: CloudAwsIntegrationsS3 | undefined);
    private _fetchExtendedInventory?;
    get fetchExtendedInventory(): boolean | cdktn.IResolvable;
    set fetchExtendedInventory(value: boolean | cdktn.IResolvable);
    resetFetchExtendedInventory(): void;
    get fetchExtendedInventoryInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsSecurityHub {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsSecurityHubToTerraform(struct?: CloudAwsIntegrationsSecurityHubOutputReference | CloudAwsIntegrationsSecurityHub): any;
export declare function cloudAwsIntegrationsSecurityHubToHclTerraform(struct?: CloudAwsIntegrationsSecurityHubOutputReference | CloudAwsIntegrationsSecurityHub): any;
export declare class CloudAwsIntegrationsSecurityHubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsSecurityHub | undefined;
    set internalValue(value: CloudAwsIntegrationsSecurityHub | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsSes {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsSesToTerraform(struct?: CloudAwsIntegrationsSesOutputReference | CloudAwsIntegrationsSes): any;
export declare function cloudAwsIntegrationsSesToHclTerraform(struct?: CloudAwsIntegrationsSesOutputReference | CloudAwsIntegrationsSes): any;
export declare class CloudAwsIntegrationsSesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsSes | undefined;
    set internalValue(value: CloudAwsIntegrationsSes | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsSns {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_extended_inventory CloudAwsIntegrations#fetch_extended_inventory}
    */
    readonly fetchExtendedInventory?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsSnsToTerraform(struct?: CloudAwsIntegrationsSnsOutputReference | CloudAwsIntegrationsSns): any;
export declare function cloudAwsIntegrationsSnsToHclTerraform(struct?: CloudAwsIntegrationsSnsOutputReference | CloudAwsIntegrationsSns): any;
export declare class CloudAwsIntegrationsSnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsSns | undefined;
    set internalValue(value: CloudAwsIntegrationsSns | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchExtendedInventory?;
    get fetchExtendedInventory(): boolean | cdktn.IResolvable;
    set fetchExtendedInventory(value: boolean | cdktn.IResolvable);
    resetFetchExtendedInventory(): void;
    get fetchExtendedInventoryInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsSqs {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Determine if extra inventory data be collected or not. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_extended_inventory CloudAwsIntegrations#fetch_extended_inventory}
    */
    readonly fetchExtendedInventory?: boolean | cdktn.IResolvable;
    /**
    * Specify if tags should be collected. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_tags CloudAwsIntegrations#fetch_tags}
    */
    readonly fetchTags?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify each name or prefix for the Queues that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#queue_prefixes CloudAwsIntegrations#queue_prefixes}
    */
    readonly queuePrefixes?: string[];
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsSqsToTerraform(struct?: CloudAwsIntegrationsSqsOutputReference | CloudAwsIntegrationsSqs): any;
export declare function cloudAwsIntegrationsSqsToHclTerraform(struct?: CloudAwsIntegrationsSqsOutputReference | CloudAwsIntegrationsSqs): any;
export declare class CloudAwsIntegrationsSqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsSqs | undefined;
    set internalValue(value: CloudAwsIntegrationsSqs | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchExtendedInventory?;
    get fetchExtendedInventory(): boolean | cdktn.IResolvable;
    set fetchExtendedInventory(value: boolean | cdktn.IResolvable);
    resetFetchExtendedInventory(): void;
    get fetchExtendedInventoryInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchTags?;
    get fetchTags(): boolean | cdktn.IResolvable;
    set fetchTags(value: boolean | cdktn.IResolvable);
    resetFetchTags(): void;
    get fetchTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _queuePrefixes?;
    get queuePrefixes(): string[];
    set queuePrefixes(value: string[]);
    resetQueuePrefixes(): void;
    get queuePrefixesInput(): string[] | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsTrustedAdvisor {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsTrustedAdvisorToTerraform(struct?: CloudAwsIntegrationsTrustedAdvisorOutputReference | CloudAwsIntegrationsTrustedAdvisor): any;
export declare function cloudAwsIntegrationsTrustedAdvisorToHclTerraform(struct?: CloudAwsIntegrationsTrustedAdvisorOutputReference | CloudAwsIntegrationsTrustedAdvisor): any;
export declare class CloudAwsIntegrationsTrustedAdvisorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsTrustedAdvisor | undefined;
    set internalValue(value: CloudAwsIntegrationsTrustedAdvisor | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudAwsIntegrationsVpc {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * Specify if NAT gateway should be monitored. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_nat_gateway CloudAwsIntegrations#fetch_nat_gateway}
    */
    readonly fetchNatGateway?: boolean | cdktn.IResolvable;
    /**
    * Specify if VPN should be monitored. May affect total data collection time and contribute to the Cloud provider API rate limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#fetch_vpn CloudAwsIntegrations#fetch_vpn}
    */
    readonly fetchVpn?: boolean | cdktn.IResolvable;
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
    /**
    * Specify a Tag key associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_key CloudAwsIntegrations#tag_key}
    */
    readonly tagKey?: string;
    /**
    * Specify a Tag value associated with the resources that you want to monitor. Filter values are case-sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#tag_value CloudAwsIntegrations#tag_value}
    */
    readonly tagValue?: string;
}
export declare function cloudAwsIntegrationsVpcToTerraform(struct?: CloudAwsIntegrationsVpcOutputReference | CloudAwsIntegrationsVpc): any;
export declare function cloudAwsIntegrationsVpcToHclTerraform(struct?: CloudAwsIntegrationsVpcOutputReference | CloudAwsIntegrationsVpc): any;
export declare class CloudAwsIntegrationsVpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsVpc | undefined;
    set internalValue(value: CloudAwsIntegrationsVpc | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _fetchNatGateway?;
    get fetchNatGateway(): boolean | cdktn.IResolvable;
    set fetchNatGateway(value: boolean | cdktn.IResolvable);
    resetFetchNatGateway(): void;
    get fetchNatGatewayInput(): boolean | cdktn.IResolvable | undefined;
    private _fetchVpn?;
    get fetchVpn(): boolean | cdktn.IResolvable;
    set fetchVpn(value: boolean | cdktn.IResolvable);
    resetFetchVpn(): void;
    get fetchVpnInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
}
export interface CloudAwsIntegrationsXRay {
    /**
    * Specify each AWS region that includes the resources that you want to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#aws_regions CloudAwsIntegrations#aws_regions}
    */
    readonly awsRegions?: string[];
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#metrics_polling_interval CloudAwsIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudAwsIntegrationsXRayToTerraform(struct?: CloudAwsIntegrationsXRayOutputReference | CloudAwsIntegrationsXRay): any;
export declare function cloudAwsIntegrationsXRayToHclTerraform(struct?: CloudAwsIntegrationsXRayOutputReference | CloudAwsIntegrationsXRay): any;
export declare class CloudAwsIntegrationsXRayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudAwsIntegrationsXRay | undefined;
    set internalValue(value: CloudAwsIntegrationsXRay | undefined);
    private _awsRegions?;
    get awsRegions(): string[];
    set awsRegions(value: string[]);
    resetAwsRegions(): void;
    get awsRegionsInput(): string[] | undefined;
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations newrelic_cloud_aws_integrations}
*/
export declare class CloudAwsIntegrations extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_cloud_aws_integrations";
    /**
    * Generates CDKTN code for importing a CloudAwsIntegrations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudAwsIntegrations to import
    * @param importFromId The id of the existing CloudAwsIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudAwsIntegrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/cloud_aws_integrations newrelic_cloud_aws_integrations} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudAwsIntegrationsConfig
    */
    constructor(scope: Construct, id: string, config: CloudAwsIntegrationsConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _linkedAccountId?;
    get linkedAccountId(): number;
    set linkedAccountId(value: number);
    get linkedAccountIdInput(): number | undefined;
    private _alb;
    get alb(): CloudAwsIntegrationsAlbOutputReference;
    putAlb(value: CloudAwsIntegrationsAlb): void;
    resetAlb(): void;
    get albInput(): CloudAwsIntegrationsAlb | undefined;
    private _apiGateway;
    get apiGateway(): CloudAwsIntegrationsApiGatewayOutputReference;
    putApiGateway(value: CloudAwsIntegrationsApiGateway): void;
    resetApiGateway(): void;
    get apiGatewayInput(): CloudAwsIntegrationsApiGateway | undefined;
    private _autoScaling;
    get autoScaling(): CloudAwsIntegrationsAutoScalingOutputReference;
    putAutoScaling(value: CloudAwsIntegrationsAutoScaling): void;
    resetAutoScaling(): void;
    get autoScalingInput(): CloudAwsIntegrationsAutoScaling | undefined;
    private _awsAppSync;
    get awsAppSync(): CloudAwsIntegrationsAwsAppSyncOutputReference;
    putAwsAppSync(value: CloudAwsIntegrationsAwsAppSync): void;
    resetAwsAppSync(): void;
    get awsAppSyncInput(): CloudAwsIntegrationsAwsAppSync | undefined;
    private _awsAthena;
    get awsAthena(): CloudAwsIntegrationsAwsAthenaOutputReference;
    putAwsAthena(value: CloudAwsIntegrationsAwsAthena): void;
    resetAwsAthena(): void;
    get awsAthenaInput(): CloudAwsIntegrationsAwsAthena | undefined;
    private _awsAutoDiscovery;
    get awsAutoDiscovery(): CloudAwsIntegrationsAwsAutoDiscoveryOutputReference;
    putAwsAutoDiscovery(value: CloudAwsIntegrationsAwsAutoDiscovery): void;
    resetAwsAutoDiscovery(): void;
    get awsAutoDiscoveryInput(): CloudAwsIntegrationsAwsAutoDiscovery | undefined;
    private _awsCognito;
    get awsCognito(): CloudAwsIntegrationsAwsCognitoOutputReference;
    putAwsCognito(value: CloudAwsIntegrationsAwsCognito): void;
    resetAwsCognito(): void;
    get awsCognitoInput(): CloudAwsIntegrationsAwsCognito | undefined;
    private _awsConnect;
    get awsConnect(): CloudAwsIntegrationsAwsConnectOutputReference;
    putAwsConnect(value: CloudAwsIntegrationsAwsConnect): void;
    resetAwsConnect(): void;
    get awsConnectInput(): CloudAwsIntegrationsAwsConnect | undefined;
    private _awsDirectConnect;
    get awsDirectConnect(): CloudAwsIntegrationsAwsDirectConnectOutputReference;
    putAwsDirectConnect(value: CloudAwsIntegrationsAwsDirectConnect): void;
    resetAwsDirectConnect(): void;
    get awsDirectConnectInput(): CloudAwsIntegrationsAwsDirectConnect | undefined;
    private _awsFsx;
    get awsFsx(): CloudAwsIntegrationsAwsFsxOutputReference;
    putAwsFsx(value: CloudAwsIntegrationsAwsFsx): void;
    resetAwsFsx(): void;
    get awsFsxInput(): CloudAwsIntegrationsAwsFsx | undefined;
    private _awsGlue;
    get awsGlue(): CloudAwsIntegrationsAwsGlueOutputReference;
    putAwsGlue(value: CloudAwsIntegrationsAwsGlue): void;
    resetAwsGlue(): void;
    get awsGlueInput(): CloudAwsIntegrationsAwsGlue | undefined;
    private _awsKinesisAnalytics;
    get awsKinesisAnalytics(): CloudAwsIntegrationsAwsKinesisAnalyticsOutputReference;
    putAwsKinesisAnalytics(value: CloudAwsIntegrationsAwsKinesisAnalytics): void;
    resetAwsKinesisAnalytics(): void;
    get awsKinesisAnalyticsInput(): CloudAwsIntegrationsAwsKinesisAnalytics | undefined;
    private _awsMediaConvert;
    get awsMediaConvert(): CloudAwsIntegrationsAwsMediaConvertOutputReference;
    putAwsMediaConvert(value: CloudAwsIntegrationsAwsMediaConvert): void;
    resetAwsMediaConvert(): void;
    get awsMediaConvertInput(): CloudAwsIntegrationsAwsMediaConvert | undefined;
    private _awsMediaPackageVod;
    get awsMediaPackageVod(): CloudAwsIntegrationsAwsMediaPackageVodOutputReference;
    putAwsMediaPackageVod(value: CloudAwsIntegrationsAwsMediaPackageVod): void;
    resetAwsMediaPackageVod(): void;
    get awsMediaPackageVodInput(): CloudAwsIntegrationsAwsMediaPackageVod | undefined;
    private _awsMq;
    get awsMq(): CloudAwsIntegrationsAwsMqOutputReference;
    putAwsMq(value: CloudAwsIntegrationsAwsMq): void;
    resetAwsMq(): void;
    get awsMqInput(): CloudAwsIntegrationsAwsMq | undefined;
    private _awsMsk;
    get awsMsk(): CloudAwsIntegrationsAwsMskOutputReference;
    putAwsMsk(value: CloudAwsIntegrationsAwsMsk): void;
    resetAwsMsk(): void;
    get awsMskInput(): CloudAwsIntegrationsAwsMsk | undefined;
    private _awsNeptune;
    get awsNeptune(): CloudAwsIntegrationsAwsNeptuneOutputReference;
    putAwsNeptune(value: CloudAwsIntegrationsAwsNeptune): void;
    resetAwsNeptune(): void;
    get awsNeptuneInput(): CloudAwsIntegrationsAwsNeptune | undefined;
    private _awsQldb;
    get awsQldb(): CloudAwsIntegrationsAwsQldbOutputReference;
    putAwsQldb(value: CloudAwsIntegrationsAwsQldb): void;
    resetAwsQldb(): void;
    get awsQldbInput(): CloudAwsIntegrationsAwsQldb | undefined;
    private _awsRoute53Resolver;
    get awsRoute53Resolver(): CloudAwsIntegrationsAwsRoute53ResolverOutputReference;
    putAwsRoute53Resolver(value: CloudAwsIntegrationsAwsRoute53Resolver): void;
    resetAwsRoute53Resolver(): void;
    get awsRoute53ResolverInput(): CloudAwsIntegrationsAwsRoute53Resolver | undefined;
    private _awsStates;
    get awsStates(): CloudAwsIntegrationsAwsStatesOutputReference;
    putAwsStates(value: CloudAwsIntegrationsAwsStates): void;
    resetAwsStates(): void;
    get awsStatesInput(): CloudAwsIntegrationsAwsStates | undefined;
    private _awsTransitGateway;
    get awsTransitGateway(): CloudAwsIntegrationsAwsTransitGatewayOutputReference;
    putAwsTransitGateway(value: CloudAwsIntegrationsAwsTransitGateway): void;
    resetAwsTransitGateway(): void;
    get awsTransitGatewayInput(): CloudAwsIntegrationsAwsTransitGateway | undefined;
    private _awsWaf;
    get awsWaf(): CloudAwsIntegrationsAwsWafOutputReference;
    putAwsWaf(value: CloudAwsIntegrationsAwsWaf): void;
    resetAwsWaf(): void;
    get awsWafInput(): CloudAwsIntegrationsAwsWaf | undefined;
    private _awsWafv2;
    get awsWafv2(): CloudAwsIntegrationsAwsWafv2OutputReference;
    putAwsWafv2(value: CloudAwsIntegrationsAwsWafv2): void;
    resetAwsWafv2(): void;
    get awsWafv2Input(): CloudAwsIntegrationsAwsWafv2 | undefined;
    private _billing;
    get billing(): CloudAwsIntegrationsBillingOutputReference;
    putBilling(value: CloudAwsIntegrationsBilling): void;
    resetBilling(): void;
    get billingInput(): CloudAwsIntegrationsBilling | undefined;
    private _cloudfront;
    get cloudfront(): CloudAwsIntegrationsCloudfrontOutputReference;
    putCloudfront(value: CloudAwsIntegrationsCloudfront): void;
    resetCloudfront(): void;
    get cloudfrontInput(): CloudAwsIntegrationsCloudfront | undefined;
    private _cloudtrail;
    get cloudtrail(): CloudAwsIntegrationsCloudtrailOutputReference;
    putCloudtrail(value: CloudAwsIntegrationsCloudtrail): void;
    resetCloudtrail(): void;
    get cloudtrailInput(): CloudAwsIntegrationsCloudtrail | undefined;
    private _docDb;
    get docDb(): CloudAwsIntegrationsDocDbOutputReference;
    putDocDb(value: CloudAwsIntegrationsDocDb): void;
    resetDocDb(): void;
    get docDbInput(): CloudAwsIntegrationsDocDb | undefined;
    private _dynamodb;
    get dynamodb(): CloudAwsIntegrationsDynamodbOutputReference;
    putDynamodb(value: CloudAwsIntegrationsDynamodb): void;
    resetDynamodb(): void;
    get dynamodbInput(): CloudAwsIntegrationsDynamodb | undefined;
    private _ebs;
    get ebs(): CloudAwsIntegrationsEbsOutputReference;
    putEbs(value: CloudAwsIntegrationsEbs): void;
    resetEbs(): void;
    get ebsInput(): CloudAwsIntegrationsEbs | undefined;
    private _ec2;
    get ec2(): CloudAwsIntegrationsEc2OutputReference;
    putEc2(value: CloudAwsIntegrationsEc2): void;
    resetEc2(): void;
    get ec2Input(): CloudAwsIntegrationsEc2 | undefined;
    private _ecs;
    get ecs(): CloudAwsIntegrationsEcsOutputReference;
    putEcs(value: CloudAwsIntegrationsEcs): void;
    resetEcs(): void;
    get ecsInput(): CloudAwsIntegrationsEcs | undefined;
    private _efs;
    get efs(): CloudAwsIntegrationsEfsOutputReference;
    putEfs(value: CloudAwsIntegrationsEfs): void;
    resetEfs(): void;
    get efsInput(): CloudAwsIntegrationsEfs | undefined;
    private _elasticache;
    get elasticache(): CloudAwsIntegrationsElasticacheOutputReference;
    putElasticache(value: CloudAwsIntegrationsElasticache): void;
    resetElasticache(): void;
    get elasticacheInput(): CloudAwsIntegrationsElasticache | undefined;
    private _elasticbeanstalk;
    get elasticbeanstalk(): CloudAwsIntegrationsElasticbeanstalkOutputReference;
    putElasticbeanstalk(value: CloudAwsIntegrationsElasticbeanstalk): void;
    resetElasticbeanstalk(): void;
    get elasticbeanstalkInput(): CloudAwsIntegrationsElasticbeanstalk | undefined;
    private _elasticsearch;
    get elasticsearch(): CloudAwsIntegrationsElasticsearchOutputReference;
    putElasticsearch(value: CloudAwsIntegrationsElasticsearch): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): CloudAwsIntegrationsElasticsearch | undefined;
    private _elb;
    get elb(): CloudAwsIntegrationsElbOutputReference;
    putElb(value: CloudAwsIntegrationsElb): void;
    resetElb(): void;
    get elbInput(): CloudAwsIntegrationsElb | undefined;
    private _emr;
    get emr(): CloudAwsIntegrationsEmrOutputReference;
    putEmr(value: CloudAwsIntegrationsEmr): void;
    resetEmr(): void;
    get emrInput(): CloudAwsIntegrationsEmr | undefined;
    private _health;
    get health(): CloudAwsIntegrationsHealthOutputReference;
    putHealth(value: CloudAwsIntegrationsHealth): void;
    resetHealth(): void;
    get healthInput(): CloudAwsIntegrationsHealth | undefined;
    private _iam;
    get iam(): CloudAwsIntegrationsIamOutputReference;
    putIam(value: CloudAwsIntegrationsIam): void;
    resetIam(): void;
    get iamInput(): CloudAwsIntegrationsIam | undefined;
    private _iot;
    get iot(): CloudAwsIntegrationsIotOutputReference;
    putIot(value: CloudAwsIntegrationsIot): void;
    resetIot(): void;
    get iotInput(): CloudAwsIntegrationsIot | undefined;
    private _kinesis;
    get kinesis(): CloudAwsIntegrationsKinesisOutputReference;
    putKinesis(value: CloudAwsIntegrationsKinesis): void;
    resetKinesis(): void;
    get kinesisInput(): CloudAwsIntegrationsKinesis | undefined;
    private _kinesisFirehose;
    get kinesisFirehose(): CloudAwsIntegrationsKinesisFirehoseOutputReference;
    putKinesisFirehose(value: CloudAwsIntegrationsKinesisFirehose): void;
    resetKinesisFirehose(): void;
    get kinesisFirehoseInput(): CloudAwsIntegrationsKinesisFirehose | undefined;
    private _lambda;
    get lambda(): CloudAwsIntegrationsLambdaOutputReference;
    putLambda(value: CloudAwsIntegrationsLambda): void;
    resetLambda(): void;
    get lambdaInput(): CloudAwsIntegrationsLambda | undefined;
    private _rds;
    get rds(): CloudAwsIntegrationsRdsOutputReference;
    putRds(value: CloudAwsIntegrationsRds): void;
    resetRds(): void;
    get rdsInput(): CloudAwsIntegrationsRds | undefined;
    private _redshift;
    get redshift(): CloudAwsIntegrationsRedshiftOutputReference;
    putRedshift(value: CloudAwsIntegrationsRedshift): void;
    resetRedshift(): void;
    get redshiftInput(): CloudAwsIntegrationsRedshift | undefined;
    private _route53;
    get route53(): CloudAwsIntegrationsRoute53OutputReference;
    putRoute53(value: CloudAwsIntegrationsRoute53): void;
    resetRoute53(): void;
    get route53Input(): CloudAwsIntegrationsRoute53 | undefined;
    private _s3;
    get s3(): CloudAwsIntegrationsS3OutputReference;
    putS3(value: CloudAwsIntegrationsS3): void;
    resetS3(): void;
    get s3Input(): CloudAwsIntegrationsS3 | undefined;
    private _securityHub;
    get securityHub(): CloudAwsIntegrationsSecurityHubOutputReference;
    putSecurityHub(value: CloudAwsIntegrationsSecurityHub): void;
    resetSecurityHub(): void;
    get securityHubInput(): CloudAwsIntegrationsSecurityHub | undefined;
    private _ses;
    get ses(): CloudAwsIntegrationsSesOutputReference;
    putSes(value: CloudAwsIntegrationsSes): void;
    resetSes(): void;
    get sesInput(): CloudAwsIntegrationsSes | undefined;
    private _sns;
    get sns(): CloudAwsIntegrationsSnsOutputReference;
    putSns(value: CloudAwsIntegrationsSns): void;
    resetSns(): void;
    get snsInput(): CloudAwsIntegrationsSns | undefined;
    private _sqs;
    get sqs(): CloudAwsIntegrationsSqsOutputReference;
    putSqs(value: CloudAwsIntegrationsSqs): void;
    resetSqs(): void;
    get sqsInput(): CloudAwsIntegrationsSqs | undefined;
    private _trustedAdvisor;
    get trustedAdvisor(): CloudAwsIntegrationsTrustedAdvisorOutputReference;
    putTrustedAdvisor(value: CloudAwsIntegrationsTrustedAdvisor): void;
    resetTrustedAdvisor(): void;
    get trustedAdvisorInput(): CloudAwsIntegrationsTrustedAdvisor | undefined;
    private _vpc;
    get vpc(): CloudAwsIntegrationsVpcOutputReference;
    putVpc(value: CloudAwsIntegrationsVpc): void;
    resetVpc(): void;
    get vpcInput(): CloudAwsIntegrationsVpc | undefined;
    private _xRay;
    get xRay(): CloudAwsIntegrationsXRayOutputReference;
    putXRay(value: CloudAwsIntegrationsXRay): void;
    resetXRay(): void;
    get xRayInput(): CloudAwsIntegrationsXRay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
