/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ObfuscationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id associated with the obfuscation rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#account_id ObfuscationRule#account_id}
    */
    readonly accountId?: number;
    /**
    * Description of rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#description ObfuscationRule#description}
    */
    readonly description?: string;
    /**
    * Whether the rule should be applied or not to incoming data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#enabled ObfuscationRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * NRQL for determining whether a given log record should have obfuscation actions applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#filter ObfuscationRule#filter}
    */
    readonly filter: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#id ObfuscationRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#name ObfuscationRule#name}
    */
    readonly name: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#action ObfuscationRule#action}
    */
    readonly action: ObfuscationRuleAction[] | cdktn.IResolvable;
}
export interface ObfuscationRuleAction {
    /**
    * Attribute names for action. An empty list applies the action to all the attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#attribute ObfuscationRule#attribute}
    */
    readonly attribute: string[];
    /**
    * Expression Id for action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#expression_id ObfuscationRule#expression_id}
    */
    readonly expressionId: string;
    /**
    * Obfuscation method to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#method ObfuscationRule#method}
    */
    readonly method: string;
}
export declare function obfuscationRuleActionToTerraform(struct?: ObfuscationRuleAction | cdktn.IResolvable): any;
export declare function obfuscationRuleActionToHclTerraform(struct?: ObfuscationRuleAction | cdktn.IResolvable): any;
export declare class ObfuscationRuleActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObfuscationRuleAction | cdktn.IResolvable | undefined;
    set internalValue(value: ObfuscationRuleAction | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string[];
    set attribute(value: string[]);
    get attributeInput(): string[] | undefined;
    private _expressionId?;
    get expressionId(): string;
    set expressionId(value: string);
    get expressionIdInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    get methodInput(): string | undefined;
}
export declare class ObfuscationRuleActionList extends cdktn.ComplexList {
    internalValue?: ObfuscationRuleAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObfuscationRuleActionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule newrelic_obfuscation_rule}
*/
export declare class ObfuscationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_obfuscation_rule";
    /**
    * Generates CDKTN code for importing a ObfuscationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObfuscationRule to import
    * @param importFromId The id of the existing ObfuscationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObfuscationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.93.2/docs/resources/obfuscation_rule newrelic_obfuscation_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObfuscationRuleConfig
    */
    constructor(scope: Construct, id: string, config: ObfuscationRuleConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _action;
    get action(): ObfuscationRuleActionList;
    putAction(value: ObfuscationRuleAction[] | cdktn.IResolvable): void;
    get actionInput(): cdktn.IResolvable | ObfuscationRuleAction[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
