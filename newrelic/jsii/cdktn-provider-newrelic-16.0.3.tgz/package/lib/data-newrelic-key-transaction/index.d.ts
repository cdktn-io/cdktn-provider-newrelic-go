/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicKeyTransactionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the New Relic account the key transaction would need to belong to. Uses the account_id in the provider{} block by default, if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.4/docs/data-sources/key_transaction#account_id DataNewrelicKeyTransaction#account_id}
    */
    readonly accountId?: number;
    /**
    * GUID of the key transaction in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.4/docs/data-sources/key_transaction#guid DataNewrelicKeyTransaction#guid}
    */
    readonly guid?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.4/docs/data-sources/key_transaction#id DataNewrelicKeyTransaction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the key transaction in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.4/docs/data-sources/key_transaction#name DataNewrelicKeyTransaction#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.4/docs/data-sources/key_transaction newrelic_key_transaction}
*/
export declare class DataNewrelicKeyTransaction extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_key_transaction";
    /**
    * Generates CDKTN code for importing a DataNewrelicKeyTransaction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicKeyTransaction to import
    * @param importFromId The id of the existing DataNewrelicKeyTransaction that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.4/docs/data-sources/key_transaction#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicKeyTransaction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.4/docs/data-sources/key_transaction newrelic_key_transaction} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicKeyTransactionConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicKeyTransactionConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    get domain(): string;
    private _guid?;
    get guid(): string;
    set guid(value: string);
    resetGuid(): void;
    get guidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
