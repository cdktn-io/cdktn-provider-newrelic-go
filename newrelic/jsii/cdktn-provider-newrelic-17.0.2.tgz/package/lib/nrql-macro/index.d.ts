/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NrqlMacroConfig extends cdktn.TerraformMetaArguments {
    /**
    * The NRQL fragment this macro expands to wherever `$name` appears in a query. Changes to this field take effect immediately across every dashboard widget, alert condition, and query that references the macro.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.12/docs/resources/nrql_macro#expression NrqlMacro#expression}
    */
    readonly expression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.12/docs/resources/nrql_macro#id NrqlMacro#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A unique name for the macro within your organization. Once created, the name cannot be changed — it is the identifier used to reference the macro as `$name` in NRQL queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.12/docs/resources/nrql_macro#name NrqlMacro#name}
    */
    readonly name: string;
    /**
    * The number of positional parameters the expression accepts, expressed as bare `$1`, `$2`, ... tokens. Required when the expression contains any positional parameters; defaults to `0` for expressions that do not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.12/docs/resources/nrql_macro#parameter_count NrqlMacro#parameter_count}
    */
    readonly parameterCount?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.12/docs/resources/nrql_macro newrelic_nrql_macro}
*/
export declare class NrqlMacro extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_nrql_macro";
    /**
    * Generates CDKTN code for importing a NrqlMacro resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NrqlMacro to import
    * @param importFromId The id of the existing NrqlMacro that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.12/docs/resources/nrql_macro#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NrqlMacro to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.101.12/docs/resources/nrql_macro newrelic_nrql_macro} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NrqlMacroConfig
    */
    constructor(scope: Construct, id: string, config: NrqlMacroConfig);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    private _parameterCount?;
    get parameterCount(): number;
    set parameterCount(value: number);
    resetParameterCount(): void;
    get parameterCountInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
