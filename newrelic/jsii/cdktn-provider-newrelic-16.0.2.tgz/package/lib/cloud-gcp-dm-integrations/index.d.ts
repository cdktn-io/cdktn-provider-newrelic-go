/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudGcpDmIntegrationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#account_id CloudGcpDmIntegrations#account_id}
    */
    readonly accountId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#id CloudGcpDmIntegrations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the GCP Dimensional Metrics linked account (from newrelic_cloud_gcp_link_account with use_workload_identity_federation = true).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#linked_account_id CloudGcpDmIntegrations#linked_account_id}
    */
    readonly linkedAccountId: number;
    /**
    * ai_platform block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#ai_platform CloudGcpDmIntegrations#ai_platform}
    */
    readonly aiPlatform?: CloudGcpDmIntegrationsAiPlatform;
    /**
    * alloy_db block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#alloy_db CloudGcpDmIntegrations#alloy_db}
    */
    readonly alloyDb?: CloudGcpDmIntegrationsAlloyDb;
    /**
    * api_gateway block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#api_gateway CloudGcpDmIntegrations#api_gateway}
    */
    readonly apiGateway?: CloudGcpDmIntegrationsApiGateway;
    /**
    * app_engine block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#app_engine CloudGcpDmIntegrations#app_engine}
    */
    readonly appEngine?: CloudGcpDmIntegrationsAppEngine;
    /**
    * big_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#big_query CloudGcpDmIntegrations#big_query}
    */
    readonly bigQuery?: CloudGcpDmIntegrationsBigQuery;
    /**
    * big_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#big_table CloudGcpDmIntegrations#big_table}
    */
    readonly bigTable?: CloudGcpDmIntegrationsBigTable;
    /**
    * composer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#composer CloudGcpDmIntegrations#composer}
    */
    readonly composer?: CloudGcpDmIntegrationsComposer;
    /**
    * data_flow block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#data_flow CloudGcpDmIntegrations#data_flow}
    */
    readonly dataFlow?: CloudGcpDmIntegrationsDataFlow;
    /**
    * data_proc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#data_proc CloudGcpDmIntegrations#data_proc}
    */
    readonly dataProc?: CloudGcpDmIntegrationsDataProc;
    /**
    * data_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#data_store CloudGcpDmIntegrations#data_store}
    */
    readonly dataStore?: CloudGcpDmIntegrationsDataStore;
    /**
    * firebase_app_hosting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#firebase_app_hosting CloudGcpDmIntegrations#firebase_app_hosting}
    */
    readonly firebaseAppHosting?: CloudGcpDmIntegrationsFirebaseAppHosting;
    /**
    * firebase_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#firebase_auth CloudGcpDmIntegrations#firebase_auth}
    */
    readonly firebaseAuth?: CloudGcpDmIntegrationsFirebaseAuth;
    /**
    * firebase_database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#firebase_database CloudGcpDmIntegrations#firebase_database}
    */
    readonly firebaseDatabase?: CloudGcpDmIntegrationsFirebaseDatabase;
    /**
    * firebase_hosting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#firebase_hosting CloudGcpDmIntegrations#firebase_hosting}
    */
    readonly firebaseHosting?: CloudGcpDmIntegrationsFirebaseHosting;
    /**
    * firebase_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#firebase_storage CloudGcpDmIntegrations#firebase_storage}
    */
    readonly firebaseStorage?: CloudGcpDmIntegrationsFirebaseStorage;
    /**
    * firebase_vertex_ai block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#firebase_vertex_ai CloudGcpDmIntegrations#firebase_vertex_ai}
    */
    readonly firebaseVertexAi?: CloudGcpDmIntegrationsFirebaseVertexAi;
    /**
    * firestore block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#firestore CloudGcpDmIntegrations#firestore}
    */
    readonly firestore?: CloudGcpDmIntegrationsFirestore;
    /**
    * functions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#functions CloudGcpDmIntegrations#functions}
    */
    readonly functions?: CloudGcpDmIntegrationsFunctions;
    /**
    * interconnect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#interconnect CloudGcpDmIntegrations#interconnect}
    */
    readonly interconnect?: CloudGcpDmIntegrationsInterconnect;
    /**
    * istio block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#istio CloudGcpDmIntegrations#istio}
    */
    readonly istio?: CloudGcpDmIntegrationsIstio;
    /**
    * kubernetes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#kubernetes CloudGcpDmIntegrations#kubernetes}
    */
    readonly kubernetes?: CloudGcpDmIntegrationsKubernetes;
    /**
    * load_balancing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#load_balancing CloudGcpDmIntegrations#load_balancing}
    */
    readonly loadBalancing?: CloudGcpDmIntegrationsLoadBalancing;
    /**
    * managed_kafka block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#managed_kafka CloudGcpDmIntegrations#managed_kafka}
    */
    readonly managedKafka?: CloudGcpDmIntegrationsManagedKafka;
    /**
    * mem_cache block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#mem_cache CloudGcpDmIntegrations#mem_cache}
    */
    readonly memCache?: CloudGcpDmIntegrationsMemCache;
    /**
    * memory_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#memory_store CloudGcpDmIntegrations#memory_store}
    */
    readonly memoryStore?: CloudGcpDmIntegrationsMemoryStore;
    /**
    * pub_sub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#pub_sub CloudGcpDmIntegrations#pub_sub}
    */
    readonly pubSub?: CloudGcpDmIntegrationsPubSub;
    /**
    * redis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#redis CloudGcpDmIntegrations#redis}
    */
    readonly redis?: CloudGcpDmIntegrationsRedis;
    /**
    * router block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#router CloudGcpDmIntegrations#router}
    */
    readonly router?: CloudGcpDmIntegrationsRouter;
    /**
    * run block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#run CloudGcpDmIntegrations#run}
    */
    readonly run?: CloudGcpDmIntegrationsRun;
    /**
    * spanner block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#spanner CloudGcpDmIntegrations#spanner}
    */
    readonly spanner?: CloudGcpDmIntegrationsSpanner;
    /**
    * sql block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#sql CloudGcpDmIntegrations#sql}
    */
    readonly sql?: CloudGcpDmIntegrationsSql;
    /**
    * storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#storage CloudGcpDmIntegrations#storage}
    */
    readonly storage?: CloudGcpDmIntegrationsStorage;
    /**
    * virtual_machines block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#virtual_machines CloudGcpDmIntegrations#virtual_machines}
    */
    readonly virtualMachines?: CloudGcpDmIntegrationsVirtualMachines;
    /**
    * vpc_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#vpc_access CloudGcpDmIntegrations#vpc_access}
    */
    readonly vpcAccess?: CloudGcpDmIntegrationsVpcAccess;
}
export interface CloudGcpDmIntegrationsAiPlatform {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsAiPlatformToTerraform(struct?: CloudGcpDmIntegrationsAiPlatformOutputReference | CloudGcpDmIntegrationsAiPlatform): any;
export declare function cloudGcpDmIntegrationsAiPlatformToHclTerraform(struct?: CloudGcpDmIntegrationsAiPlatformOutputReference | CloudGcpDmIntegrationsAiPlatform): any;
export declare class CloudGcpDmIntegrationsAiPlatformOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsAiPlatform | undefined;
    set internalValue(value: CloudGcpDmIntegrationsAiPlatform | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsAlloyDb {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsAlloyDbToTerraform(struct?: CloudGcpDmIntegrationsAlloyDbOutputReference | CloudGcpDmIntegrationsAlloyDb): any;
export declare function cloudGcpDmIntegrationsAlloyDbToHclTerraform(struct?: CloudGcpDmIntegrationsAlloyDbOutputReference | CloudGcpDmIntegrationsAlloyDb): any;
export declare class CloudGcpDmIntegrationsAlloyDbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsAlloyDb | undefined;
    set internalValue(value: CloudGcpDmIntegrationsAlloyDb | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsApiGateway {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsApiGatewayToTerraform(struct?: CloudGcpDmIntegrationsApiGatewayOutputReference | CloudGcpDmIntegrationsApiGateway): any;
export declare function cloudGcpDmIntegrationsApiGatewayToHclTerraform(struct?: CloudGcpDmIntegrationsApiGatewayOutputReference | CloudGcpDmIntegrationsApiGateway): any;
export declare class CloudGcpDmIntegrationsApiGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsApiGateway | undefined;
    set internalValue(value: CloudGcpDmIntegrationsApiGateway | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsAppEngine {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsAppEngineToTerraform(struct?: CloudGcpDmIntegrationsAppEngineOutputReference | CloudGcpDmIntegrationsAppEngine): any;
export declare function cloudGcpDmIntegrationsAppEngineToHclTerraform(struct?: CloudGcpDmIntegrationsAppEngineOutputReference | CloudGcpDmIntegrationsAppEngine): any;
export declare class CloudGcpDmIntegrationsAppEngineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsAppEngine | undefined;
    set internalValue(value: CloudGcpDmIntegrationsAppEngine | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsBigQuery {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsBigQueryToTerraform(struct?: CloudGcpDmIntegrationsBigQueryOutputReference | CloudGcpDmIntegrationsBigQuery): any;
export declare function cloudGcpDmIntegrationsBigQueryToHclTerraform(struct?: CloudGcpDmIntegrationsBigQueryOutputReference | CloudGcpDmIntegrationsBigQuery): any;
export declare class CloudGcpDmIntegrationsBigQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsBigQuery | undefined;
    set internalValue(value: CloudGcpDmIntegrationsBigQuery | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsBigTable {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsBigTableToTerraform(struct?: CloudGcpDmIntegrationsBigTableOutputReference | CloudGcpDmIntegrationsBigTable): any;
export declare function cloudGcpDmIntegrationsBigTableToHclTerraform(struct?: CloudGcpDmIntegrationsBigTableOutputReference | CloudGcpDmIntegrationsBigTable): any;
export declare class CloudGcpDmIntegrationsBigTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsBigTable | undefined;
    set internalValue(value: CloudGcpDmIntegrationsBigTable | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsComposer {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsComposerToTerraform(struct?: CloudGcpDmIntegrationsComposerOutputReference | CloudGcpDmIntegrationsComposer): any;
export declare function cloudGcpDmIntegrationsComposerToHclTerraform(struct?: CloudGcpDmIntegrationsComposerOutputReference | CloudGcpDmIntegrationsComposer): any;
export declare class CloudGcpDmIntegrationsComposerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsComposer | undefined;
    set internalValue(value: CloudGcpDmIntegrationsComposer | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsDataFlow {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsDataFlowToTerraform(struct?: CloudGcpDmIntegrationsDataFlowOutputReference | CloudGcpDmIntegrationsDataFlow): any;
export declare function cloudGcpDmIntegrationsDataFlowToHclTerraform(struct?: CloudGcpDmIntegrationsDataFlowOutputReference | CloudGcpDmIntegrationsDataFlow): any;
export declare class CloudGcpDmIntegrationsDataFlowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsDataFlow | undefined;
    set internalValue(value: CloudGcpDmIntegrationsDataFlow | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsDataProc {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsDataProcToTerraform(struct?: CloudGcpDmIntegrationsDataProcOutputReference | CloudGcpDmIntegrationsDataProc): any;
export declare function cloudGcpDmIntegrationsDataProcToHclTerraform(struct?: CloudGcpDmIntegrationsDataProcOutputReference | CloudGcpDmIntegrationsDataProc): any;
export declare class CloudGcpDmIntegrationsDataProcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsDataProc | undefined;
    set internalValue(value: CloudGcpDmIntegrationsDataProc | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsDataStore {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsDataStoreToTerraform(struct?: CloudGcpDmIntegrationsDataStoreOutputReference | CloudGcpDmIntegrationsDataStore): any;
export declare function cloudGcpDmIntegrationsDataStoreToHclTerraform(struct?: CloudGcpDmIntegrationsDataStoreOutputReference | CloudGcpDmIntegrationsDataStore): any;
export declare class CloudGcpDmIntegrationsDataStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsDataStore | undefined;
    set internalValue(value: CloudGcpDmIntegrationsDataStore | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsFirebaseAppHosting {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsFirebaseAppHostingToTerraform(struct?: CloudGcpDmIntegrationsFirebaseAppHostingOutputReference | CloudGcpDmIntegrationsFirebaseAppHosting): any;
export declare function cloudGcpDmIntegrationsFirebaseAppHostingToHclTerraform(struct?: CloudGcpDmIntegrationsFirebaseAppHostingOutputReference | CloudGcpDmIntegrationsFirebaseAppHosting): any;
export declare class CloudGcpDmIntegrationsFirebaseAppHostingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsFirebaseAppHosting | undefined;
    set internalValue(value: CloudGcpDmIntegrationsFirebaseAppHosting | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsFirebaseAuth {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsFirebaseAuthToTerraform(struct?: CloudGcpDmIntegrationsFirebaseAuthOutputReference | CloudGcpDmIntegrationsFirebaseAuth): any;
export declare function cloudGcpDmIntegrationsFirebaseAuthToHclTerraform(struct?: CloudGcpDmIntegrationsFirebaseAuthOutputReference | CloudGcpDmIntegrationsFirebaseAuth): any;
export declare class CloudGcpDmIntegrationsFirebaseAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsFirebaseAuth | undefined;
    set internalValue(value: CloudGcpDmIntegrationsFirebaseAuth | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsFirebaseDatabase {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsFirebaseDatabaseToTerraform(struct?: CloudGcpDmIntegrationsFirebaseDatabaseOutputReference | CloudGcpDmIntegrationsFirebaseDatabase): any;
export declare function cloudGcpDmIntegrationsFirebaseDatabaseToHclTerraform(struct?: CloudGcpDmIntegrationsFirebaseDatabaseOutputReference | CloudGcpDmIntegrationsFirebaseDatabase): any;
export declare class CloudGcpDmIntegrationsFirebaseDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsFirebaseDatabase | undefined;
    set internalValue(value: CloudGcpDmIntegrationsFirebaseDatabase | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsFirebaseHosting {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsFirebaseHostingToTerraform(struct?: CloudGcpDmIntegrationsFirebaseHostingOutputReference | CloudGcpDmIntegrationsFirebaseHosting): any;
export declare function cloudGcpDmIntegrationsFirebaseHostingToHclTerraform(struct?: CloudGcpDmIntegrationsFirebaseHostingOutputReference | CloudGcpDmIntegrationsFirebaseHosting): any;
export declare class CloudGcpDmIntegrationsFirebaseHostingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsFirebaseHosting | undefined;
    set internalValue(value: CloudGcpDmIntegrationsFirebaseHosting | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsFirebaseStorage {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsFirebaseStorageToTerraform(struct?: CloudGcpDmIntegrationsFirebaseStorageOutputReference | CloudGcpDmIntegrationsFirebaseStorage): any;
export declare function cloudGcpDmIntegrationsFirebaseStorageToHclTerraform(struct?: CloudGcpDmIntegrationsFirebaseStorageOutputReference | CloudGcpDmIntegrationsFirebaseStorage): any;
export declare class CloudGcpDmIntegrationsFirebaseStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsFirebaseStorage | undefined;
    set internalValue(value: CloudGcpDmIntegrationsFirebaseStorage | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsFirebaseVertexAi {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsFirebaseVertexAiToTerraform(struct?: CloudGcpDmIntegrationsFirebaseVertexAiOutputReference | CloudGcpDmIntegrationsFirebaseVertexAi): any;
export declare function cloudGcpDmIntegrationsFirebaseVertexAiToHclTerraform(struct?: CloudGcpDmIntegrationsFirebaseVertexAiOutputReference | CloudGcpDmIntegrationsFirebaseVertexAi): any;
export declare class CloudGcpDmIntegrationsFirebaseVertexAiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsFirebaseVertexAi | undefined;
    set internalValue(value: CloudGcpDmIntegrationsFirebaseVertexAi | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsFirestore {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsFirestoreToTerraform(struct?: CloudGcpDmIntegrationsFirestoreOutputReference | CloudGcpDmIntegrationsFirestore): any;
export declare function cloudGcpDmIntegrationsFirestoreToHclTerraform(struct?: CloudGcpDmIntegrationsFirestoreOutputReference | CloudGcpDmIntegrationsFirestore): any;
export declare class CloudGcpDmIntegrationsFirestoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsFirestore | undefined;
    set internalValue(value: CloudGcpDmIntegrationsFirestore | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsFunctions {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsFunctionsToTerraform(struct?: CloudGcpDmIntegrationsFunctionsOutputReference | CloudGcpDmIntegrationsFunctions): any;
export declare function cloudGcpDmIntegrationsFunctionsToHclTerraform(struct?: CloudGcpDmIntegrationsFunctionsOutputReference | CloudGcpDmIntegrationsFunctions): any;
export declare class CloudGcpDmIntegrationsFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsFunctions | undefined;
    set internalValue(value: CloudGcpDmIntegrationsFunctions | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsInterconnect {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsInterconnectToTerraform(struct?: CloudGcpDmIntegrationsInterconnectOutputReference | CloudGcpDmIntegrationsInterconnect): any;
export declare function cloudGcpDmIntegrationsInterconnectToHclTerraform(struct?: CloudGcpDmIntegrationsInterconnectOutputReference | CloudGcpDmIntegrationsInterconnect): any;
export declare class CloudGcpDmIntegrationsInterconnectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsInterconnect | undefined;
    set internalValue(value: CloudGcpDmIntegrationsInterconnect | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsIstio {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsIstioToTerraform(struct?: CloudGcpDmIntegrationsIstioOutputReference | CloudGcpDmIntegrationsIstio): any;
export declare function cloudGcpDmIntegrationsIstioToHclTerraform(struct?: CloudGcpDmIntegrationsIstioOutputReference | CloudGcpDmIntegrationsIstio): any;
export declare class CloudGcpDmIntegrationsIstioOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsIstio | undefined;
    set internalValue(value: CloudGcpDmIntegrationsIstio | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsKubernetes {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsKubernetesToTerraform(struct?: CloudGcpDmIntegrationsKubernetesOutputReference | CloudGcpDmIntegrationsKubernetes): any;
export declare function cloudGcpDmIntegrationsKubernetesToHclTerraform(struct?: CloudGcpDmIntegrationsKubernetesOutputReference | CloudGcpDmIntegrationsKubernetes): any;
export declare class CloudGcpDmIntegrationsKubernetesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsKubernetes | undefined;
    set internalValue(value: CloudGcpDmIntegrationsKubernetes | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsLoadBalancing {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsLoadBalancingToTerraform(struct?: CloudGcpDmIntegrationsLoadBalancingOutputReference | CloudGcpDmIntegrationsLoadBalancing): any;
export declare function cloudGcpDmIntegrationsLoadBalancingToHclTerraform(struct?: CloudGcpDmIntegrationsLoadBalancingOutputReference | CloudGcpDmIntegrationsLoadBalancing): any;
export declare class CloudGcpDmIntegrationsLoadBalancingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsLoadBalancing | undefined;
    set internalValue(value: CloudGcpDmIntegrationsLoadBalancing | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsManagedKafka {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsManagedKafkaToTerraform(struct?: CloudGcpDmIntegrationsManagedKafkaOutputReference | CloudGcpDmIntegrationsManagedKafka): any;
export declare function cloudGcpDmIntegrationsManagedKafkaToHclTerraform(struct?: CloudGcpDmIntegrationsManagedKafkaOutputReference | CloudGcpDmIntegrationsManagedKafka): any;
export declare class CloudGcpDmIntegrationsManagedKafkaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsManagedKafka | undefined;
    set internalValue(value: CloudGcpDmIntegrationsManagedKafka | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsMemCache {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsMemCacheToTerraform(struct?: CloudGcpDmIntegrationsMemCacheOutputReference | CloudGcpDmIntegrationsMemCache): any;
export declare function cloudGcpDmIntegrationsMemCacheToHclTerraform(struct?: CloudGcpDmIntegrationsMemCacheOutputReference | CloudGcpDmIntegrationsMemCache): any;
export declare class CloudGcpDmIntegrationsMemCacheOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsMemCache | undefined;
    set internalValue(value: CloudGcpDmIntegrationsMemCache | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsMemoryStore {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsMemoryStoreToTerraform(struct?: CloudGcpDmIntegrationsMemoryStoreOutputReference | CloudGcpDmIntegrationsMemoryStore): any;
export declare function cloudGcpDmIntegrationsMemoryStoreToHclTerraform(struct?: CloudGcpDmIntegrationsMemoryStoreOutputReference | CloudGcpDmIntegrationsMemoryStore): any;
export declare class CloudGcpDmIntegrationsMemoryStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsMemoryStore | undefined;
    set internalValue(value: CloudGcpDmIntegrationsMemoryStore | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsPubSub {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsPubSubToTerraform(struct?: CloudGcpDmIntegrationsPubSubOutputReference | CloudGcpDmIntegrationsPubSub): any;
export declare function cloudGcpDmIntegrationsPubSubToHclTerraform(struct?: CloudGcpDmIntegrationsPubSubOutputReference | CloudGcpDmIntegrationsPubSub): any;
export declare class CloudGcpDmIntegrationsPubSubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsPubSub | undefined;
    set internalValue(value: CloudGcpDmIntegrationsPubSub | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsRedis {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsRedisToTerraform(struct?: CloudGcpDmIntegrationsRedisOutputReference | CloudGcpDmIntegrationsRedis): any;
export declare function cloudGcpDmIntegrationsRedisToHclTerraform(struct?: CloudGcpDmIntegrationsRedisOutputReference | CloudGcpDmIntegrationsRedis): any;
export declare class CloudGcpDmIntegrationsRedisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsRedis | undefined;
    set internalValue(value: CloudGcpDmIntegrationsRedis | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsRouter {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsRouterToTerraform(struct?: CloudGcpDmIntegrationsRouterOutputReference | CloudGcpDmIntegrationsRouter): any;
export declare function cloudGcpDmIntegrationsRouterToHclTerraform(struct?: CloudGcpDmIntegrationsRouterOutputReference | CloudGcpDmIntegrationsRouter): any;
export declare class CloudGcpDmIntegrationsRouterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsRouter | undefined;
    set internalValue(value: CloudGcpDmIntegrationsRouter | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsRun {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsRunToTerraform(struct?: CloudGcpDmIntegrationsRunOutputReference | CloudGcpDmIntegrationsRun): any;
export declare function cloudGcpDmIntegrationsRunToHclTerraform(struct?: CloudGcpDmIntegrationsRunOutputReference | CloudGcpDmIntegrationsRun): any;
export declare class CloudGcpDmIntegrationsRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsRun | undefined;
    set internalValue(value: CloudGcpDmIntegrationsRun | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsSpanner {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsSpannerToTerraform(struct?: CloudGcpDmIntegrationsSpannerOutputReference | CloudGcpDmIntegrationsSpanner): any;
export declare function cloudGcpDmIntegrationsSpannerToHclTerraform(struct?: CloudGcpDmIntegrationsSpannerOutputReference | CloudGcpDmIntegrationsSpanner): any;
export declare class CloudGcpDmIntegrationsSpannerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsSpanner | undefined;
    set internalValue(value: CloudGcpDmIntegrationsSpanner | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsSql {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsSqlToTerraform(struct?: CloudGcpDmIntegrationsSqlOutputReference | CloudGcpDmIntegrationsSql): any;
export declare function cloudGcpDmIntegrationsSqlToHclTerraform(struct?: CloudGcpDmIntegrationsSqlOutputReference | CloudGcpDmIntegrationsSql): any;
export declare class CloudGcpDmIntegrationsSqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsSql | undefined;
    set internalValue(value: CloudGcpDmIntegrationsSql | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsStorage {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsStorageToTerraform(struct?: CloudGcpDmIntegrationsStorageOutputReference | CloudGcpDmIntegrationsStorage): any;
export declare function cloudGcpDmIntegrationsStorageToHclTerraform(struct?: CloudGcpDmIntegrationsStorageOutputReference | CloudGcpDmIntegrationsStorage): any;
export declare class CloudGcpDmIntegrationsStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsStorage | undefined;
    set internalValue(value: CloudGcpDmIntegrationsStorage | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsVirtualMachines {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsVirtualMachinesToTerraform(struct?: CloudGcpDmIntegrationsVirtualMachinesOutputReference | CloudGcpDmIntegrationsVirtualMachines): any;
export declare function cloudGcpDmIntegrationsVirtualMachinesToHclTerraform(struct?: CloudGcpDmIntegrationsVirtualMachinesOutputReference | CloudGcpDmIntegrationsVirtualMachines): any;
export declare class CloudGcpDmIntegrationsVirtualMachinesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsVirtualMachines | undefined;
    set internalValue(value: CloudGcpDmIntegrationsVirtualMachines | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
export interface CloudGcpDmIntegrationsVpcAccess {
    /**
    * The data polling interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#metrics_polling_interval CloudGcpDmIntegrations#metrics_polling_interval}
    */
    readonly metricsPollingInterval?: number;
}
export declare function cloudGcpDmIntegrationsVpcAccessToTerraform(struct?: CloudGcpDmIntegrationsVpcAccessOutputReference | CloudGcpDmIntegrationsVpcAccess): any;
export declare function cloudGcpDmIntegrationsVpcAccessToHclTerraform(struct?: CloudGcpDmIntegrationsVpcAccessOutputReference | CloudGcpDmIntegrationsVpcAccess): any;
export declare class CloudGcpDmIntegrationsVpcAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudGcpDmIntegrationsVpcAccess | undefined;
    set internalValue(value: CloudGcpDmIntegrationsVpcAccess | undefined);
    private _metricsPollingInterval?;
    get metricsPollingInterval(): number;
    set metricsPollingInterval(value: number);
    resetMetricsPollingInterval(): void;
    get metricsPollingIntervalInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations newrelic_cloud_gcp_dm_integrations}
*/
export declare class CloudGcpDmIntegrations extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_cloud_gcp_dm_integrations";
    /**
    * Generates CDKTN code for importing a CloudGcpDmIntegrations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudGcpDmIntegrations to import
    * @param importFromId The id of the existing CloudGcpDmIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudGcpDmIntegrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.3/docs/resources/cloud_gcp_dm_integrations newrelic_cloud_gcp_dm_integrations} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudGcpDmIntegrationsConfig
    */
    constructor(scope: Construct, id: string, config: CloudGcpDmIntegrationsConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _linkedAccountId?;
    get linkedAccountId(): number;
    set linkedAccountId(value: number);
    get linkedAccountIdInput(): number | undefined;
    private _aiPlatform;
    get aiPlatform(): CloudGcpDmIntegrationsAiPlatformOutputReference;
    putAiPlatform(value: CloudGcpDmIntegrationsAiPlatform): void;
    resetAiPlatform(): void;
    get aiPlatformInput(): CloudGcpDmIntegrationsAiPlatform | undefined;
    private _alloyDb;
    get alloyDb(): CloudGcpDmIntegrationsAlloyDbOutputReference;
    putAlloyDb(value: CloudGcpDmIntegrationsAlloyDb): void;
    resetAlloyDb(): void;
    get alloyDbInput(): CloudGcpDmIntegrationsAlloyDb | undefined;
    private _apiGateway;
    get apiGateway(): CloudGcpDmIntegrationsApiGatewayOutputReference;
    putApiGateway(value: CloudGcpDmIntegrationsApiGateway): void;
    resetApiGateway(): void;
    get apiGatewayInput(): CloudGcpDmIntegrationsApiGateway | undefined;
    private _appEngine;
    get appEngine(): CloudGcpDmIntegrationsAppEngineOutputReference;
    putAppEngine(value: CloudGcpDmIntegrationsAppEngine): void;
    resetAppEngine(): void;
    get appEngineInput(): CloudGcpDmIntegrationsAppEngine | undefined;
    private _bigQuery;
    get bigQuery(): CloudGcpDmIntegrationsBigQueryOutputReference;
    putBigQuery(value: CloudGcpDmIntegrationsBigQuery): void;
    resetBigQuery(): void;
    get bigQueryInput(): CloudGcpDmIntegrationsBigQuery | undefined;
    private _bigTable;
    get bigTable(): CloudGcpDmIntegrationsBigTableOutputReference;
    putBigTable(value: CloudGcpDmIntegrationsBigTable): void;
    resetBigTable(): void;
    get bigTableInput(): CloudGcpDmIntegrationsBigTable | undefined;
    private _composer;
    get composer(): CloudGcpDmIntegrationsComposerOutputReference;
    putComposer(value: CloudGcpDmIntegrationsComposer): void;
    resetComposer(): void;
    get composerInput(): CloudGcpDmIntegrationsComposer | undefined;
    private _dataFlow;
    get dataFlow(): CloudGcpDmIntegrationsDataFlowOutputReference;
    putDataFlow(value: CloudGcpDmIntegrationsDataFlow): void;
    resetDataFlow(): void;
    get dataFlowInput(): CloudGcpDmIntegrationsDataFlow | undefined;
    private _dataProc;
    get dataProc(): CloudGcpDmIntegrationsDataProcOutputReference;
    putDataProc(value: CloudGcpDmIntegrationsDataProc): void;
    resetDataProc(): void;
    get dataProcInput(): CloudGcpDmIntegrationsDataProc | undefined;
    private _dataStore;
    get dataStore(): CloudGcpDmIntegrationsDataStoreOutputReference;
    putDataStore(value: CloudGcpDmIntegrationsDataStore): void;
    resetDataStore(): void;
    get dataStoreInput(): CloudGcpDmIntegrationsDataStore | undefined;
    private _firebaseAppHosting;
    get firebaseAppHosting(): CloudGcpDmIntegrationsFirebaseAppHostingOutputReference;
    putFirebaseAppHosting(value: CloudGcpDmIntegrationsFirebaseAppHosting): void;
    resetFirebaseAppHosting(): void;
    get firebaseAppHostingInput(): CloudGcpDmIntegrationsFirebaseAppHosting | undefined;
    private _firebaseAuth;
    get firebaseAuth(): CloudGcpDmIntegrationsFirebaseAuthOutputReference;
    putFirebaseAuth(value: CloudGcpDmIntegrationsFirebaseAuth): void;
    resetFirebaseAuth(): void;
    get firebaseAuthInput(): CloudGcpDmIntegrationsFirebaseAuth | undefined;
    private _firebaseDatabase;
    get firebaseDatabase(): CloudGcpDmIntegrationsFirebaseDatabaseOutputReference;
    putFirebaseDatabase(value: CloudGcpDmIntegrationsFirebaseDatabase): void;
    resetFirebaseDatabase(): void;
    get firebaseDatabaseInput(): CloudGcpDmIntegrationsFirebaseDatabase | undefined;
    private _firebaseHosting;
    get firebaseHosting(): CloudGcpDmIntegrationsFirebaseHostingOutputReference;
    putFirebaseHosting(value: CloudGcpDmIntegrationsFirebaseHosting): void;
    resetFirebaseHosting(): void;
    get firebaseHostingInput(): CloudGcpDmIntegrationsFirebaseHosting | undefined;
    private _firebaseStorage;
    get firebaseStorage(): CloudGcpDmIntegrationsFirebaseStorageOutputReference;
    putFirebaseStorage(value: CloudGcpDmIntegrationsFirebaseStorage): void;
    resetFirebaseStorage(): void;
    get firebaseStorageInput(): CloudGcpDmIntegrationsFirebaseStorage | undefined;
    private _firebaseVertexAi;
    get firebaseVertexAi(): CloudGcpDmIntegrationsFirebaseVertexAiOutputReference;
    putFirebaseVertexAi(value: CloudGcpDmIntegrationsFirebaseVertexAi): void;
    resetFirebaseVertexAi(): void;
    get firebaseVertexAiInput(): CloudGcpDmIntegrationsFirebaseVertexAi | undefined;
    private _firestore;
    get firestore(): CloudGcpDmIntegrationsFirestoreOutputReference;
    putFirestore(value: CloudGcpDmIntegrationsFirestore): void;
    resetFirestore(): void;
    get firestoreInput(): CloudGcpDmIntegrationsFirestore | undefined;
    private _functions;
    get functions(): CloudGcpDmIntegrationsFunctionsOutputReference;
    putFunctions(value: CloudGcpDmIntegrationsFunctions): void;
    resetFunctions(): void;
    get functionsInput(): CloudGcpDmIntegrationsFunctions | undefined;
    private _interconnect;
    get interconnect(): CloudGcpDmIntegrationsInterconnectOutputReference;
    putInterconnect(value: CloudGcpDmIntegrationsInterconnect): void;
    resetInterconnect(): void;
    get interconnectInput(): CloudGcpDmIntegrationsInterconnect | undefined;
    private _istio;
    get istio(): CloudGcpDmIntegrationsIstioOutputReference;
    putIstio(value: CloudGcpDmIntegrationsIstio): void;
    resetIstio(): void;
    get istioInput(): CloudGcpDmIntegrationsIstio | undefined;
    private _kubernetes;
    get kubernetes(): CloudGcpDmIntegrationsKubernetesOutputReference;
    putKubernetes(value: CloudGcpDmIntegrationsKubernetes): void;
    resetKubernetes(): void;
    get kubernetesInput(): CloudGcpDmIntegrationsKubernetes | undefined;
    private _loadBalancing;
    get loadBalancing(): CloudGcpDmIntegrationsLoadBalancingOutputReference;
    putLoadBalancing(value: CloudGcpDmIntegrationsLoadBalancing): void;
    resetLoadBalancing(): void;
    get loadBalancingInput(): CloudGcpDmIntegrationsLoadBalancing | undefined;
    private _managedKafka;
    get managedKafka(): CloudGcpDmIntegrationsManagedKafkaOutputReference;
    putManagedKafka(value: CloudGcpDmIntegrationsManagedKafka): void;
    resetManagedKafka(): void;
    get managedKafkaInput(): CloudGcpDmIntegrationsManagedKafka | undefined;
    private _memCache;
    get memCache(): CloudGcpDmIntegrationsMemCacheOutputReference;
    putMemCache(value: CloudGcpDmIntegrationsMemCache): void;
    resetMemCache(): void;
    get memCacheInput(): CloudGcpDmIntegrationsMemCache | undefined;
    private _memoryStore;
    get memoryStore(): CloudGcpDmIntegrationsMemoryStoreOutputReference;
    putMemoryStore(value: CloudGcpDmIntegrationsMemoryStore): void;
    resetMemoryStore(): void;
    get memoryStoreInput(): CloudGcpDmIntegrationsMemoryStore | undefined;
    private _pubSub;
    get pubSub(): CloudGcpDmIntegrationsPubSubOutputReference;
    putPubSub(value: CloudGcpDmIntegrationsPubSub): void;
    resetPubSub(): void;
    get pubSubInput(): CloudGcpDmIntegrationsPubSub | undefined;
    private _redis;
    get redis(): CloudGcpDmIntegrationsRedisOutputReference;
    putRedis(value: CloudGcpDmIntegrationsRedis): void;
    resetRedis(): void;
    get redisInput(): CloudGcpDmIntegrationsRedis | undefined;
    private _router;
    get router(): CloudGcpDmIntegrationsRouterOutputReference;
    putRouter(value: CloudGcpDmIntegrationsRouter): void;
    resetRouter(): void;
    get routerInput(): CloudGcpDmIntegrationsRouter | undefined;
    private _run;
    get run(): CloudGcpDmIntegrationsRunOutputReference;
    putRun(value: CloudGcpDmIntegrationsRun): void;
    resetRun(): void;
    get runInput(): CloudGcpDmIntegrationsRun | undefined;
    private _spanner;
    get spanner(): CloudGcpDmIntegrationsSpannerOutputReference;
    putSpanner(value: CloudGcpDmIntegrationsSpanner): void;
    resetSpanner(): void;
    get spannerInput(): CloudGcpDmIntegrationsSpanner | undefined;
    private _sql;
    get sql(): CloudGcpDmIntegrationsSqlOutputReference;
    putSql(value: CloudGcpDmIntegrationsSql): void;
    resetSql(): void;
    get sqlInput(): CloudGcpDmIntegrationsSql | undefined;
    private _storage;
    get storage(): CloudGcpDmIntegrationsStorageOutputReference;
    putStorage(value: CloudGcpDmIntegrationsStorage): void;
    resetStorage(): void;
    get storageInput(): CloudGcpDmIntegrationsStorage | undefined;
    private _virtualMachines;
    get virtualMachines(): CloudGcpDmIntegrationsVirtualMachinesOutputReference;
    putVirtualMachines(value: CloudGcpDmIntegrationsVirtualMachines): void;
    resetVirtualMachines(): void;
    get virtualMachinesInput(): CloudGcpDmIntegrationsVirtualMachines | undefined;
    private _vpcAccess;
    get vpcAccess(): CloudGcpDmIntegrationsVpcAccessOutputReference;
    putVpcAccess(value: CloudGcpDmIntegrationsVpcAccess): void;
    resetVpcAccess(): void;
    get vpcAccessInput(): CloudGcpDmIntegrationsVpcAccess | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
