/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkflowConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id of the workflow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#account_id Workflow#account_id}
    */
    readonly accountId?: number;
    /**
    * Indicates whether the destinations are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#destinations_enabled Workflow#destinations_enabled}
    */
    readonly destinationsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether the workflow is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#enabled Workflow#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether the enrichments are enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#enrichments_enabled Workflow#enrichments_enabled}
    */
    readonly enrichmentsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#id Workflow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The type of the muting rule handling. One of: (NOTIFY_ALL_ISSUES, DONT_NOTIFY_FULLY_MUTED_ISSUES, DONT_NOTIFY_FULLY_OR_PARTIALLY_MUTED_ISSUES).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#muting_rules_handling Workflow#muting_rules_handling}
    */
    readonly mutingRulesHandling: string;
    /**
    * (Required) The name of the workflow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#name Workflow#name}
    */
    readonly name: string;
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#destination Workflow#destination}
    */
    readonly destination: WorkflowDestination[] | cdktn.IResolvable;
    /**
    * enrichments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#enrichments Workflow#enrichments}
    */
    readonly enrichments?: WorkflowEnrichments;
    /**
    * issues_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#issues_filter Workflow#issues_filter}
    */
    readonly issuesFilter: WorkflowIssuesFilter;
}
export interface WorkflowDestination {
    /**
    * (Required) Destination's channel id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#channel_id Workflow#channel_id}
    */
    readonly channelId: string;
    /**
    * List of triggers to notify about in this destination configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#notification_triggers Workflow#notification_triggers}
    */
    readonly notificationTriggers?: string[];
    /**
    * Update original notification message (Slack channels only)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#update_original_message Workflow#update_original_message}
    */
    readonly updateOriginalMessage?: boolean | cdktn.IResolvable;
}
export declare function workflowDestinationToTerraform(struct?: WorkflowDestination | cdktn.IResolvable): any;
export declare function workflowDestinationToHclTerraform(struct?: WorkflowDestination | cdktn.IResolvable): any;
export declare class WorkflowDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowDestination | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowDestination | cdktn.IResolvable | undefined);
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    get channelIdInput(): string | undefined;
    get name(): string;
    private _notificationTriggers?;
    get notificationTriggers(): string[];
    set notificationTriggers(value: string[]);
    resetNotificationTriggers(): void;
    get notificationTriggersInput(): string[] | undefined;
    get type(): string;
    private _updateOriginalMessage?;
    get updateOriginalMessage(): boolean | cdktn.IResolvable;
    set updateOriginalMessage(value: boolean | cdktn.IResolvable);
    resetUpdateOriginalMessage(): void;
    get updateOriginalMessageInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class WorkflowDestinationList extends cdktn.ComplexList {
    internalValue?: WorkflowDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowDestinationOutputReference;
}
export interface WorkflowEnrichmentsNrqlConfiguration {
    /**
    * enrichment's NRQL query
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#query Workflow#query}
    */
    readonly query: string;
}
export declare function workflowEnrichmentsNrqlConfigurationToTerraform(struct?: WorkflowEnrichmentsNrqlConfiguration | cdktn.IResolvable): any;
export declare function workflowEnrichmentsNrqlConfigurationToHclTerraform(struct?: WorkflowEnrichmentsNrqlConfiguration | cdktn.IResolvable): any;
export declare class WorkflowEnrichmentsNrqlConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowEnrichmentsNrqlConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowEnrichmentsNrqlConfiguration | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class WorkflowEnrichmentsNrqlConfigurationList extends cdktn.ComplexList {
    internalValue?: WorkflowEnrichmentsNrqlConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowEnrichmentsNrqlConfigurationOutputReference;
}
export interface WorkflowEnrichmentsNrql {
    /**
    * (Required) Enrichment's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#name Workflow#name}
    */
    readonly name: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#configuration Workflow#configuration}
    */
    readonly configuration: WorkflowEnrichmentsNrqlConfiguration[] | cdktn.IResolvable;
}
export declare function workflowEnrichmentsNrqlToTerraform(struct?: WorkflowEnrichmentsNrql | cdktn.IResolvable): any;
export declare function workflowEnrichmentsNrqlToHclTerraform(struct?: WorkflowEnrichmentsNrql | cdktn.IResolvable): any;
export declare class WorkflowEnrichmentsNrqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowEnrichmentsNrql | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowEnrichmentsNrql | cdktn.IResolvable | undefined);
    get accountId(): number;
    get enrichmentId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get type(): string;
    private _configuration;
    get configuration(): WorkflowEnrichmentsNrqlConfigurationList;
    putConfiguration(value: WorkflowEnrichmentsNrqlConfiguration[] | cdktn.IResolvable): void;
    get configurationInput(): cdktn.IResolvable | WorkflowEnrichmentsNrqlConfiguration[] | undefined;
}
export declare class WorkflowEnrichmentsNrqlList extends cdktn.ComplexList {
    internalValue?: WorkflowEnrichmentsNrql[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowEnrichmentsNrqlOutputReference;
}
export interface WorkflowEnrichments {
    /**
    * nrql block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#nrql Workflow#nrql}
    */
    readonly nrql: WorkflowEnrichmentsNrql[] | cdktn.IResolvable;
}
export declare function workflowEnrichmentsToTerraform(struct?: WorkflowEnrichmentsOutputReference | WorkflowEnrichments): any;
export declare function workflowEnrichmentsToHclTerraform(struct?: WorkflowEnrichmentsOutputReference | WorkflowEnrichments): any;
export declare class WorkflowEnrichmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowEnrichments | undefined;
    set internalValue(value: WorkflowEnrichments | undefined);
    private _nrql;
    get nrql(): WorkflowEnrichmentsNrqlList;
    putNrql(value: WorkflowEnrichmentsNrql[] | cdktn.IResolvable): void;
    get nrqlInput(): cdktn.IResolvable | WorkflowEnrichmentsNrql[] | undefined;
}
export interface WorkflowIssuesFilterPredicate {
    /**
    * (Required) predicate's attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#attribute Workflow#attribute}
    */
    readonly attribute: string;
    /**
    * The type of the operator. One of: (CONTAINS, DOES_NOT_CONTAIN, DOES_NOT_EQUAL, DOES_NOT_EXACTLY_MATCH, ENDS_WITH, EQUAL, EXACTLY_MATCHES, GREATER_OR_EQUAL, GREATER_THAN, IS, IS_NOT, LESS_OR_EQUAL, LESS_THAN, STARTS_WITH).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#operator Workflow#operator}
    */
    readonly operator: string;
    /**
    * List of predicate values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#values Workflow#values}
    */
    readonly values: string[];
}
export declare function workflowIssuesFilterPredicateToTerraform(struct?: WorkflowIssuesFilterPredicate | cdktn.IResolvable): any;
export declare function workflowIssuesFilterPredicateToHclTerraform(struct?: WorkflowIssuesFilterPredicate | cdktn.IResolvable): any;
export declare class WorkflowIssuesFilterPredicateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WorkflowIssuesFilterPredicate | cdktn.IResolvable | undefined;
    set internalValue(value: WorkflowIssuesFilterPredicate | cdktn.IResolvable | undefined);
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    get attributeInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class WorkflowIssuesFilterPredicateList extends cdktn.ComplexList {
    internalValue?: WorkflowIssuesFilterPredicate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WorkflowIssuesFilterPredicateOutputReference;
}
export interface WorkflowIssuesFilter {
    /**
    * (Required) Filter's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#name Workflow#name}
    */
    readonly name: string;
    /**
    * (Required) The type of the filter. One of: (FILTER, VIEW).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#type Workflow#type}
    */
    readonly type: string;
    /**
    * predicate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#predicate Workflow#predicate}
    */
    readonly predicate?: WorkflowIssuesFilterPredicate[] | cdktn.IResolvable;
}
export declare function workflowIssuesFilterToTerraform(struct?: WorkflowIssuesFilterOutputReference | WorkflowIssuesFilter): any;
export declare function workflowIssuesFilterToHclTerraform(struct?: WorkflowIssuesFilterOutputReference | WorkflowIssuesFilter): any;
export declare class WorkflowIssuesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkflowIssuesFilter | undefined;
    set internalValue(value: WorkflowIssuesFilter | undefined);
    get filterId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _predicate;
    get predicate(): WorkflowIssuesFilterPredicateList;
    putPredicate(value: WorkflowIssuesFilterPredicate[] | cdktn.IResolvable): void;
    resetPredicate(): void;
    get predicateInput(): cdktn.IResolvable | WorkflowIssuesFilterPredicate[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow newrelic_workflow}
*/
export declare class Workflow extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_workflow";
    /**
    * Generates CDKTN code for importing a Workflow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Workflow to import
    * @param importFromId The id of the existing Workflow that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Workflow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/workflow newrelic_workflow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkflowConfig
    */
    constructor(scope: Construct, id: string, config: WorkflowConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _destinationsEnabled?;
    get destinationsEnabled(): boolean | cdktn.IResolvable;
    set destinationsEnabled(value: boolean | cdktn.IResolvable);
    resetDestinationsEnabled(): void;
    get destinationsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enrichmentsEnabled?;
    get enrichmentsEnabled(): boolean | cdktn.IResolvable;
    set enrichmentsEnabled(value: boolean | cdktn.IResolvable);
    resetEnrichmentsEnabled(): void;
    get enrichmentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastRun(): string;
    private _mutingRulesHandling?;
    get mutingRulesHandling(): string;
    set mutingRulesHandling(value: string);
    get mutingRulesHandlingInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get workflowId(): string;
    private _destination;
    get destination(): WorkflowDestinationList;
    putDestination(value: WorkflowDestination[] | cdktn.IResolvable): void;
    get destinationInput(): cdktn.IResolvable | WorkflowDestination[] | undefined;
    private _enrichments;
    get enrichments(): WorkflowEnrichmentsOutputReference;
    putEnrichments(value: WorkflowEnrichments): void;
    resetEnrichments(): void;
    get enrichmentsInput(): WorkflowEnrichments | undefined;
    private _issuesFilter;
    get issuesFilter(): WorkflowIssuesFilterOutputReference;
    putIssuesFilter(value: WorkflowIssuesFilter): void;
    get issuesFilterInput(): WorkflowIssuesFilter | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
