/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the newrelic account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#account_id SyntheticsMonitor#account_id}
    */
    readonly accountId?: number;
    /**
    * The multiple browsers list on which synthetic monitors will run. Valid values are array of CHROME,and FIREFOX
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#browsers SyntheticsMonitor#browsers}
    */
    readonly browsers?: string[];
    /**
    * Bypass HEAD request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#bypass_head_request SyntheticsMonitor#bypass_head_request}
    */
    readonly bypassHeadRequest?: boolean | cdktn.IResolvable;
    /**
    * The device orientation the user would like to represent. Valid values are LANDSCAPE, PORTRAIT, or NONE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#device_orientation SyntheticsMonitor#device_orientation}
    */
    readonly deviceOrientation?: string;
    /**
    * The device type that a user can select. Valid values are MOBILE, TABLET, or NONE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#device_type SyntheticsMonitor#device_type}
    */
    readonly deviceType?: string;
    /**
    * The multiple devices list on which synthetic monitors will run. Valid values are array of DESKTOP, MOBILE_LANDSCAPE, MOBILE_PORTRAIT, TABLET_LANDSCAPE and TABLET_PORTRAIT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#devices SyntheticsMonitor#devices}
    */
    readonly devices?: string[];
    /**
    * Capture a screenshot during job execution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#enable_screenshot_on_failure_and_script SyntheticsMonitor#enable_screenshot_on_failure_and_script}
    */
    readonly enableScreenshotOnFailureAndScript?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#id SyntheticsMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The locations in which this monitor should be run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#locations_private SyntheticsMonitor#locations_private}
    */
    readonly locationsPrivate?: string[];
    /**
    * The locations in which this monitor should be run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#locations_public SyntheticsMonitor#locations_public}
    */
    readonly locationsPublic?: string[];
    /**
    * The title of this monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#name SyntheticsMonitor#name}
    */
    readonly name: string;
    /**
    * The interval at which this monitor should run. Valid values are EVERY_MINUTE, EVERY_5_MINUTES, EVERY_10_MINUTES, EVERY_15_MINUTES, EVERY_30_MINUTES, EVERY_HOUR, EVERY_6_HOURS, EVERY_12_HOURS, or EVERY_DAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#period SyntheticsMonitor#period}
    */
    readonly period?: string;
    /**
    * The runtime type that the monitor will run
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#runtime_type SyntheticsMonitor#runtime_type}
    */
    readonly runtimeType?: string;
    /**
    * The specific version of the runtime type selected
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#runtime_type_version SyntheticsMonitor#runtime_type_version}
    */
    readonly runtimeTypeVersion?: string;
    /**
    * The programing language that should execute the script
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#script_language SyntheticsMonitor#script_language}
    */
    readonly scriptLanguage?: string;
    /**
    * The monitor status (ENABLED or DISABLED).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#status SyntheticsMonitor#status}
    */
    readonly status: string;
    /**
    * Fail the monitor check if redirected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#treat_redirect_as_failure SyntheticsMonitor#treat_redirect_as_failure}
    */
    readonly treatRedirectAsFailure?: boolean | cdktn.IResolvable;
    /**
    * The monitor type. Valid values are SIMPLE AND BROWSER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#type SyntheticsMonitor#type}
    */
    readonly type: string;
    /**
    * The URI for the monitor to hit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#uri SyntheticsMonitor#uri}
    */
    readonly uri?: string;
    /**
    * A boolean attribute to be set true by the customer, if they would like to use the unsupported legacy runtime of Synthetic Monitors by means of an exemption given until the October 22, 2024 Legacy Runtime EOL. Setting this attribute to true would allow skipping validation performed by the the New Relic Terraform Provider starting v3.43.0 to disallow using the legacy runtime with new monitors. This would, hence, allow creation of monitors in the legacy runtime until the October 22, 2024 Legacy Runtime EOL, if exempt by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#use_unsupported_legacy_runtime SyntheticsMonitor#use_unsupported_legacy_runtime}
    */
    readonly useUnsupportedLegacyRuntime?: boolean | cdktn.IResolvable;
    /**
    * The string to validate against in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#validation_string SyntheticsMonitor#validation_string}
    */
    readonly validationString?: string;
    /**
    * Verify SSL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#verify_ssl SyntheticsMonitor#verify_ssl}
    */
    readonly verifySsl?: boolean | cdktn.IResolvable;
    /**
    * custom_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#custom_header SyntheticsMonitor#custom_header}
    */
    readonly customHeader?: SyntheticsMonitorCustomHeader[] | cdktn.IResolvable;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#tag SyntheticsMonitor#tag}
    */
    readonly tag?: SyntheticsMonitorTag[] | cdktn.IResolvable;
}
export interface SyntheticsMonitorCustomHeader {
    /**
    * Header name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#name SyntheticsMonitor#name}
    */
    readonly name?: string;
    /**
    * Header value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#value SyntheticsMonitor#value}
    */
    readonly value?: string;
}
export declare function syntheticsMonitorCustomHeaderToTerraform(struct?: SyntheticsMonitorCustomHeader | cdktn.IResolvable): any;
export declare function syntheticsMonitorCustomHeaderToHclTerraform(struct?: SyntheticsMonitorCustomHeader | cdktn.IResolvable): any;
export declare class SyntheticsMonitorCustomHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsMonitorCustomHeader | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsMonitorCustomHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class SyntheticsMonitorCustomHeaderList extends cdktn.ComplexList {
    internalValue?: SyntheticsMonitorCustomHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsMonitorCustomHeaderOutputReference;
}
export interface SyntheticsMonitorTag {
    /**
    * Name of the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#key SyntheticsMonitor#key}
    */
    readonly key: string;
    /**
    * Values associated with the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#values SyntheticsMonitor#values}
    */
    readonly values: string[];
}
export declare function syntheticsMonitorTagToTerraform(struct?: SyntheticsMonitorTag | cdktn.IResolvable): any;
export declare function syntheticsMonitorTagToHclTerraform(struct?: SyntheticsMonitorTag | cdktn.IResolvable): any;
export declare class SyntheticsMonitorTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsMonitorTag | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsMonitorTag | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class SyntheticsMonitorTagList extends cdktn.ComplexList {
    internalValue?: SyntheticsMonitorTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsMonitorTagOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor newrelic_synthetics_monitor}
*/
export declare class SyntheticsMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_synthetics_monitor";
    /**
    * Generates CDKTN code for importing a SyntheticsMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsMonitor to import
    * @param importFromId The id of the existing SyntheticsMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/synthetics_monitor newrelic_synthetics_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsMonitorConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsMonitorConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _browsers?;
    get browsers(): string[];
    set browsers(value: string[]);
    resetBrowsers(): void;
    get browsersInput(): string[] | undefined;
    private _bypassHeadRequest?;
    get bypassHeadRequest(): boolean | cdktn.IResolvable;
    set bypassHeadRequest(value: boolean | cdktn.IResolvable);
    resetBypassHeadRequest(): void;
    get bypassHeadRequestInput(): boolean | cdktn.IResolvable | undefined;
    private _deviceOrientation?;
    get deviceOrientation(): string;
    set deviceOrientation(value: string);
    resetDeviceOrientation(): void;
    get deviceOrientationInput(): string | undefined;
    private _deviceType?;
    get deviceType(): string;
    set deviceType(value: string);
    resetDeviceType(): void;
    get deviceTypeInput(): string | undefined;
    private _devices?;
    get devices(): string[];
    set devices(value: string[]);
    resetDevices(): void;
    get devicesInput(): string[] | undefined;
    private _enableScreenshotOnFailureAndScript?;
    get enableScreenshotOnFailureAndScript(): boolean | cdktn.IResolvable;
    set enableScreenshotOnFailureAndScript(value: boolean | cdktn.IResolvable);
    resetEnableScreenshotOnFailureAndScript(): void;
    get enableScreenshotOnFailureAndScriptInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationsPrivate?;
    get locationsPrivate(): string[];
    set locationsPrivate(value: string[]);
    resetLocationsPrivate(): void;
    get locationsPrivateInput(): string[] | undefined;
    private _locationsPublic?;
    get locationsPublic(): string[];
    set locationsPublic(value: string[]);
    resetLocationsPublic(): void;
    get locationsPublicInput(): string[] | undefined;
    get monitorId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    resetPeriod(): void;
    get periodInput(): string | undefined;
    get periodInMinutes(): number;
    private _runtimeType?;
    get runtimeType(): string;
    set runtimeType(value: string);
    resetRuntimeType(): void;
    get runtimeTypeInput(): string | undefined;
    private _runtimeTypeVersion?;
    get runtimeTypeVersion(): string;
    set runtimeTypeVersion(value: string);
    resetRuntimeTypeVersion(): void;
    get runtimeTypeVersionInput(): string | undefined;
    private _scriptLanguage?;
    get scriptLanguage(): string;
    set scriptLanguage(value: string);
    resetScriptLanguage(): void;
    get scriptLanguageInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _treatRedirectAsFailure?;
    get treatRedirectAsFailure(): boolean | cdktn.IResolvable;
    set treatRedirectAsFailure(value: boolean | cdktn.IResolvable);
    resetTreatRedirectAsFailure(): void;
    get treatRedirectAsFailureInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
    private _useUnsupportedLegacyRuntime?;
    get useUnsupportedLegacyRuntime(): boolean | cdktn.IResolvable;
    set useUnsupportedLegacyRuntime(value: boolean | cdktn.IResolvable);
    resetUseUnsupportedLegacyRuntime(): void;
    get useUnsupportedLegacyRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _validationString?;
    get validationString(): string;
    set validationString(value: string);
    resetValidationString(): void;
    get validationStringInput(): string | undefined;
    private _verifySsl?;
    get verifySsl(): boolean | cdktn.IResolvable;
    set verifySsl(value: boolean | cdktn.IResolvable);
    resetVerifySsl(): void;
    get verifySslInput(): boolean | cdktn.IResolvable | undefined;
    private _customHeader;
    get customHeader(): SyntheticsMonitorCustomHeaderList;
    putCustomHeader(value: SyntheticsMonitorCustomHeader[] | cdktn.IResolvable): void;
    resetCustomHeader(): void;
    get customHeaderInput(): cdktn.IResolvable | SyntheticsMonitorCustomHeader[] | undefined;
    private _tag;
    get tag(): SyntheticsMonitorTagList;
    putTag(value: SyntheticsMonitorTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | SyntheticsMonitorTag[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
