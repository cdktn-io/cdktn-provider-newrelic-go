/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MetricPruningRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account ID in which the pruning rule is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/metric_pruning_rule#account_id MetricPruningRule#account_id}
    */
    readonly accountId?: number;
    /**
    * A human-readable description of the pruning rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/metric_pruning_rule#description MetricPruningRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/metric_pruning_rule#id MetricPruningRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The NRQL query that identifies the metric attributes to prune. Must select specific attributes from Metric (e.g. `SELECT collector.name FROM Metric WHERE metricName = 'my.metric'`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/metric_pruning_rule#nrql MetricPruningRule#nrql}
    */
    readonly nrql: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/metric_pruning_rule newrelic_metric_pruning_rule}
*/
export declare class MetricPruningRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_metric_pruning_rule";
    /**
    * Generates CDKTN code for importing a MetricPruningRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MetricPruningRule to import
    * @param importFromId The id of the existing MetricPruningRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/metric_pruning_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MetricPruningRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.2/docs/resources/metric_pruning_rule newrelic_metric_pruning_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MetricPruningRuleConfig
    */
    constructor(scope: Construct, id: string, config: MetricPruningRuleConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
    get ruleId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
