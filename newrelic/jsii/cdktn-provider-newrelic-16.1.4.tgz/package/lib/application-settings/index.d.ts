/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The response time threshold value for Apdex score calculation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#app_apdex_threshold ApplicationSettings#app_apdex_threshold}
    */
    readonly appApdexThreshold?: number;
    /**
    * Dummy field to support backward compatibility of previous version.should be removed with next major version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#enable_real_user_monitoring ApplicationSettings#enable_real_user_monitoring}
    */
    readonly enableRealUserMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Samples and reports the slowest database queries in your traces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#enable_slow_sql ApplicationSettings#enable_slow_sql}
    */
    readonly enableSlowSql?: boolean | cdktn.IResolvable;
    /**
    * Enable or disable the thread profiler.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#enable_thread_profiler ApplicationSettings#enable_thread_profiler}
    */
    readonly enableThreadProfiler?: boolean | cdktn.IResolvable;
    /**
    * Dummy field to support backward compatibility of previous version.should be removed with next major version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#end_user_apdex_threshold ApplicationSettings#end_user_apdex_threshold}
    */
    readonly endUserApdexThreshold?: number;
    /**
    * The GUID of the application in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#guid ApplicationSettings#guid}
    */
    readonly guid?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#id ApplicationSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the application in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#name ApplicationSettings#name}
    */
    readonly name?: string;
    /**
    * The type of tracer to use, either 'CROSS_APPLICATION_TRACER', 'DISTRIBUTED_TRACING', 'NONE', or 'OPT_OUT'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#tracer_type ApplicationSettings#tracer_type}
    */
    readonly tracerType?: string;
    /**
    * Enable or disable server side monitoring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#use_server_side_config ApplicationSettings#use_server_side_config}
    */
    readonly useServerSideConfig?: boolean | cdktn.IResolvable;
    /**
    * error_collector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#error_collector ApplicationSettings#error_collector}
    */
    readonly errorCollector?: ApplicationSettingsErrorCollector[] | cdktn.IResolvable;
    /**
    * transaction_tracer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#transaction_tracer ApplicationSettings#transaction_tracer}
    */
    readonly transactionTracer?: ApplicationSettingsTransactionTracer[] | cdktn.IResolvable;
}
export interface ApplicationSettingsErrorCollector {
    /**
    * A list of error classes that are expected and should not trigger alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#expected_error_classes ApplicationSettings#expected_error_classes}
    */
    readonly expectedErrorClasses?: string[];
    /**
    * A list of error codes that are expected and should not trigger alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#expected_error_codes ApplicationSettings#expected_error_codes}
    */
    readonly expectedErrorCodes?: string[];
    /**
    * A list of error classes that should be ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#ignored_error_classes ApplicationSettings#ignored_error_classes}
    */
    readonly ignoredErrorClasses?: string[];
    /**
    * A list of error codes that should be ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#ignored_error_codes ApplicationSettings#ignored_error_codes}
    */
    readonly ignoredErrorCodes?: string[];
}
export declare function applicationSettingsErrorCollectorToTerraform(struct?: ApplicationSettingsErrorCollector | cdktn.IResolvable): any;
export declare function applicationSettingsErrorCollectorToHclTerraform(struct?: ApplicationSettingsErrorCollector | cdktn.IResolvable): any;
export declare class ApplicationSettingsErrorCollectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationSettingsErrorCollector | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationSettingsErrorCollector | cdktn.IResolvable | undefined);
    private _expectedErrorClasses?;
    get expectedErrorClasses(): string[];
    set expectedErrorClasses(value: string[]);
    resetExpectedErrorClasses(): void;
    get expectedErrorClassesInput(): string[] | undefined;
    private _expectedErrorCodes?;
    get expectedErrorCodes(): string[];
    set expectedErrorCodes(value: string[]);
    resetExpectedErrorCodes(): void;
    get expectedErrorCodesInput(): string[] | undefined;
    private _ignoredErrorClasses?;
    get ignoredErrorClasses(): string[];
    set ignoredErrorClasses(value: string[]);
    resetIgnoredErrorClasses(): void;
    get ignoredErrorClassesInput(): string[] | undefined;
    private _ignoredErrorCodes?;
    get ignoredErrorCodes(): string[];
    set ignoredErrorCodes(value: string[]);
    resetIgnoredErrorCodes(): void;
    get ignoredErrorCodesInput(): string[] | undefined;
}
export declare class ApplicationSettingsErrorCollectorList extends cdktn.ComplexList {
    internalValue?: ApplicationSettingsErrorCollector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationSettingsErrorCollectorOutputReference;
}
export interface ApplicationSettingsTransactionTracerExplainQueryPlans {
    /**
    * The type of threshold for explain plans, either 'APDEX_F' or 'VALUE'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#query_plan_threshold_type ApplicationSettings#query_plan_threshold_type}
    */
    readonly queryPlanThresholdType?: string;
    /**
    * The threshold value for explain plans when 'query_plan_threshold_type' is 'VALUE'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#query_plan_threshold_value ApplicationSettings#query_plan_threshold_value}
    */
    readonly queryPlanThresholdValue?: number;
}
export declare function applicationSettingsTransactionTracerExplainQueryPlansToTerraform(struct?: ApplicationSettingsTransactionTracerExplainQueryPlans | cdktn.IResolvable): any;
export declare function applicationSettingsTransactionTracerExplainQueryPlansToHclTerraform(struct?: ApplicationSettingsTransactionTracerExplainQueryPlans | cdktn.IResolvable): any;
export declare class ApplicationSettingsTransactionTracerExplainQueryPlansOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationSettingsTransactionTracerExplainQueryPlans | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationSettingsTransactionTracerExplainQueryPlans | cdktn.IResolvable | undefined);
    private _queryPlanThresholdType?;
    get queryPlanThresholdType(): string;
    set queryPlanThresholdType(value: string);
    resetQueryPlanThresholdType(): void;
    get queryPlanThresholdTypeInput(): string | undefined;
    private _queryPlanThresholdValue?;
    get queryPlanThresholdValue(): number;
    set queryPlanThresholdValue(value: number);
    resetQueryPlanThresholdValue(): void;
    get queryPlanThresholdValueInput(): number | undefined;
}
export declare class ApplicationSettingsTransactionTracerExplainQueryPlansList extends cdktn.ComplexList {
    internalValue?: ApplicationSettingsTransactionTracerExplainQueryPlans[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationSettingsTransactionTracerExplainQueryPlansOutputReference;
}
export interface ApplicationSettingsTransactionTracerSql {
    /**
    * The level of SQL recording, either 'OBFUSCATED', 'OFF', or 'RAW'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#record_sql ApplicationSettings#record_sql}
    */
    readonly recordSql: string;
}
export declare function applicationSettingsTransactionTracerSqlToTerraform(struct?: ApplicationSettingsTransactionTracerSqlOutputReference | ApplicationSettingsTransactionTracerSql): any;
export declare function applicationSettingsTransactionTracerSqlToHclTerraform(struct?: ApplicationSettingsTransactionTracerSqlOutputReference | ApplicationSettingsTransactionTracerSql): any;
export declare class ApplicationSettingsTransactionTracerSqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationSettingsTransactionTracerSql | undefined;
    set internalValue(value: ApplicationSettingsTransactionTracerSql | undefined);
    private _recordSql?;
    get recordSql(): string;
    set recordSql(value: string);
    get recordSqlInput(): string | undefined;
}
export interface ApplicationSettingsTransactionTracer {
    /**
    * The response time threshold value for capturing stack traces of SQL queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#stack_trace_threshold_value ApplicationSettings#stack_trace_threshold_value}
    */
    readonly stackTraceThresholdValue?: number;
    /**
    * The type of threshold for transaction tracing, either 'APDEX_F' or 'VALUE'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#transaction_threshold_type ApplicationSettings#transaction_threshold_type}
    */
    readonly transactionThresholdType?: string;
    /**
    * The threshold value for transaction tracing when 'transaction_threshold_type' is 'VALUE'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#transaction_threshold_value ApplicationSettings#transaction_threshold_value}
    */
    readonly transactionThresholdValue?: number;
    /**
    * explain_query_plans block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#explain_query_plans ApplicationSettings#explain_query_plans}
    */
    readonly explainQueryPlans?: ApplicationSettingsTransactionTracerExplainQueryPlans[] | cdktn.IResolvable;
    /**
    * sql block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#sql ApplicationSettings#sql}
    */
    readonly sql?: ApplicationSettingsTransactionTracerSql;
}
export declare function applicationSettingsTransactionTracerToTerraform(struct?: ApplicationSettingsTransactionTracer | cdktn.IResolvable): any;
export declare function applicationSettingsTransactionTracerToHclTerraform(struct?: ApplicationSettingsTransactionTracer | cdktn.IResolvable): any;
export declare class ApplicationSettingsTransactionTracerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationSettingsTransactionTracer | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationSettingsTransactionTracer | cdktn.IResolvable | undefined);
    private _stackTraceThresholdValue?;
    get stackTraceThresholdValue(): number;
    set stackTraceThresholdValue(value: number);
    resetStackTraceThresholdValue(): void;
    get stackTraceThresholdValueInput(): number | undefined;
    private _transactionThresholdType?;
    get transactionThresholdType(): string;
    set transactionThresholdType(value: string);
    resetTransactionThresholdType(): void;
    get transactionThresholdTypeInput(): string | undefined;
    private _transactionThresholdValue?;
    get transactionThresholdValue(): number;
    set transactionThresholdValue(value: number);
    resetTransactionThresholdValue(): void;
    get transactionThresholdValueInput(): number | undefined;
    private _explainQueryPlans;
    get explainQueryPlans(): ApplicationSettingsTransactionTracerExplainQueryPlansList;
    putExplainQueryPlans(value: ApplicationSettingsTransactionTracerExplainQueryPlans[] | cdktn.IResolvable): void;
    resetExplainQueryPlans(): void;
    get explainQueryPlansInput(): cdktn.IResolvable | ApplicationSettingsTransactionTracerExplainQueryPlans[] | undefined;
    private _sql;
    get sql(): ApplicationSettingsTransactionTracerSqlOutputReference;
    putSql(value: ApplicationSettingsTransactionTracerSql): void;
    resetSql(): void;
    get sqlInput(): ApplicationSettingsTransactionTracerSql | undefined;
}
export declare class ApplicationSettingsTransactionTracerList extends cdktn.ComplexList {
    internalValue?: ApplicationSettingsTransactionTracer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationSettingsTransactionTracerOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings newrelic_application_settings}
*/
export declare class ApplicationSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_application_settings";
    /**
    * Generates CDKTN code for importing a ApplicationSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationSettings to import
    * @param importFromId The id of the existing ApplicationSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/application_settings newrelic_application_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ApplicationSettingsConfig);
    private _appApdexThreshold?;
    get appApdexThreshold(): number;
    set appApdexThreshold(value: number);
    resetAppApdexThreshold(): void;
    get appApdexThresholdInput(): number | undefined;
    private _enableRealUserMonitoring?;
    get enableRealUserMonitoring(): boolean | cdktn.IResolvable;
    set enableRealUserMonitoring(value: boolean | cdktn.IResolvable);
    resetEnableRealUserMonitoring(): void;
    get enableRealUserMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSlowSql?;
    get enableSlowSql(): boolean | cdktn.IResolvable;
    set enableSlowSql(value: boolean | cdktn.IResolvable);
    resetEnableSlowSql(): void;
    get enableSlowSqlInput(): boolean | cdktn.IResolvable | undefined;
    private _enableThreadProfiler?;
    get enableThreadProfiler(): boolean | cdktn.IResolvable;
    set enableThreadProfiler(value: boolean | cdktn.IResolvable);
    resetEnableThreadProfiler(): void;
    get enableThreadProfilerInput(): boolean | cdktn.IResolvable | undefined;
    private _endUserApdexThreshold?;
    get endUserApdexThreshold(): number;
    set endUserApdexThreshold(value: number);
    resetEndUserApdexThreshold(): void;
    get endUserApdexThresholdInput(): number | undefined;
    private _guid?;
    get guid(): string;
    set guid(value: string);
    resetGuid(): void;
    get guidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isImported(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _tracerType?;
    get tracerType(): string;
    set tracerType(value: string);
    resetTracerType(): void;
    get tracerTypeInput(): string | undefined;
    private _useServerSideConfig?;
    get useServerSideConfig(): boolean | cdktn.IResolvable;
    set useServerSideConfig(value: boolean | cdktn.IResolvable);
    resetUseServerSideConfig(): void;
    get useServerSideConfigInput(): boolean | cdktn.IResolvable | undefined;
    private _errorCollector;
    get errorCollector(): ApplicationSettingsErrorCollectorList;
    putErrorCollector(value: ApplicationSettingsErrorCollector[] | cdktn.IResolvable): void;
    resetErrorCollector(): void;
    get errorCollectorInput(): cdktn.IResolvable | ApplicationSettingsErrorCollector[] | undefined;
    private _transactionTracer;
    get transactionTracer(): ApplicationSettingsTransactionTracerList;
    putTransactionTracer(value: ApplicationSettingsTransactionTracer[] | cdktn.IResolvable): void;
    resetTransactionTracer(): void;
    get transactionTracerInput(): cdktn.IResolvable | ApplicationSettingsTransactionTracer[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
