/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsPrivateLocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the account in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/synthetics_private_location#account_id SyntheticsPrivateLocation#account_id}
    */
    readonly accountId?: number;
    /**
    * The private location description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/synthetics_private_location#description SyntheticsPrivateLocation#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/synthetics_private_location#id SyntheticsPrivateLocation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the private location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/synthetics_private_location#name SyntheticsPrivateLocation#name}
    */
    readonly name: string;
    /**
    * Specifies whether the private location is shared across the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/synthetics_private_location#shared SyntheticsPrivateLocation#shared}
    */
    readonly shared?: boolean | cdktn.IResolvable;
    /**
    * The private location requires a password to edit if value is true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/synthetics_private_location#verified_script_execution SyntheticsPrivateLocation#verified_script_execution}
    */
    readonly verifiedScriptExecution?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/synthetics_private_location newrelic_synthetics_private_location}
*/
export declare class SyntheticsPrivateLocation extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_synthetics_private_location";
    /**
    * Generates CDKTN code for importing a SyntheticsPrivateLocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsPrivateLocation to import
    * @param importFromId The id of the existing SyntheticsPrivateLocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/synthetics_private_location#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsPrivateLocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.6/docs/resources/synthetics_private_location newrelic_synthetics_private_location} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsPrivateLocationConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsPrivateLocationConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get domainId(): string;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get key(): string;
    get locationId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _shared?;
    get shared(): boolean | cdktn.IResolvable;
    set shared(value: boolean | cdktn.IResolvable);
    resetShared(): void;
    get sharedInput(): boolean | cdktn.IResolvable | undefined;
    private _verifiedScriptExecution?;
    get verifiedScriptExecution(): boolean | cdktn.IResolvable;
    set verifiedScriptExecution(value: boolean | cdktn.IResolvable);
    resetVerifiedScriptExecution(): void;
    get verifiedScriptExecutionInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
