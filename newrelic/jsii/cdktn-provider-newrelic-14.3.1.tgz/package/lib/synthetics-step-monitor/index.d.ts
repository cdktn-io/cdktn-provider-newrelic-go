/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsStepMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the newrelic account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#account_id SyntheticsStepMonitor#account_id}
    */
    readonly accountId?: number;
    /**
    * The multiple browsers list on which synthetic monitors will run. Valid values are array of CHROME,and FIREFOX
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#browsers SyntheticsStepMonitor#browsers}
    */
    readonly browsers?: string[];
    /**
    * The multiple devices list on which synthetic monitors will run. Valid values are array of DESKTOP, MOBILE_LANDSCAPE, MOBILE_PORTRAIT, TABLET_LANDSCAPE and TABLET_PORTRAIT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#devices SyntheticsStepMonitor#devices}
    */
    readonly devices?: string[];
    /**
    * Capture a screenshot during job execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#enable_screenshot_on_failure_and_script SyntheticsStepMonitor#enable_screenshot_on_failure_and_script}
    */
    readonly enableScreenshotOnFailureAndScript?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#id SyntheticsStepMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The public location(s) that the monitor will run jobs from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#locations_public SyntheticsStepMonitor#locations_public}
    */
    readonly locationsPublic?: string[];
    /**
    * The title of this monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#name SyntheticsStepMonitor#name}
    */
    readonly name: string;
    /**
    * The interval at which this monitor should run. Valid values are EVERY_MINUTE, EVERY_5_MINUTES, EVERY_10_MINUTES, EVERY_15_MINUTES, EVERY_30_MINUTES, EVERY_HOUR, EVERY_6_HOURS, EVERY_12_HOURS, or EVERY_DAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#period SyntheticsStepMonitor#period}
    */
    readonly period: string;
    /**
    * The runtime type that the monitor will run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#runtime_type SyntheticsStepMonitor#runtime_type}
    */
    readonly runtimeType?: string;
    /**
    * The specific semver version of the runtime type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#runtime_type_version SyntheticsStepMonitor#runtime_type_version}
    */
    readonly runtimeTypeVersion?: string;
    /**
    * The monitor status (ENABLED or DISABLED).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#status SyntheticsStepMonitor#status}
    */
    readonly status: string;
    /**
    * A boolean attribute to be set true by the customer, if they would like to use the unsupported legacy runtime of Synthetic Monitors by means of an exemption given until the October 22, 2024 Legacy Runtime EOL. Setting this attribute to true would allow skipping validation performed by the the New Relic Terraform Provider starting v3.43.0 to disallow using the legacy runtime with new monitors. This would, hence, allow creation of monitors in the legacy runtime until the October 22, 2024 Legacy Runtime EOL, if exempt by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#use_unsupported_legacy_runtime SyntheticsStepMonitor#use_unsupported_legacy_runtime}
    */
    readonly useUnsupportedLegacyRuntime?: boolean | cdktn.IResolvable;
    /**
    * location_private block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#location_private SyntheticsStepMonitor#location_private}
    */
    readonly locationPrivate?: SyntheticsStepMonitorLocationPrivate[] | cdktn.IResolvable;
    /**
    * steps block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#steps SyntheticsStepMonitor#steps}
    */
    readonly steps: SyntheticsStepMonitorSteps[] | cdktn.IResolvable;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#tag SyntheticsStepMonitor#tag}
    */
    readonly tag?: SyntheticsStepMonitorTag[] | cdktn.IResolvable;
}
export interface SyntheticsStepMonitorLocationPrivate {
    /**
    * The unique identifier for the Synthetics private location in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#guid SyntheticsStepMonitor#guid}
    */
    readonly guid: string;
    /**
    * The location's Verified Script Execution password (Only necessary if Verified Script Execution is enabled for the location).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#vse_password SyntheticsStepMonitor#vse_password}
    */
    readonly vsePassword?: string;
}
export declare function syntheticsStepMonitorLocationPrivateToTerraform(struct?: SyntheticsStepMonitorLocationPrivate | cdktn.IResolvable): any;
export declare function syntheticsStepMonitorLocationPrivateToHclTerraform(struct?: SyntheticsStepMonitorLocationPrivate | cdktn.IResolvable): any;
export declare class SyntheticsStepMonitorLocationPrivateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsStepMonitorLocationPrivate | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsStepMonitorLocationPrivate | cdktn.IResolvable | undefined);
    private _guid?;
    get guid(): string;
    set guid(value: string);
    get guidInput(): string | undefined;
    private _vsePassword?;
    get vsePassword(): string;
    set vsePassword(value: string);
    resetVsePassword(): void;
    get vsePasswordInput(): string | undefined;
}
export declare class SyntheticsStepMonitorLocationPrivateList extends cdktn.ComplexList {
    internalValue?: SyntheticsStepMonitorLocationPrivate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsStepMonitorLocationPrivateOutputReference;
}
export interface SyntheticsStepMonitorSteps {
    /**
    * The position of the step within the script ranging from 0-100
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#ordinal SyntheticsStepMonitor#ordinal}
    */
    readonly ordinal: number;
    /**
    * The type of step to be added to the script.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#type SyntheticsStepMonitor#type}
    */
    readonly type: string;
    /**
    * The metadata values related to the check the step performs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#values SyntheticsStepMonitor#values}
    */
    readonly values?: string[];
}
export declare function syntheticsStepMonitorStepsToTerraform(struct?: SyntheticsStepMonitorSteps | cdktn.IResolvable): any;
export declare function syntheticsStepMonitorStepsToHclTerraform(struct?: SyntheticsStepMonitorSteps | cdktn.IResolvable): any;
export declare class SyntheticsStepMonitorStepsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsStepMonitorSteps | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsStepMonitorSteps | cdktn.IResolvable | undefined);
    private _ordinal?;
    get ordinal(): number;
    set ordinal(value: number);
    get ordinalInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class SyntheticsStepMonitorStepsList extends cdktn.ComplexList {
    internalValue?: SyntheticsStepMonitorSteps[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsStepMonitorStepsOutputReference;
}
export interface SyntheticsStepMonitorTag {
    /**
    * Name of the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#key SyntheticsStepMonitor#key}
    */
    readonly key: string;
    /**
    * Values associated with the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#values SyntheticsStepMonitor#values}
    */
    readonly values: string[];
}
export declare function syntheticsStepMonitorTagToTerraform(struct?: SyntheticsStepMonitorTag | cdktn.IResolvable): any;
export declare function syntheticsStepMonitorTagToHclTerraform(struct?: SyntheticsStepMonitorTag | cdktn.IResolvable): any;
export declare class SyntheticsStepMonitorTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsStepMonitorTag | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsStepMonitorTag | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class SyntheticsStepMonitorTagList extends cdktn.ComplexList {
    internalValue?: SyntheticsStepMonitorTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsStepMonitorTagOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor newrelic_synthetics_step_monitor}
*/
export declare class SyntheticsStepMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_synthetics_step_monitor";
    /**
    * Generates CDKTN code for importing a SyntheticsStepMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsStepMonitor to import
    * @param importFromId The id of the existing SyntheticsStepMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsStepMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/resources/synthetics_step_monitor newrelic_synthetics_step_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsStepMonitorConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsStepMonitorConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _browsers?;
    get browsers(): string[];
    set browsers(value: string[]);
    resetBrowsers(): void;
    get browsersInput(): string[] | undefined;
    private _devices?;
    get devices(): string[];
    set devices(value: string[]);
    resetDevices(): void;
    get devicesInput(): string[] | undefined;
    private _enableScreenshotOnFailureAndScript?;
    get enableScreenshotOnFailureAndScript(): boolean | cdktn.IResolvable;
    set enableScreenshotOnFailureAndScript(value: boolean | cdktn.IResolvable);
    resetEnableScreenshotOnFailureAndScript(): void;
    get enableScreenshotOnFailureAndScriptInput(): boolean | cdktn.IResolvable | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationsPublic?;
    get locationsPublic(): string[];
    set locationsPublic(value: string[]);
    resetLocationsPublic(): void;
    get locationsPublicInput(): string[] | undefined;
    get monitorId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    get periodInput(): string | undefined;
    get periodInMinutes(): number;
    private _runtimeType?;
    get runtimeType(): string;
    set runtimeType(value: string);
    resetRuntimeType(): void;
    get runtimeTypeInput(): string | undefined;
    private _runtimeTypeVersion?;
    get runtimeTypeVersion(): string;
    set runtimeTypeVersion(value: string);
    resetRuntimeTypeVersion(): void;
    get runtimeTypeVersionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _useUnsupportedLegacyRuntime?;
    get useUnsupportedLegacyRuntime(): boolean | cdktn.IResolvable;
    set useUnsupportedLegacyRuntime(value: boolean | cdktn.IResolvable);
    resetUseUnsupportedLegacyRuntime(): void;
    get useUnsupportedLegacyRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _locationPrivate;
    get locationPrivate(): SyntheticsStepMonitorLocationPrivateList;
    putLocationPrivate(value: SyntheticsStepMonitorLocationPrivate[] | cdktn.IResolvable): void;
    resetLocationPrivate(): void;
    get locationPrivateInput(): cdktn.IResolvable | SyntheticsStepMonitorLocationPrivate[] | undefined;
    private _steps;
    get steps(): SyntheticsStepMonitorStepsList;
    putSteps(value: SyntheticsStepMonitorSteps[] | cdktn.IResolvable): void;
    get stepsInput(): cdktn.IResolvable | SyntheticsStepMonitorSteps[] | undefined;
    private _tag;
    get tag(): SyntheticsStepMonitorTagList;
    putTag(value: SyntheticsStepMonitorTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | SyntheticsStepMonitorTag[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
