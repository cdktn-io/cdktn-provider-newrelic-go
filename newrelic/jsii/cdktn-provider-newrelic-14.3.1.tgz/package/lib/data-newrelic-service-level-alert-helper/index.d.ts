/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicServiceLevelAlertHelperConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper#alert_type DataNewrelicServiceLevelAlertHelper#alert_type}
    */
    readonly alertType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper#custom_evaluation_period DataNewrelicServiceLevelAlertHelper#custom_evaluation_period}
    */
    readonly customEvaluationPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper#custom_tolerated_budget_consumption DataNewrelicServiceLevelAlertHelper#custom_tolerated_budget_consumption}
    */
    readonly customToleratedBudgetConsumption?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper#id DataNewrelicServiceLevelAlertHelper#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper#is_bad_events DataNewrelicServiceLevelAlertHelper#is_bad_events}
    */
    readonly isBadEvents?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper#sli_guid DataNewrelicServiceLevelAlertHelper#sli_guid}
    */
    readonly sliGuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper#slo_period DataNewrelicServiceLevelAlertHelper#slo_period}
    */
    readonly sloPeriod: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper#slo_target DataNewrelicServiceLevelAlertHelper#slo_target}
    */
    readonly sloTarget: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper newrelic_service_level_alert_helper}
*/
export declare class DataNewrelicServiceLevelAlertHelper extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_service_level_alert_helper";
    /**
    * Generates CDKTN code for importing a DataNewrelicServiceLevelAlertHelper resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicServiceLevelAlertHelper to import
    * @param importFromId The id of the existing DataNewrelicServiceLevelAlertHelper that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicServiceLevelAlertHelper to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/service_level_alert_helper newrelic_service_level_alert_helper} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicServiceLevelAlertHelperConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicServiceLevelAlertHelperConfig);
    private _alertType?;
    get alertType(): string;
    set alertType(value: string);
    get alertTypeInput(): string | undefined;
    private _customEvaluationPeriod?;
    get customEvaluationPeriod(): number;
    set customEvaluationPeriod(value: number);
    resetCustomEvaluationPeriod(): void;
    get customEvaluationPeriodInput(): number | undefined;
    private _customToleratedBudgetConsumption?;
    get customToleratedBudgetConsumption(): number;
    set customToleratedBudgetConsumption(value: number);
    resetCustomToleratedBudgetConsumption(): void;
    get customToleratedBudgetConsumptionInput(): number | undefined;
    get evaluationPeriod(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isBadEvents?;
    get isBadEvents(): boolean | cdktn.IResolvable;
    set isBadEvents(value: boolean | cdktn.IResolvable);
    resetIsBadEvents(): void;
    get isBadEventsInput(): boolean | cdktn.IResolvable | undefined;
    get nrql(): string;
    private _sliGuid?;
    get sliGuid(): string;
    set sliGuid(value: string);
    get sliGuidInput(): string | undefined;
    private _sloPeriod?;
    get sloPeriod(): number;
    set sloPeriod(value: number);
    get sloPeriodInput(): number | undefined;
    private _sloTarget?;
    get sloTarget(): number;
    set sloTarget(value: number);
    get sloTargetInput(): number | undefined;
    get threshold(): number;
    get toleratedBudgetConsumption(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
