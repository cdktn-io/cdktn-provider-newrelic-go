/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicAuthenticationDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the authentication domain to be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/authentication_domain#name DataNewrelicAuthenticationDomain#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/authentication_domain newrelic_authentication_domain}
*/
export declare class DataNewrelicAuthenticationDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_authentication_domain";
    /**
    * Generates CDKTN code for importing a DataNewrelicAuthenticationDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicAuthenticationDomain to import
    * @param importFromId The id of the existing DataNewrelicAuthenticationDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/authentication_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicAuthenticationDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.1/docs/data-sources/authentication_domain newrelic_authentication_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicAuthenticationDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicAuthenticationDomainConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
