/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicEntityConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID; if specified, constrains the data source to return an entity belonging to the account with this ID, of all matching entities retrieved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#account_id DataNewrelicEntity#account_id}
    */
    readonly accountId?: number;
    /**
    * The entity's domain. Valid values are APM, BROWSER, INFRA, MOBILE, SYNTH, and EXT. If not specified, all domains are searched.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#domain DataNewrelicEntity#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#entity_tags DataNewrelicEntity#entity_tags}
    */
    readonly entityTags?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#id DataNewrelicEntity#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Ignore case when searching the entity name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#ignore_case DataNewrelicEntity#ignore_case}
    */
    readonly ignoreCase?: boolean | cdktn.IResolvable;
    /**
    * A boolean attribute which when set to true, does not throw an error if the queried entity is not found.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#ignore_not_found DataNewrelicEntity#ignore_not_found}
    */
    readonly ignoreNotFound?: boolean | cdktn.IResolvable;
    /**
    * The name of the entity in New Relic One. The first entity matching this name for the given search parameters will be returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#name DataNewrelicEntity#name}
    */
    readonly name: string;
    /**
    * The entity's type. Valid values are APPLICATION, DASHBOARD, HOST, MONITOR, SERVICE and WORKLOAD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#type DataNewrelicEntity#type}
    */
    readonly type?: string;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#tag DataNewrelicEntity#tag}
    */
    readonly tag?: DataNewrelicEntityTag[] | cdktn.IResolvable;
}
export interface DataNewrelicEntityTag {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#key DataNewrelicEntity#key}
    */
    readonly key: string;
    /**
    * The tag value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#value DataNewrelicEntity#value}
    */
    readonly value: string;
}
export declare function dataNewrelicEntityTagToTerraform(struct?: DataNewrelicEntityTag | cdktn.IResolvable): any;
export declare function dataNewrelicEntityTagToHclTerraform(struct?: DataNewrelicEntityTag | cdktn.IResolvable): any;
export declare class DataNewrelicEntityTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNewrelicEntityTag | cdktn.IResolvable | undefined;
    set internalValue(value: DataNewrelicEntityTag | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataNewrelicEntityTagList extends cdktn.ComplexList {
    internalValue?: DataNewrelicEntityTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNewrelicEntityTagOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity newrelic_entity}
*/
export declare class DataNewrelicEntity extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_entity";
    /**
    * Generates CDKTN code for importing a DataNewrelicEntity resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicEntity to import
    * @param importFromId The id of the existing DataNewrelicEntity that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicEntity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/data-sources/entity newrelic_entity} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicEntityConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicEntityConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    get applicationId(): number;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _entityTags?;
    get entityTags(): string;
    set entityTags(value: string);
    resetEntityTags(): void;
    get entityTagsInput(): string | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreCase?;
    get ignoreCase(): boolean | cdktn.IResolvable;
    set ignoreCase(value: boolean | cdktn.IResolvable);
    resetIgnoreCase(): void;
    get ignoreCaseInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreNotFound?;
    get ignoreNotFound(): boolean | cdktn.IResolvable;
    set ignoreNotFound(value: boolean | cdktn.IResolvable);
    resetIgnoreNotFound(): void;
    get ignoreNotFoundInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get servingApmApplicationId(): number;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _tag;
    get tag(): DataNewrelicEntityTagList;
    putTag(value: DataNewrelicEntityTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | DataNewrelicEntityTag[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
