/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkflowAutomationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The YAML definition of the workflow automation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/workflow_automation#definition WorkflowAutomation#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/workflow_automation#id WorkflowAutomation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the workflow automation. Must match the name in the YAML definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/workflow_automation#name WorkflowAutomation#name}
    */
    readonly name: string;
    /**
    * The scope ID (account ID for ACCOUNT scope, organization ID for ORGANIZATION scope).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/workflow_automation#scope_id WorkflowAutomation#scope_id}
    */
    readonly scopeId: string;
    /**
    * The scope type. Supported values are: ACCOUNT, ORGANIZATION.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/workflow_automation#scope_type WorkflowAutomation#scope_type}
    */
    readonly scopeType: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/workflow_automation newrelic_workflow_automation}
*/
export declare class WorkflowAutomation extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_workflow_automation";
    /**
    * Generates CDKTN code for importing a WorkflowAutomation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkflowAutomation to import
    * @param importFromId The id of the existing WorkflowAutomation that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/workflow_automation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkflowAutomation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/workflow_automation newrelic_workflow_automation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkflowAutomationConfig
    */
    constructor(scope: Construct, id: string, config: WorkflowAutomationConfig);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    get definitionId(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _scopeId?;
    get scopeId(): string;
    set scopeId(value: string);
    get scopeIdInput(): string | undefined;
    private _scopeType?;
    get scopeType(): string;
    set scopeType(value: string);
    get scopeTypeInput(): string | undefined;
    get version(): number;
    get yaml(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
