/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertCompoundConditionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID for managing your compound alert conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#account_id AlertCompoundCondition#account_id}
    */
    readonly accountId?: number;
    /**
    * BETA PREVIEW: the `description` field is in limited release and only enabled for preview on a per-account basis. The custom violation description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#description AlertCompoundCondition#description}
    */
    readonly description?: string;
    /**
    * Whether or not to enable the alert condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#enabled AlertCompoundCondition#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * How the compound condition will take into account the component conditions' facets during evaluation. Valid values: 'FACETS_IGNORED' (default) - facets are not taken into consideration when determining when the compound alert condition activates; 'FACETS_MATCH' - the compound alert condition will activate only when shared facets have matching values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#facet_matching_behavior AlertCompoundCondition#facet_matching_behavior}
    */
    readonly facetMatchingBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#id AlertCompoundCondition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The title of the compound alert condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#name AlertCompoundCondition#name}
    */
    readonly name: string;
    /**
    * The ID of the policy where this condition should be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#policy_id AlertCompoundCondition#policy_id}
    */
    readonly policyId: number;
    /**
    * Runbook URL to display in notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#runbook_url AlertCompoundCondition#runbook_url}
    */
    readonly runbookUrl?: string;
    /**
    * The duration, in seconds, that the trigger expression must be true before the compound alert condition will activate. Between 30-86400 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#threshold_duration AlertCompoundCondition#threshold_duration}
    */
    readonly thresholdDuration?: number;
    /**
    * BETA PREVIEW: the `title_template` field is in limited release and only enabled for preview on a per-account basis. This field allows you to create a custom title to be used when incidents are opened by the condition. Setting this field will override the default title. Must be Handlebars format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#title_template AlertCompoundCondition#title_template}
    */
    readonly titleTemplate?: string;
    /**
    * Expression that defines how component condition evaluations are combined. Valid operators are 'AND', 'OR', 'NOT'. For more complex expressions, use parentheses. Simple example: 'A AND B'. Complex example: 'A AND (B OR C) AND NOT D'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#trigger_expression AlertCompoundCondition#trigger_expression}
    */
    readonly triggerExpression: string;
    /**
    * component_conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#component_conditions AlertCompoundCondition#component_conditions}
    */
    readonly componentConditions: AlertCompoundConditionComponentConditions[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#timeouts AlertCompoundCondition#timeouts}
    */
    readonly timeouts?: AlertCompoundConditionTimeouts;
}
export interface AlertCompoundConditionComponentConditions {
    /**
    * The identifier that will be used in the compound alert condition's trigger_expression (e.g., 'A', 'B', 'C').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#alias AlertCompoundCondition#alias}
    */
    readonly alias: string;
    /**
    * The ID of the existing alert condition to use as a component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#id AlertCompoundCondition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function alertCompoundConditionComponentConditionsToTerraform(struct?: AlertCompoundConditionComponentConditions | cdktn.IResolvable): any;
export declare function alertCompoundConditionComponentConditionsToHclTerraform(struct?: AlertCompoundConditionComponentConditions | cdktn.IResolvable): any;
export declare class AlertCompoundConditionComponentConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertCompoundConditionComponentConditions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertCompoundConditionComponentConditions | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    get aliasInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class AlertCompoundConditionComponentConditionsList extends cdktn.ComplexList {
    internalValue?: AlertCompoundConditionComponentConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertCompoundConditionComponentConditionsOutputReference;
}
export interface AlertCompoundConditionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#create AlertCompoundCondition#create}
    */
    readonly create?: string;
}
export declare function alertCompoundConditionTimeoutsToTerraform(struct?: AlertCompoundConditionTimeouts | cdktn.IResolvable): any;
export declare function alertCompoundConditionTimeoutsToHclTerraform(struct?: AlertCompoundConditionTimeouts | cdktn.IResolvable): any;
export declare class AlertCompoundConditionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertCompoundConditionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AlertCompoundConditionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition newrelic_alert_compound_condition}
*/
export declare class AlertCompoundCondition extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_alert_compound_condition";
    /**
    * Generates CDKTN code for importing a AlertCompoundCondition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertCompoundCondition to import
    * @param importFromId The id of the existing AlertCompoundCondition that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertCompoundCondition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.96.2/docs/resources/alert_compound_condition newrelic_alert_compound_condition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertCompoundConditionConfig
    */
    constructor(scope: Construct, id: string, config: AlertCompoundConditionConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get entityGuid(): string;
    private _facetMatchingBehavior?;
    get facetMatchingBehavior(): string;
    set facetMatchingBehavior(value: string);
    resetFacetMatchingBehavior(): void;
    get facetMatchingBehaviorInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyId?;
    get policyId(): number;
    set policyId(value: number);
    get policyIdInput(): number | undefined;
    private _runbookUrl?;
    get runbookUrl(): string;
    set runbookUrl(value: string);
    resetRunbookUrl(): void;
    get runbookUrlInput(): string | undefined;
    private _thresholdDuration?;
    get thresholdDuration(): number;
    set thresholdDuration(value: number);
    resetThresholdDuration(): void;
    get thresholdDurationInput(): number | undefined;
    private _titleTemplate?;
    get titleTemplate(): string;
    set titleTemplate(value: string);
    resetTitleTemplate(): void;
    get titleTemplateInput(): string | undefined;
    private _triggerExpression?;
    get triggerExpression(): string;
    set triggerExpression(value: string);
    get triggerExpressionInput(): string | undefined;
    private _componentConditions;
    get componentConditions(): AlertCompoundConditionComponentConditionsList;
    putComponentConditions(value: AlertCompoundConditionComponentConditions[] | cdktn.IResolvable): void;
    get componentConditionsInput(): cdktn.IResolvable | AlertCompoundConditionComponentConditions[] | undefined;
    private _timeouts;
    get timeouts(): AlertCompoundConditionTimeoutsOutputReference;
    putTimeouts(value: AlertCompoundConditionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AlertCompoundConditionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
