/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MonitorDowntimeConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the New Relic account in which the Monitor Downtime shall be created. Defaults to the `account_id` in the provider{} configuration if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#account_id MonitorDowntime#account_id}
    */
    readonly accountId?: number;
    /**
    * A datetime stamp signifying the end of the Monitor Downtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#end_time MonitorDowntime#end_time}
    */
    readonly endTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#id MonitorDowntime#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A list of maintenance days to be included with the created weekly Monitor Downtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#maintenance_days MonitorDowntime#maintenance_days}
    */
    readonly maintenanceDays?: string[];
    /**
    * An identifier of the type of Monitor Downtime to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#mode MonitorDowntime#mode}
    */
    readonly mode: string;
    /**
    * A list of GUIDs of monitors, to which the created Monitor Downtime shall be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#monitor_guids MonitorDowntime#monitor_guids}
    */
    readonly monitorGuids?: string[];
    /**
    * A name to identify the Monitor Downtime to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#name MonitorDowntime#name}
    */
    readonly name: string;
    /**
    * A datetime stamp signifying the start of the Monitor Downtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#start_time MonitorDowntime#start_time}
    */
    readonly startTime: string;
    /**
    * The timezone that applies to the Monitor Downtime schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#time_zone MonitorDowntime#time_zone}
    */
    readonly timeZone: string;
    /**
    * end_repeat block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#end_repeat MonitorDowntime#end_repeat}
    */
    readonly endRepeat?: MonitorDowntimeEndRepeat;
    /**
    * frequency block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#frequency MonitorDowntime#frequency}
    */
    readonly frequency?: MonitorDowntimeFrequency;
}
export interface MonitorDowntimeEndRepeat {
    /**
    * A date, on which the Monitor Downtime's repeat cycle is expected to end.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#on_date MonitorDowntime#on_date}
    */
    readonly onDate?: string;
    /**
    * Number of repetitions after which the Monitor Downtime's repeat cycle is expected to end.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#on_repeat MonitorDowntime#on_repeat}
    */
    readonly onRepeat?: number;
}
export declare function monitorDowntimeEndRepeatToTerraform(struct?: MonitorDowntimeEndRepeatOutputReference | MonitorDowntimeEndRepeat): any;
export declare function monitorDowntimeEndRepeatToHclTerraform(struct?: MonitorDowntimeEndRepeatOutputReference | MonitorDowntimeEndRepeat): any;
export declare class MonitorDowntimeEndRepeatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorDowntimeEndRepeat | undefined;
    set internalValue(value: MonitorDowntimeEndRepeat | undefined);
    private _onDate?;
    get onDate(): string;
    set onDate(value: string);
    resetOnDate(): void;
    get onDateInput(): string | undefined;
    private _onRepeat?;
    get onRepeat(): number;
    set onRepeat(value: number);
    resetOnRepeat(): void;
    get onRepeatInput(): number | undefined;
}
export interface MonitorDowntimeFrequencyDaysOfWeek {
    /**
    * An occurrence of the day selected within the month.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#ordinal_day_of_month MonitorDowntime#ordinal_day_of_month}
    */
    readonly ordinalDayOfMonth: string;
    /**
    * The day of the week on which the Monitor Downtime would run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#week_day MonitorDowntime#week_day}
    */
    readonly weekDay: string;
}
export declare function monitorDowntimeFrequencyDaysOfWeekToTerraform(struct?: MonitorDowntimeFrequencyDaysOfWeekOutputReference | MonitorDowntimeFrequencyDaysOfWeek): any;
export declare function monitorDowntimeFrequencyDaysOfWeekToHclTerraform(struct?: MonitorDowntimeFrequencyDaysOfWeekOutputReference | MonitorDowntimeFrequencyDaysOfWeek): any;
export declare class MonitorDowntimeFrequencyDaysOfWeekOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorDowntimeFrequencyDaysOfWeek | undefined;
    set internalValue(value: MonitorDowntimeFrequencyDaysOfWeek | undefined);
    private _ordinalDayOfMonth?;
    get ordinalDayOfMonth(): string;
    set ordinalDayOfMonth(value: string);
    get ordinalDayOfMonthInput(): string | undefined;
    private _weekDay?;
    get weekDay(): string;
    set weekDay(value: string);
    get weekDayInput(): string | undefined;
}
export interface MonitorDowntimeFrequency {
    /**
    * A numerical list of days of a month on which the Monitor Downtime is scheduled to run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#days_of_month MonitorDowntime#days_of_month}
    */
    readonly daysOfMonth?: number[];
    /**
    * days_of_week block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#days_of_week MonitorDowntime#days_of_week}
    */
    readonly daysOfWeek?: MonitorDowntimeFrequencyDaysOfWeek;
}
export declare function monitorDowntimeFrequencyToTerraform(struct?: MonitorDowntimeFrequencyOutputReference | MonitorDowntimeFrequency): any;
export declare function monitorDowntimeFrequencyToHclTerraform(struct?: MonitorDowntimeFrequencyOutputReference | MonitorDowntimeFrequency): any;
export declare class MonitorDowntimeFrequencyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorDowntimeFrequency | undefined;
    set internalValue(value: MonitorDowntimeFrequency | undefined);
    private _daysOfMonth?;
    get daysOfMonth(): number[];
    set daysOfMonth(value: number[]);
    resetDaysOfMonth(): void;
    get daysOfMonthInput(): number[] | undefined;
    private _daysOfWeek;
    get daysOfWeek(): MonitorDowntimeFrequencyDaysOfWeekOutputReference;
    putDaysOfWeek(value: MonitorDowntimeFrequencyDaysOfWeek): void;
    resetDaysOfWeek(): void;
    get daysOfWeekInput(): MonitorDowntimeFrequencyDaysOfWeek | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime newrelic_monitor_downtime}
*/
export declare class MonitorDowntime extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_monitor_downtime";
    /**
    * Generates CDKTN code for importing a MonitorDowntime resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MonitorDowntime to import
    * @param importFromId The id of the existing MonitorDowntime that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MonitorDowntime to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.3/docs/resources/monitor_downtime newrelic_monitor_downtime} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MonitorDowntimeConfig
    */
    constructor(scope: Construct, id: string, config: MonitorDowntimeConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maintenanceDays?;
    get maintenanceDays(): string[];
    set maintenanceDays(value: string[]);
    resetMaintenanceDays(): void;
    get maintenanceDaysInput(): string[] | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _monitorGuids?;
    get monitorGuids(): string[];
    set monitorGuids(value: string[]);
    resetMonitorGuids(): void;
    get monitorGuidsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    private _endRepeat;
    get endRepeat(): MonitorDowntimeEndRepeatOutputReference;
    putEndRepeat(value: MonitorDowntimeEndRepeat): void;
    resetEndRepeat(): void;
    get endRepeatInput(): MonitorDowntimeEndRepeat | undefined;
    private _frequency;
    get frequency(): MonitorDowntimeFrequencyOutputReference;
    putFrequency(value: MonitorDowntimeFrequency): void;
    resetFrequency(): void;
    get frequencyInput(): MonitorDowntimeFrequency | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
