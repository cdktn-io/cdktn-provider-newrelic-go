/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsCertCheckMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the newrelic account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#account_id SyntheticsCertCheckMonitor#account_id}
    */
    readonly accountId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#certificate_expiration SyntheticsCertCheckMonitor#certificate_expiration}
    */
    readonly certificateExpiration: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#domain SyntheticsCertCheckMonitor#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#id SyntheticsCertCheckMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The locations in which this monitor should be run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#locations_private SyntheticsCertCheckMonitor#locations_private}
    */
    readonly locationsPrivate?: string[];
    /**
    * The locations in which this monitor should be run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#locations_public SyntheticsCertCheckMonitor#locations_public}
    */
    readonly locationsPublic?: string[];
    /**
    * name of the cert check monitor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#name SyntheticsCertCheckMonitor#name}
    */
    readonly name: string;
    /**
    * The interval at which this monitor should run. Valid values are EVERY_MINUTE, EVERY_5_MINUTES, EVERY_10_MINUTES, EVERY_15_MINUTES, EVERY_30_MINUTES, EVERY_HOUR, EVERY_6_HOURS, EVERY_12_HOURS, or EVERY_DAY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#period SyntheticsCertCheckMonitor#period}
    */
    readonly period: string;
    /**
    * The runtime type that the monitor will run.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#runtime_type SyntheticsCertCheckMonitor#runtime_type}
    */
    readonly runtimeType?: string;
    /**
    * The specific semver version of the runtime type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#runtime_type_version SyntheticsCertCheckMonitor#runtime_type_version}
    */
    readonly runtimeTypeVersion?: string;
    /**
    * The monitor status (ENABLED or DISABLED).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#status SyntheticsCertCheckMonitor#status}
    */
    readonly status: string;
    /**
    * A boolean attribute to be set true by the customer, if they would like to use the unsupported legacy runtime of Synthetic Monitors by means of an exemption given until the October 22, 2024 Legacy Runtime EOL. Setting this attribute to true would allow skipping validation performed by the the New Relic Terraform Provider starting v3.43.0 to disallow using the legacy runtime with new monitors. This would, hence, allow creation of monitors in the legacy runtime until the October 22, 2024 Legacy Runtime EOL, if exempt by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#use_unsupported_legacy_runtime SyntheticsCertCheckMonitor#use_unsupported_legacy_runtime}
    */
    readonly useUnsupportedLegacyRuntime?: boolean | cdktn.IResolvable;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#tag SyntheticsCertCheckMonitor#tag}
    */
    readonly tag?: SyntheticsCertCheckMonitorTag[] | cdktn.IResolvable;
}
export interface SyntheticsCertCheckMonitorTag {
    /**
    * Name of the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#key SyntheticsCertCheckMonitor#key}
    */
    readonly key: string;
    /**
    * Values associated with the tag key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#values SyntheticsCertCheckMonitor#values}
    */
    readonly values: string[];
}
export declare function syntheticsCertCheckMonitorTagToTerraform(struct?: SyntheticsCertCheckMonitorTag | cdktn.IResolvable): any;
export declare function syntheticsCertCheckMonitorTagToHclTerraform(struct?: SyntheticsCertCheckMonitorTag | cdktn.IResolvable): any;
export declare class SyntheticsCertCheckMonitorTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsCertCheckMonitorTag | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsCertCheckMonitorTag | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class SyntheticsCertCheckMonitorTagList extends cdktn.ComplexList {
    internalValue?: SyntheticsCertCheckMonitorTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsCertCheckMonitorTagOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor newrelic_synthetics_cert_check_monitor}
*/
export declare class SyntheticsCertCheckMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_synthetics_cert_check_monitor";
    /**
    * Generates CDKTN code for importing a SyntheticsCertCheckMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsCertCheckMonitor to import
    * @param importFromId The id of the existing SyntheticsCertCheckMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsCertCheckMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/synthetics_cert_check_monitor newrelic_synthetics_cert_check_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsCertCheckMonitorConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsCertCheckMonitorConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _certificateExpiration?;
    get certificateExpiration(): number;
    set certificateExpiration(value: number);
    get certificateExpirationInput(): number | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationsPrivate?;
    get locationsPrivate(): string[];
    set locationsPrivate(value: string[]);
    resetLocationsPrivate(): void;
    get locationsPrivateInput(): string[] | undefined;
    private _locationsPublic?;
    get locationsPublic(): string[];
    set locationsPublic(value: string[]);
    resetLocationsPublic(): void;
    get locationsPublicInput(): string[] | undefined;
    get monitorId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _period?;
    get period(): string;
    set period(value: string);
    get periodInput(): string | undefined;
    get periodInMinutes(): number;
    private _runtimeType?;
    get runtimeType(): string;
    set runtimeType(value: string);
    resetRuntimeType(): void;
    get runtimeTypeInput(): string | undefined;
    private _runtimeTypeVersion?;
    get runtimeTypeVersion(): string;
    set runtimeTypeVersion(value: string);
    resetRuntimeTypeVersion(): void;
    get runtimeTypeVersionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _useUnsupportedLegacyRuntime?;
    get useUnsupportedLegacyRuntime(): boolean | cdktn.IResolvable;
    set useUnsupportedLegacyRuntime(value: boolean | cdktn.IResolvable);
    resetUseUnsupportedLegacyRuntime(): void;
    get useUnsupportedLegacyRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _tag;
    get tag(): SyntheticsCertCheckMonitorTagList;
    putTag(value: SyntheticsCertCheckMonitorTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | SyntheticsCertCheckMonitorTag[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
