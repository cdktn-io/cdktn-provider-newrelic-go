/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OneDashboardJsonConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where you want to create the dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/one_dashboard_json#account_id OneDashboardJson#account_id}
    */
    readonly accountId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/one_dashboard_json#id OneDashboardJson#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The dashboard's json.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/one_dashboard_json#json OneDashboardJson#json}
    */
    readonly json: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/one_dashboard_json#timeouts OneDashboardJson#timeouts}
    */
    readonly timeouts?: OneDashboardJsonTimeouts;
}
export interface OneDashboardJsonTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/one_dashboard_json#create OneDashboardJson#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/one_dashboard_json#update OneDashboardJson#update}
    */
    readonly update?: string;
}
export declare function oneDashboardJsonTimeoutsToTerraform(struct?: OneDashboardJsonTimeouts | cdktn.IResolvable): any;
export declare function oneDashboardJsonTimeoutsToHclTerraform(struct?: OneDashboardJsonTimeouts | cdktn.IResolvable): any;
export declare class OneDashboardJsonTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardJsonTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardJsonTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/one_dashboard_json newrelic_one_dashboard_json}
*/
export declare class OneDashboardJson extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_one_dashboard_json";
    /**
    * Generates CDKTN code for importing a OneDashboardJson resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OneDashboardJson to import
    * @param importFromId The id of the existing OneDashboardJson that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/one_dashboard_json#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OneDashboardJson to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/resources/one_dashboard_json newrelic_one_dashboard_json} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OneDashboardJsonConfig
    */
    constructor(scope: Construct, id: string, config: OneDashboardJsonConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _json?;
    get json(): string;
    set json(value: string);
    get jsonInput(): string | undefined;
    get permalink(): string;
    get updatedAt(): string;
    private _timeouts;
    get timeouts(): OneDashboardJsonTimeoutsOutputReference;
    putTimeouts(value: OneDashboardJsonTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | OneDashboardJsonTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
