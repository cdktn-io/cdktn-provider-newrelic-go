/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Authentication Domain the user being queried would belong to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/data-sources/user#authentication_domain_id DataNewrelicUser#authentication_domain_id}
    */
    readonly authenticationDomainId: string;
    /**
    * The email ID of the user to be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/data-sources/user#email_id DataNewrelicUser#email_id}
    */
    readonly emailId?: string;
    /**
    * The name of the user to be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/data-sources/user#name DataNewrelicUser#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/data-sources/user newrelic_user}
*/
export declare class DataNewrelicUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_user";
    /**
    * Generates CDKTN code for importing a DataNewrelicUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicUser to import
    * @param importFromId The id of the existing DataNewrelicUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/data-sources/user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.84.0/docs/data-sources/user newrelic_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicUserConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicUserConfig);
    private _authenticationDomainId?;
    get authenticationDomainId(): string;
    set authenticationDomainId(value: string);
    get authenticationDomainIdInput(): string | undefined;
    private _emailId?;
    get emailId(): string;
    set emailId(value: string);
    resetEmailId(): void;
    get emailIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
