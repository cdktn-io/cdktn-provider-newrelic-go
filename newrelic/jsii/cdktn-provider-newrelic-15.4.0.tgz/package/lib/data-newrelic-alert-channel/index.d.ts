/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicAlertChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * The New Relic account ID where you want to retrieve the alert channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/data-sources/alert_channel#account_id DataNewrelicAlertChannel#account_id}
    */
    readonly accountId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/data-sources/alert_channel#id DataNewrelicAlertChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the alert channel in New Relic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/data-sources/alert_channel#name DataNewrelicAlertChannel#name}
    */
    readonly name: string;
}
export interface DataNewrelicAlertChannelConfigA {
}
export declare function dataNewrelicAlertChannelConfigAToTerraform(struct?: DataNewrelicAlertChannelConfigA): any;
export declare function dataNewrelicAlertChannelConfigAToHclTerraform(struct?: DataNewrelicAlertChannelConfigA): any;
export declare class DataNewrelicAlertChannelConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataNewrelicAlertChannelConfigA | undefined;
    set internalValue(value: DataNewrelicAlertChannelConfigA | undefined);
    get apiKey(): string;
    get authPassword(): string;
    get authType(): string;
    get authUsername(): string;
    get baseUrl(): string;
    get channel(): string;
    private _headers;
    get headers(): cdktn.StringMap;
    get includeJsonAttachment(): string;
    get key(): string;
    private _payload;
    get payload(): cdktn.StringMap;
    get payloadString(): string;
    get payloadType(): string;
    get recipients(): string;
    get region(): string;
    get routeKey(): string;
    get serviceKey(): string;
    get tags(): string;
    get teams(): string;
    get url(): string;
    get userId(): string;
}
export declare class DataNewrelicAlertChannelConfigAList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataNewrelicAlertChannelConfigAOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/data-sources/alert_channel newrelic_alert_channel}
*/
export declare class DataNewrelicAlertChannel extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_alert_channel";
    /**
    * Generates CDKTN code for importing a DataNewrelicAlertChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicAlertChannel to import
    * @param importFromId The id of the existing DataNewrelicAlertChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/data-sources/alert_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicAlertChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/data-sources/alert_channel newrelic_alert_channel} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicAlertChannelConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicAlertChannelConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _config;
    get config(): DataNewrelicAlertChannelConfigAList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyIds(): number[];
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
