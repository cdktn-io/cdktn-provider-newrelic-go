/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NrqlDropRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account with the NRQL drop rule will be put.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule#account_id NrqlDropRule#account_id}
    */
    readonly accountId?: number;
    /**
    * The drop rule action (drop_data, drop_attributes, or drop_attributes_from_metric_aggregates).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule#action NrqlDropRule#action}
    */
    readonly action: string;
    /**
    * Provides additional information about the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule#description NrqlDropRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule#id NrqlDropRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Explains which data to apply the drop rule to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule#nrql NrqlDropRule#nrql}
    */
    readonly nrql: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule#timeouts NrqlDropRule#timeouts}
    */
    readonly timeouts?: NrqlDropRuleTimeouts;
}
export interface NrqlDropRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule#read NrqlDropRule#read}
    */
    readonly read?: string;
}
export declare function nrqlDropRuleTimeoutsToTerraform(struct?: NrqlDropRuleTimeouts | cdktn.IResolvable): any;
export declare function nrqlDropRuleTimeoutsToHclTerraform(struct?: NrqlDropRuleTimeouts | cdktn.IResolvable): any;
export declare class NrqlDropRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NrqlDropRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: NrqlDropRuleTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule newrelic_nrql_drop_rule}
*/
export declare class NrqlDropRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_nrql_drop_rule";
    /**
    * Generates CDKTN code for importing a NrqlDropRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NrqlDropRule to import
    * @param importFromId The id of the existing NrqlDropRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NrqlDropRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/nrql_drop_rule newrelic_nrql_drop_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NrqlDropRuleConfig
    */
    constructor(scope: Construct, id: string, config: NrqlDropRuleConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _nrql?;
    get nrql(): string;
    set nrql(value: string);
    get nrqlInput(): string | undefined;
    get pipelineCloudRuleEntityId(): string;
    get ruleId(): string;
    private _timeouts;
    get timeouts(): NrqlDropRuleTimeoutsOutputReference;
    putTimeouts(value: NrqlDropRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | NrqlDropRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
