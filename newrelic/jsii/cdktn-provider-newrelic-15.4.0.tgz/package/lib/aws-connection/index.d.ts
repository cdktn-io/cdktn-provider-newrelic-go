/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account ID where the AWS connection will be created. Used when scope_type is ACCOUNT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#account_id AwsConnection#account_id}
    */
    readonly accountId?: number;
    /**
    * The description of the AWS connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#description AwsConnection#description}
    */
    readonly description?: string;
    /**
    * Flag to indicate if the connection is enabled. True by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#enabled AwsConnection#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Optional field representing an identifier managed by the consumer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#external_id AwsConnection#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#id AwsConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the AWS connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#name AwsConnection#name}
    */
    readonly name: string;
    /**
    * Default region for this connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#region AwsConnection#region}
    */
    readonly region?: string;
    /**
    * The scope ID (account ID or organization ID) for the AWS connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#scope_id AwsConnection#scope_id}
    */
    readonly scopeId?: string;
    /**
    * The scope type for the AWS connection. Valid values are ACCOUNT and ORGANIZATION.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#scope_type AwsConnection#scope_type}
    */
    readonly scopeType?: string;
    /**
    * credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#credential AwsConnection#credential}
    */
    readonly credential: AwsConnectionCredential;
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#settings AwsConnection#settings}
    */
    readonly settings?: AwsConnectionSettings[] | cdktn.IResolvable;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#tag AwsConnection#tag}
    */
    readonly tag?: AwsConnectionTag[] | cdktn.IResolvable;
}
export interface AwsConnectionCredentialAssumeRole {
    /**
    * External ID supplied by New Relic during AssumeRole.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#external_id AwsConnection#external_id}
    */
    readonly externalId?: string;
    /**
    * ARN of the IAM role New Relic should assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#role_arn AwsConnection#role_arn}
    */
    readonly roleArn: string;
}
export declare function awsConnectionCredentialAssumeRoleToTerraform(struct?: AwsConnectionCredentialAssumeRoleOutputReference | AwsConnectionCredentialAssumeRole): any;
export declare function awsConnectionCredentialAssumeRoleToHclTerraform(struct?: AwsConnectionCredentialAssumeRoleOutputReference | AwsConnectionCredentialAssumeRole): any;
export declare class AwsConnectionCredentialAssumeRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AwsConnectionCredentialAssumeRole | undefined;
    set internalValue(value: AwsConnectionCredentialAssumeRole | undefined);
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
}
export interface AwsConnectionCredential {
    /**
    * assume_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#assume_role AwsConnection#assume_role}
    */
    readonly assumeRole: AwsConnectionCredentialAssumeRole;
}
export declare function awsConnectionCredentialToTerraform(struct?: AwsConnectionCredentialOutputReference | AwsConnectionCredential): any;
export declare function awsConnectionCredentialToHclTerraform(struct?: AwsConnectionCredentialOutputReference | AwsConnectionCredential): any;
export declare class AwsConnectionCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AwsConnectionCredential | undefined;
    set internalValue(value: AwsConnectionCredential | undefined);
    private _assumeRole;
    get assumeRole(): AwsConnectionCredentialAssumeRoleOutputReference;
    putAssumeRole(value: AwsConnectionCredentialAssumeRole): void;
    get assumeRoleInput(): AwsConnectionCredentialAssumeRole | undefined;
}
export interface AwsConnectionSettings {
    /**
    * The key or name of the setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#key AwsConnection#key}
    */
    readonly key: string;
    /**
    * The value of the setting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#value AwsConnection#value}
    */
    readonly value: string;
}
export declare function awsConnectionSettingsToTerraform(struct?: AwsConnectionSettings | cdktn.IResolvable): any;
export declare function awsConnectionSettingsToHclTerraform(struct?: AwsConnectionSettings | cdktn.IResolvable): any;
export declare class AwsConnectionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AwsConnectionSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AwsConnectionSettings | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class AwsConnectionSettingsList extends cdktn.ComplexList {
    internalValue?: AwsConnectionSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AwsConnectionSettingsOutputReference;
}
export interface AwsConnectionTag {
    /**
    * The tag key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#key AwsConnection#key}
    */
    readonly key: string;
    /**
    * The tag values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#values AwsConnection#values}
    */
    readonly values: string[];
}
export declare function awsConnectionTagToTerraform(struct?: AwsConnectionTag | cdktn.IResolvable): any;
export declare function awsConnectionTagToHclTerraform(struct?: AwsConnectionTag | cdktn.IResolvable): any;
export declare class AwsConnectionTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AwsConnectionTag | cdktn.IResolvable | undefined;
    set internalValue(value: AwsConnectionTag | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class AwsConnectionTagList extends cdktn.ComplexList {
    internalValue?: AwsConnectionTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AwsConnectionTagOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection newrelic_aws_connection}
*/
export declare class AwsConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_aws_connection";
    /**
    * Generates CDKTN code for importing a AwsConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConnection to import
    * @param importFromId The id of the existing AwsConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.94.0/docs/resources/aws_connection newrelic_aws_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConnectionConfig
    */
    constructor(scope: Construct, id: string, config: AwsConnectionConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scopeId?;
    get scopeId(): string;
    set scopeId(value: string);
    resetScopeId(): void;
    get scopeIdInput(): string | undefined;
    private _scopeType?;
    get scopeType(): string;
    set scopeType(value: string);
    resetScopeType(): void;
    get scopeTypeInput(): string | undefined;
    private _credential;
    get credential(): AwsConnectionCredentialOutputReference;
    putCredential(value: AwsConnectionCredential): void;
    get credentialInput(): AwsConnectionCredential | undefined;
    private _settings;
    get settings(): AwsConnectionSettingsList;
    putSettings(value: AwsConnectionSettings[] | cdktn.IResolvable): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | AwsConnectionSettings[] | undefined;
    private _tag;
    get tag(): AwsConnectionTagList;
    putTag(value: AwsConnectionTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | AwsConnectionTag[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
