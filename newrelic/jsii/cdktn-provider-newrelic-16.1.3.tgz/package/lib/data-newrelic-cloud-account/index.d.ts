/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataNewrelicCloudAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the New Relic account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/data-sources/cloud_account#account_id DataNewrelicCloudAccount#account_id}
    */
    readonly accountId?: number;
    /**
    * The cloud provider of the account, e.g. aws, gcp, azure
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/data-sources/cloud_account#cloud_provider DataNewrelicCloudAccount#cloud_provider}
    */
    readonly cloudProvider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/data-sources/cloud_account#id DataNewrelicCloudAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Set to true when looking up a GCP Dimensional Metrics linked account (cloud_provider must be "gcp").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/data-sources/cloud_account#is_dimensional_metrics DataNewrelicCloudAccount#is_dimensional_metrics}
    */
    readonly isDimensionalMetrics?: boolean | cdktn.IResolvable;
    /**
    * The name of the cloud account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/data-sources/cloud_account#name DataNewrelicCloudAccount#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/data-sources/cloud_account newrelic_cloud_account}
*/
export declare class DataNewrelicCloudAccount extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "newrelic_cloud_account";
    /**
    * Generates CDKTN code for importing a DataNewrelicCloudAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataNewrelicCloudAccount to import
    * @param importFromId The id of the existing DataNewrelicCloudAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/data-sources/cloud_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataNewrelicCloudAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/data-sources/cloud_account newrelic_cloud_account} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataNewrelicCloudAccountConfig
    */
    constructor(scope: Construct, id: string, config: DataNewrelicCloudAccountConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    private _cloudProvider?;
    get cloudProvider(): string;
    set cloudProvider(value: string);
    get cloudProviderInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isDimensionalMetrics?;
    get isDimensionalMetrics(): boolean | cdktn.IResolvable;
    set isDimensionalMetrics(value: boolean | cdktn.IResolvable);
    resetIsDimensionalMetrics(): void;
    get isDimensionalMetricsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
