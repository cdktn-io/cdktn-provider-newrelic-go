/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { OneDashboardPageWidgetLineChartStyles, OneDashboardPageWidgetLineChartStylesOutputReference, OneDashboardPageWidgetLineColors, OneDashboardPageWidgetLineColorsList, OneDashboardPageWidgetLineDataFormat, OneDashboardPageWidgetLineDataFormatList, OneDashboardPageWidgetLineInitialSorting, OneDashboardPageWidgetLineInitialSortingOutputReference, OneDashboardPageWidgetLineNrqlQuery, OneDashboardPageWidgetLineNrqlQueryList, OneDashboardPageWidgetArea, OneDashboardPageWidgetAreaList, OneDashboardPageWidgetBar, OneDashboardPageWidgetBarList, OneDashboardPageWidgetBillboard, OneDashboardPageWidgetBillboardList, OneDashboardPageWidgetBullet, OneDashboardPageWidgetBulletList, OneDashboardPageWidgetFunnel, OneDashboardPageWidgetFunnelList, OneDashboardPageWidgetHeatmap, OneDashboardPageWidgetHeatmapList, OneDashboardPageWidgetHistogram, OneDashboardPageWidgetHistogramList, OneDashboardPageWidgetJson, OneDashboardPageWidgetJsonList } from './structs0';
export interface OneDashboardPageWidgetLineNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetLineNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetLineNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetLineNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLineNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLineNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLineNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLineNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetLineNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetLineNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLineNullValuesToTerraform(struct?: OneDashboardPageWidgetLineNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineNullValuesToHclTerraform(struct?: OneDashboardPageWidgetLineNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLineNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLineNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetLineNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetLineNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetLineNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetLineNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLineNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineNullValuesOutputReference;
}
export interface OneDashboardPageWidgetLineThreshold {
    /**
    * The number from which the range starts in thresholds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#from OneDashboard#from}
    */
    readonly from?: string;
    /**
    * Name of the threshold created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name?: string;
    /**
    * Severity of the threshold, which would reflect in the widget, in the range of the threshold specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#severity OneDashboard#severity}
    */
    readonly severity?: string;
    /**
    * The number at which the range ends in thresholds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#to OneDashboard#to}
    */
    readonly to?: string;
}
export declare function oneDashboardPageWidgetLineThresholdToTerraform(struct?: OneDashboardPageWidgetLineThreshold | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineThresholdToHclTerraform(struct?: OneDashboardPageWidgetLineThreshold | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLineThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLineThreshold | cdktn.IResolvable | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    private _to?;
    get to(): string;
    set to(value: string);
    resetTo(): void;
    get toInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLineThresholdList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLineThreshold[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineThresholdOutputReference;
}
export interface OneDashboardPageWidgetLineTooltip {
    /**
    * Tooltip display mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#mode OneDashboard#mode}
    */
    readonly mode: string;
}
export declare function oneDashboardPageWidgetLineTooltipToTerraform(struct?: OneDashboardPageWidgetLineTooltipOutputReference | OneDashboardPageWidgetLineTooltip): any;
export declare function oneDashboardPageWidgetLineTooltipToHclTerraform(struct?: OneDashboardPageWidgetLineTooltipOutputReference | OneDashboardPageWidgetLineTooltip): any;
export declare class OneDashboardPageWidgetLineTooltipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetLineTooltip | undefined;
    set internalValue(value: OneDashboardPageWidgetLineTooltip | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export interface OneDashboardPageWidgetLineUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetLineUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetLineUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetLineUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLineUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLineUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLineUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLineUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetLineUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetLineUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLineUnitsToTerraform(struct?: OneDashboardPageWidgetLineUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineUnitsToHclTerraform(struct?: OneDashboardPageWidgetLineUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLineUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLineUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetLineUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetLineUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetLineUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetLineUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLineUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineUnitsOutputReference;
}
export interface OneDashboardPageWidgetLineYAxisRight {
    /**
    * Minimum value of the range to be specified with the Y-Axis on the right of the line widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_right_max OneDashboard#y_axis_right_max}
    */
    readonly yAxisRightMax?: number;
    /**
    * Minimum value of the range to be specified with the Y-Axis on the right of the line widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_right_min OneDashboard#y_axis_right_min}
    */
    readonly yAxisRightMin?: number;
    /**
    * A set of series that helps specify the Y-Axis on the right of the line widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_right_series OneDashboard#y_axis_right_series}
    */
    readonly yAxisRightSeries?: string[];
    /**
    * An attribute that helps specify the Y-Axis on the right of the line widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_right_zero OneDashboard#y_axis_right_zero}
    */
    readonly yAxisRightZero?: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLineYAxisRightToTerraform(struct?: OneDashboardPageWidgetLineYAxisRightOutputReference | OneDashboardPageWidgetLineYAxisRight): any;
export declare function oneDashboardPageWidgetLineYAxisRightToHclTerraform(struct?: OneDashboardPageWidgetLineYAxisRightOutputReference | OneDashboardPageWidgetLineYAxisRight): any;
export declare class OneDashboardPageWidgetLineYAxisRightOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetLineYAxisRight | undefined;
    set internalValue(value: OneDashboardPageWidgetLineYAxisRight | undefined);
    private _yAxisRightMax?;
    get yAxisRightMax(): number;
    set yAxisRightMax(value: number);
    resetYAxisRightMax(): void;
    get yAxisRightMaxInput(): number | undefined;
    private _yAxisRightMin?;
    get yAxisRightMin(): number;
    set yAxisRightMin(value: number);
    resetYAxisRightMin(): void;
    get yAxisRightMinInput(): number | undefined;
    private _yAxisRightSeries?;
    get yAxisRightSeries(): string[];
    set yAxisRightSeries(value: string[]);
    resetYAxisRightSeries(): void;
    get yAxisRightSeriesInput(): string[] | undefined;
    private _yAxisRightZero?;
    get yAxisRightZero(): boolean | cdktn.IResolvable;
    set yAxisRightZero(value: boolean | cdktn.IResolvable);
    resetYAxisRightZero(): void;
    get yAxisRightZeroInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetLine {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Specified if the label should be visible in the graph created when specified with thresholds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#is_label_visible OneDashboard#is_label_visible}
    */
    readonly isLabelVisible?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * Specifies if the values on the graph to be rendered need to be fit to scale, or printed within the specified range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_zero OneDashboard#y_axis_left_zero}
    */
    readonly yAxisLeftZero?: boolean | cdktn.IResolvable;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetLineChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetLineColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetLineDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetLineInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetLineNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetLineNullValues[] | cdktn.IResolvable;
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#threshold OneDashboard#threshold}
    */
    readonly threshold?: OneDashboardPageWidgetLineThreshold[] | cdktn.IResolvable;
    /**
    * tooltip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#tooltip OneDashboard#tooltip}
    */
    readonly tooltip?: OneDashboardPageWidgetLineTooltip;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetLineUnits[] | cdktn.IResolvable;
    /**
    * y_axis_right block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_right OneDashboard#y_axis_right}
    */
    readonly yAxisRight?: OneDashboardPageWidgetLineYAxisRight;
}
export declare function oneDashboardPageWidgetLineToTerraform(struct?: OneDashboardPageWidgetLine | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLineToHclTerraform(struct?: OneDashboardPageWidgetLine | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLine | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLine | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _isLabelVisible?;
    get isLabelVisible(): boolean | cdktn.IResolvable;
    set isLabelVisible(value: boolean | cdktn.IResolvable);
    resetIsLabelVisible(): void;
    get isLabelVisibleInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _yAxisLeftZero?;
    get yAxisLeftZero(): boolean | cdktn.IResolvable;
    set yAxisLeftZero(value: boolean | cdktn.IResolvable);
    resetYAxisLeftZero(): void;
    get yAxisLeftZeroInput(): boolean | cdktn.IResolvable | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetLineChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetLineChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetLineChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetLineColorsList;
    putColors(value: OneDashboardPageWidgetLineColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetLineColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetLineDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetLineDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetLineDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetLineInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetLineInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetLineInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetLineNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetLineNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetLineNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetLineNullValuesList;
    putNullValues(value: OneDashboardPageWidgetLineNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetLineNullValues[] | undefined;
    private _threshold;
    get threshold(): OneDashboardPageWidgetLineThresholdList;
    putThreshold(value: OneDashboardPageWidgetLineThreshold[] | cdktn.IResolvable): void;
    resetThreshold(): void;
    get thresholdInput(): cdktn.IResolvable | OneDashboardPageWidgetLineThreshold[] | undefined;
    private _tooltip;
    get tooltip(): OneDashboardPageWidgetLineTooltipOutputReference;
    putTooltip(value: OneDashboardPageWidgetLineTooltip): void;
    resetTooltip(): void;
    get tooltipInput(): OneDashboardPageWidgetLineTooltip | undefined;
    private _units;
    get units(): OneDashboardPageWidgetLineUnitsList;
    putUnits(value: OneDashboardPageWidgetLineUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetLineUnits[] | undefined;
    private _yAxisRight;
    get yAxisRight(): OneDashboardPageWidgetLineYAxisRightOutputReference;
    putYAxisRight(value: OneDashboardPageWidgetLineYAxisRight): void;
    resetYAxisRight(): void;
    get yAxisRightInput(): OneDashboardPageWidgetLineYAxisRight | undefined;
}
export declare class OneDashboardPageWidgetLineList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLine[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLineOutputReference;
}
export interface OneDashboardPageWidgetLogTableChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLogTableChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetLogTableChartStylesGradientOutputReference | OneDashboardPageWidgetLogTableChartStylesGradient): any;
export declare function oneDashboardPageWidgetLogTableChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetLogTableChartStylesGradientOutputReference | OneDashboardPageWidgetLogTableChartStylesGradient): any;
export declare class OneDashboardPageWidgetLogTableChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetLogTableChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetLogTableChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetLogTableChartStylesGradient;
}
export declare function oneDashboardPageWidgetLogTableChartStylesToTerraform(struct?: OneDashboardPageWidgetLogTableChartStylesOutputReference | OneDashboardPageWidgetLogTableChartStyles): any;
export declare function oneDashboardPageWidgetLogTableChartStylesToHclTerraform(struct?: OneDashboardPageWidgetLogTableChartStylesOutputReference | OneDashboardPageWidgetLogTableChartStyles): any;
export declare class OneDashboardPageWidgetLogTableChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetLogTableChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetLogTableChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetLogTableChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetLogTableChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetLogTableColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetLogTableColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetLogTableColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLogTableColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetLogTableColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLogTableColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLogTableColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLogTableColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLogTableColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLogTableColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetLogTableColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetLogTableColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLogTableColorsToTerraform(struct?: OneDashboardPageWidgetLogTableColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLogTableColorsToHclTerraform(struct?: OneDashboardPageWidgetLogTableColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLogTableColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLogTableColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetLogTableColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetLogTableColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetLogTableColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetLogTableColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLogTableColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLogTableColorsOutputReference;
}
export interface OneDashboardPageWidgetLogTableDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetLogTableDataFormatToTerraform(struct?: OneDashboardPageWidgetLogTableDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLogTableDataFormatToHclTerraform(struct?: OneDashboardPageWidgetLogTableDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLogTableDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLogTableDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLogTableDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLogTableDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLogTableDataFormatOutputReference;
}
export interface OneDashboardPageWidgetLogTableInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetLogTableInitialSortingToTerraform(struct?: OneDashboardPageWidgetLogTableInitialSortingOutputReference | OneDashboardPageWidgetLogTableInitialSorting): any;
export declare function oneDashboardPageWidgetLogTableInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetLogTableInitialSortingOutputReference | OneDashboardPageWidgetLogTableInitialSorting): any;
export declare class OneDashboardPageWidgetLogTableInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetLogTableInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetLogTableNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetLogTableNrqlQueryToTerraform(struct?: OneDashboardPageWidgetLogTableNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLogTableNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetLogTableNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLogTableNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLogTableNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLogTableNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLogTableNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLogTableNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetLogTableNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetLogTableNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetLogTableNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLogTableNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetLogTableNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLogTableNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLogTableNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLogTableNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLogTableNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLogTableNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetLogTableNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetLogTableNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLogTableNullValuesToTerraform(struct?: OneDashboardPageWidgetLogTableNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLogTableNullValuesToHclTerraform(struct?: OneDashboardPageWidgetLogTableNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLogTableNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLogTableNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetLogTableNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetLogTableNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetLogTableNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetLogTableNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLogTableNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLogTableNullValuesOutputReference;
}
export interface OneDashboardPageWidgetLogTableUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetLogTableUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetLogTableUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLogTableUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetLogTableUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLogTableUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLogTableUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetLogTableUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLogTableUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLogTableUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetLogTableUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetLogTableUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLogTableUnitsToTerraform(struct?: OneDashboardPageWidgetLogTableUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLogTableUnitsToHclTerraform(struct?: OneDashboardPageWidgetLogTableUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLogTableUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLogTableUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTableUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetLogTableUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetLogTableUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetLogTableUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetLogTableUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLogTableUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLogTableUnitsOutputReference;
}
export interface OneDashboardPageWidgetLogTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetLogTableChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetLogTableColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetLogTableDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetLogTableInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetLogTableNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetLogTableNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetLogTableUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetLogTableToTerraform(struct?: OneDashboardPageWidgetLogTable | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetLogTableToHclTerraform(struct?: OneDashboardPageWidgetLogTable | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetLogTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetLogTable | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetLogTable | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetLogTableChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetLogTableChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetLogTableChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetLogTableColorsList;
    putColors(value: OneDashboardPageWidgetLogTableColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetLogTableColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetLogTableDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetLogTableDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetLogTableDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetLogTableInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetLogTableInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetLogTableInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetLogTableNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetLogTableNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetLogTableNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetLogTableNullValuesList;
    putNullValues(value: OneDashboardPageWidgetLogTableNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetLogTableNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetLogTableUnitsList;
    putUnits(value: OneDashboardPageWidgetLogTableUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetLogTableUnits[] | undefined;
}
export declare class OneDashboardPageWidgetLogTableList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetLogTable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetLogTableOutputReference;
}
export interface OneDashboardPageWidgetMarkdownChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetMarkdownChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetMarkdownChartStylesGradientOutputReference | OneDashboardPageWidgetMarkdownChartStylesGradient): any;
export declare function oneDashboardPageWidgetMarkdownChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetMarkdownChartStylesGradientOutputReference | OneDashboardPageWidgetMarkdownChartStylesGradient): any;
export declare class OneDashboardPageWidgetMarkdownChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetMarkdownChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetMarkdownChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetMarkdownChartStylesGradient;
}
export declare function oneDashboardPageWidgetMarkdownChartStylesToTerraform(struct?: OneDashboardPageWidgetMarkdownChartStylesOutputReference | OneDashboardPageWidgetMarkdownChartStyles): any;
export declare function oneDashboardPageWidgetMarkdownChartStylesToHclTerraform(struct?: OneDashboardPageWidgetMarkdownChartStylesOutputReference | OneDashboardPageWidgetMarkdownChartStyles): any;
export declare class OneDashboardPageWidgetMarkdownChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetMarkdownChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetMarkdownChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetMarkdownChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetMarkdownChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetMarkdownColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetMarkdownColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetMarkdownColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetMarkdownColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetMarkdownColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetMarkdownColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetMarkdownColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetMarkdownColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetMarkdownColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetMarkdownColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetMarkdownColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetMarkdownColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetMarkdownColorsToTerraform(struct?: OneDashboardPageWidgetMarkdownColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetMarkdownColorsToHclTerraform(struct?: OneDashboardPageWidgetMarkdownColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetMarkdownColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetMarkdownColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetMarkdownColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetMarkdownColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetMarkdownColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetMarkdownColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetMarkdownColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetMarkdownColorsOutputReference;
}
export interface OneDashboardPageWidgetMarkdownDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetMarkdownDataFormatToTerraform(struct?: OneDashboardPageWidgetMarkdownDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetMarkdownDataFormatToHclTerraform(struct?: OneDashboardPageWidgetMarkdownDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetMarkdownDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetMarkdownDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetMarkdownDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetMarkdownDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetMarkdownDataFormatOutputReference;
}
export interface OneDashboardPageWidgetMarkdownInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetMarkdownInitialSortingToTerraform(struct?: OneDashboardPageWidgetMarkdownInitialSortingOutputReference | OneDashboardPageWidgetMarkdownInitialSorting): any;
export declare function oneDashboardPageWidgetMarkdownInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetMarkdownInitialSortingOutputReference | OneDashboardPageWidgetMarkdownInitialSorting): any;
export declare class OneDashboardPageWidgetMarkdownInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetMarkdownInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetMarkdownNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetMarkdownNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetMarkdownNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetMarkdownNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetMarkdownNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetMarkdownNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetMarkdownNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetMarkdownNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetMarkdownNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetMarkdownNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetMarkdownNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetMarkdownNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetMarkdownNullValuesToTerraform(struct?: OneDashboardPageWidgetMarkdownNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetMarkdownNullValuesToHclTerraform(struct?: OneDashboardPageWidgetMarkdownNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetMarkdownNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetMarkdownNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetMarkdownNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetMarkdownNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetMarkdownNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetMarkdownNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetMarkdownNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetMarkdownNullValuesOutputReference;
}
export interface OneDashboardPageWidgetMarkdownUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetMarkdownUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetMarkdownUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetMarkdownUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetMarkdownUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetMarkdownUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetMarkdownUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetMarkdownUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetMarkdownUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetMarkdownUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetMarkdownUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetMarkdownUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetMarkdownUnitsToTerraform(struct?: OneDashboardPageWidgetMarkdownUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetMarkdownUnitsToHclTerraform(struct?: OneDashboardPageWidgetMarkdownUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetMarkdownUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetMarkdownUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdownUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetMarkdownUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetMarkdownUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetMarkdownUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetMarkdownUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetMarkdownUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetMarkdownUnitsOutputReference;
}
export interface OneDashboardPageWidgetMarkdown {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#text OneDashboard#text}
    */
    readonly text: string;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetMarkdownChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetMarkdownColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetMarkdownDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetMarkdownInitialSorting;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetMarkdownNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetMarkdownUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetMarkdownToTerraform(struct?: OneDashboardPageWidgetMarkdown | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetMarkdownToHclTerraform(struct?: OneDashboardPageWidgetMarkdown | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetMarkdownOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetMarkdown | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetMarkdown | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    get textInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetMarkdownChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetMarkdownChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetMarkdownChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetMarkdownColorsList;
    putColors(value: OneDashboardPageWidgetMarkdownColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetMarkdownColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetMarkdownDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetMarkdownDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetMarkdownDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetMarkdownInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetMarkdownInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetMarkdownInitialSorting | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetMarkdownNullValuesList;
    putNullValues(value: OneDashboardPageWidgetMarkdownNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetMarkdownNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetMarkdownUnitsList;
    putUnits(value: OneDashboardPageWidgetMarkdownUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetMarkdownUnits[] | undefined;
}
export declare class OneDashboardPageWidgetMarkdownList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetMarkdown[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetMarkdownOutputReference;
}
export interface OneDashboardPageWidgetPieChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetPieChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetPieChartStylesGradientOutputReference | OneDashboardPageWidgetPieChartStylesGradient): any;
export declare function oneDashboardPageWidgetPieChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetPieChartStylesGradientOutputReference | OneDashboardPageWidgetPieChartStylesGradient): any;
export declare class OneDashboardPageWidgetPieChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetPieChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetPieChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetPieChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetPieChartStylesGradient;
}
export declare function oneDashboardPageWidgetPieChartStylesToTerraform(struct?: OneDashboardPageWidgetPieChartStylesOutputReference | OneDashboardPageWidgetPieChartStyles): any;
export declare function oneDashboardPageWidgetPieChartStylesToHclTerraform(struct?: OneDashboardPageWidgetPieChartStylesOutputReference | OneDashboardPageWidgetPieChartStyles): any;
export declare class OneDashboardPageWidgetPieChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetPieChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetPieChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetPieChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetPieChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetPieChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetPieColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetPieColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetPieColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetPieColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetPieColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetPieColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetPieColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetPieColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetPieColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetPieColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetPieColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetPieColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetPieColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetPieColorsToTerraform(struct?: OneDashboardPageWidgetPieColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetPieColorsToHclTerraform(struct?: OneDashboardPageWidgetPieColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetPieColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetPieColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetPieColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetPieColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetPieColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetPieColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetPieColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetPieColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetPieColorsOutputReference;
}
export interface OneDashboardPageWidgetPieDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetPieDataFormatToTerraform(struct?: OneDashboardPageWidgetPieDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetPieDataFormatToHclTerraform(struct?: OneDashboardPageWidgetPieDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetPieDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetPieDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetPieDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetPieDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetPieDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetPieDataFormatOutputReference;
}
export interface OneDashboardPageWidgetPieInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetPieInitialSortingToTerraform(struct?: OneDashboardPageWidgetPieInitialSortingOutputReference | OneDashboardPageWidgetPieInitialSorting): any;
export declare function oneDashboardPageWidgetPieInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetPieInitialSortingOutputReference | OneDashboardPageWidgetPieInitialSorting): any;
export declare class OneDashboardPageWidgetPieInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetPieInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetPieInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetPieNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetPieNrqlQueryToTerraform(struct?: OneDashboardPageWidgetPieNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetPieNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetPieNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetPieNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetPieNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetPieNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetPieNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetPieNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetPieNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetPieNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetPieNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetPieNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetPieNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetPieNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetPieNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetPieNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetPieNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetPieNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetPieNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetPieNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetPieNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetPieNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetPieNullValuesToTerraform(struct?: OneDashboardPageWidgetPieNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetPieNullValuesToHclTerraform(struct?: OneDashboardPageWidgetPieNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetPieNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetPieNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetPieNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetPieNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetPieNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetPieNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetPieNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetPieNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetPieNullValuesOutputReference;
}
export interface OneDashboardPageWidgetPieUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetPieUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetPieUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetPieUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetPieUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetPieUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetPieUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetPieUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetPieUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetPieUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetPieUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetPieUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetPieUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetPieUnitsToTerraform(struct?: OneDashboardPageWidgetPieUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetPieUnitsToHclTerraform(struct?: OneDashboardPageWidgetPieUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetPieUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetPieUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetPieUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetPieUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetPieUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetPieUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetPieUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetPieUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetPieUnitsOutputReference;
}
export interface OneDashboardPageWidgetPie {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Use this item to filter the current dashboard
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#filter_current_dashboard OneDashboard#filter_current_dashboard}
    */
    readonly filterCurrentDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Related entities. Currently only supports Dashboard entities, but may allow other cases in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#linked_entity_guids OneDashboard#linked_entity_guids}
    */
    readonly linkedEntityGuids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetPieChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetPieColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetPieDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetPieInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetPieNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetPieNullValues[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetPieUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetPieToTerraform(struct?: OneDashboardPageWidgetPie | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetPieToHclTerraform(struct?: OneDashboardPageWidgetPie | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetPieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetPie | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetPie | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _filterCurrentDashboard?;
    get filterCurrentDashboard(): boolean | cdktn.IResolvable;
    set filterCurrentDashboard(value: boolean | cdktn.IResolvable);
    resetFilterCurrentDashboard(): void;
    get filterCurrentDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _linkedEntityGuids?;
    get linkedEntityGuids(): string[];
    set linkedEntityGuids(value: string[]);
    resetLinkedEntityGuids(): void;
    get linkedEntityGuidsInput(): string[] | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetPieChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetPieChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetPieChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetPieColorsList;
    putColors(value: OneDashboardPageWidgetPieColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetPieColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetPieDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetPieDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetPieDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetPieInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetPieInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetPieInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetPieNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetPieNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetPieNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetPieNullValuesList;
    putNullValues(value: OneDashboardPageWidgetPieNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetPieNullValues[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetPieUnitsList;
    putUnits(value: OneDashboardPageWidgetPieUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetPieUnits[] | undefined;
}
export declare class OneDashboardPageWidgetPieList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetPie[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetPieOutputReference;
}
export interface OneDashboardPageWidgetStackedBarChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetStackedBarChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetStackedBarChartStylesGradientOutputReference | OneDashboardPageWidgetStackedBarChartStylesGradient): any;
export declare function oneDashboardPageWidgetStackedBarChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetStackedBarChartStylesGradientOutputReference | OneDashboardPageWidgetStackedBarChartStylesGradient): any;
export declare class OneDashboardPageWidgetStackedBarChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetStackedBarChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetStackedBarChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetStackedBarChartStylesGradient;
}
export declare function oneDashboardPageWidgetStackedBarChartStylesToTerraform(struct?: OneDashboardPageWidgetStackedBarChartStylesOutputReference | OneDashboardPageWidgetStackedBarChartStyles): any;
export declare function oneDashboardPageWidgetStackedBarChartStylesToHclTerraform(struct?: OneDashboardPageWidgetStackedBarChartStylesOutputReference | OneDashboardPageWidgetStackedBarChartStyles): any;
export declare class OneDashboardPageWidgetStackedBarChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetStackedBarChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetStackedBarChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetStackedBarChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetStackedBarChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetStackedBarColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetStackedBarColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetStackedBarColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetStackedBarColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetStackedBarColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetStackedBarColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetStackedBarColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetStackedBarColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetStackedBarColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetStackedBarColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetStackedBarColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetStackedBarColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetStackedBarColorsToTerraform(struct?: OneDashboardPageWidgetStackedBarColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetStackedBarColorsToHclTerraform(struct?: OneDashboardPageWidgetStackedBarColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetStackedBarColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetStackedBarColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetStackedBarColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetStackedBarColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetStackedBarColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetStackedBarColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetStackedBarColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetStackedBarColorsOutputReference;
}
export interface OneDashboardPageWidgetStackedBarDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetStackedBarDataFormatToTerraform(struct?: OneDashboardPageWidgetStackedBarDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetStackedBarDataFormatToHclTerraform(struct?: OneDashboardPageWidgetStackedBarDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetStackedBarDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetStackedBarDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetStackedBarDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetStackedBarDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetStackedBarDataFormatOutputReference;
}
export interface OneDashboardPageWidgetStackedBarInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetStackedBarInitialSortingToTerraform(struct?: OneDashboardPageWidgetStackedBarInitialSortingOutputReference | OneDashboardPageWidgetStackedBarInitialSorting): any;
export declare function oneDashboardPageWidgetStackedBarInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetStackedBarInitialSortingOutputReference | OneDashboardPageWidgetStackedBarInitialSorting): any;
export declare class OneDashboardPageWidgetStackedBarInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetStackedBarInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetStackedBarNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetStackedBarNrqlQueryToTerraform(struct?: OneDashboardPageWidgetStackedBarNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetStackedBarNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetStackedBarNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetStackedBarNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetStackedBarNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetStackedBarNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetStackedBarNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetStackedBarNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetStackedBarNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetStackedBarNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetStackedBarNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetStackedBarNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetStackedBarNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetStackedBarNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetStackedBarNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetStackedBarNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetStackedBarNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetStackedBarNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetStackedBarNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetStackedBarNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetStackedBarNullValuesToTerraform(struct?: OneDashboardPageWidgetStackedBarNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetStackedBarNullValuesToHclTerraform(struct?: OneDashboardPageWidgetStackedBarNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetStackedBarNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetStackedBarNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetStackedBarNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetStackedBarNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetStackedBarNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetStackedBarNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetStackedBarNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetStackedBarNullValuesOutputReference;
}
export interface OneDashboardPageWidgetStackedBarTooltip {
    /**
    * Tooltip display mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#mode OneDashboard#mode}
    */
    readonly mode: string;
}
export declare function oneDashboardPageWidgetStackedBarTooltipToTerraform(struct?: OneDashboardPageWidgetStackedBarTooltipOutputReference | OneDashboardPageWidgetStackedBarTooltip): any;
export declare function oneDashboardPageWidgetStackedBarTooltipToHclTerraform(struct?: OneDashboardPageWidgetStackedBarTooltipOutputReference | OneDashboardPageWidgetStackedBarTooltip): any;
export declare class OneDashboardPageWidgetStackedBarTooltipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetStackedBarTooltip | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarTooltip | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export interface OneDashboardPageWidgetStackedBarUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetStackedBarUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetStackedBarUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetStackedBarUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetStackedBarUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetStackedBarUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetStackedBarUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetStackedBarUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetStackedBarUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetStackedBarUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetStackedBarUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetStackedBarUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetStackedBarUnitsToTerraform(struct?: OneDashboardPageWidgetStackedBarUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetStackedBarUnitsToHclTerraform(struct?: OneDashboardPageWidgetStackedBarUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetStackedBarUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetStackedBarUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBarUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetStackedBarUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetStackedBarUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetStackedBarUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetStackedBarUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetStackedBarUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetStackedBarUnitsOutputReference;
}
export interface OneDashboardPageWidgetStackedBar {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetStackedBarChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetStackedBarColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetStackedBarDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetStackedBarInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetStackedBarNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetStackedBarNullValues[] | cdktn.IResolvable;
    /**
    * tooltip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#tooltip OneDashboard#tooltip}
    */
    readonly tooltip?: OneDashboardPageWidgetStackedBarTooltip;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetStackedBarUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetStackedBarToTerraform(struct?: OneDashboardPageWidgetStackedBar | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetStackedBarToHclTerraform(struct?: OneDashboardPageWidgetStackedBar | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetStackedBarOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetStackedBar | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetStackedBar | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetStackedBarChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetStackedBarChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetStackedBarChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetStackedBarColorsList;
    putColors(value: OneDashboardPageWidgetStackedBarColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetStackedBarColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetStackedBarDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetStackedBarDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetStackedBarDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetStackedBarInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetStackedBarInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetStackedBarInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetStackedBarNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetStackedBarNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetStackedBarNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetStackedBarNullValuesList;
    putNullValues(value: OneDashboardPageWidgetStackedBarNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetStackedBarNullValues[] | undefined;
    private _tooltip;
    get tooltip(): OneDashboardPageWidgetStackedBarTooltipOutputReference;
    putTooltip(value: OneDashboardPageWidgetStackedBarTooltip): void;
    resetTooltip(): void;
    get tooltipInput(): OneDashboardPageWidgetStackedBarTooltip | undefined;
    private _units;
    get units(): OneDashboardPageWidgetStackedBarUnitsList;
    putUnits(value: OneDashboardPageWidgetStackedBarUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetStackedBarUnits[] | undefined;
}
export declare class OneDashboardPageWidgetStackedBarList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetStackedBar[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetStackedBarOutputReference;
}
export interface OneDashboardPageWidgetTableChartStylesGradient {
    /**
    * Enable or disable gradient effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#enabled OneDashboard#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetTableChartStylesGradientToTerraform(struct?: OneDashboardPageWidgetTableChartStylesGradientOutputReference | OneDashboardPageWidgetTableChartStylesGradient): any;
export declare function oneDashboardPageWidgetTableChartStylesGradientToHclTerraform(struct?: OneDashboardPageWidgetTableChartStylesGradientOutputReference | OneDashboardPageWidgetTableChartStylesGradient): any;
export declare class OneDashboardPageWidgetTableChartStylesGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetTableChartStylesGradient | undefined;
    set internalValue(value: OneDashboardPageWidgetTableChartStylesGradient | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OneDashboardPageWidgetTableChartStyles {
    /**
    * Line interpolation style. Valid values: 'linear', 'smooth', 'stepBefore', 'stepAfter'. Applicable to line widgets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#line_interpolation OneDashboard#line_interpolation}
    */
    readonly lineInterpolation?: string;
    /**
    * gradient block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#gradient OneDashboard#gradient}
    */
    readonly gradient?: OneDashboardPageWidgetTableChartStylesGradient;
}
export declare function oneDashboardPageWidgetTableChartStylesToTerraform(struct?: OneDashboardPageWidgetTableChartStylesOutputReference | OneDashboardPageWidgetTableChartStyles): any;
export declare function oneDashboardPageWidgetTableChartStylesToHclTerraform(struct?: OneDashboardPageWidgetTableChartStylesOutputReference | OneDashboardPageWidgetTableChartStyles): any;
export declare class OneDashboardPageWidgetTableChartStylesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetTableChartStyles | undefined;
    set internalValue(value: OneDashboardPageWidgetTableChartStyles | undefined);
    private _lineInterpolation?;
    get lineInterpolation(): string;
    set lineInterpolation(value: string);
    resetLineInterpolation(): void;
    get lineInterpolationInput(): string | undefined;
    private _gradient;
    get gradient(): OneDashboardPageWidgetTableChartStylesGradientOutputReference;
    putGradient(value: OneDashboardPageWidgetTableChartStylesGradient): void;
    resetGradient(): void;
    get gradientInput(): OneDashboardPageWidgetTableChartStylesGradient | undefined;
}
export interface OneDashboardPageWidgetTableColorsSeriesOverrides {
    /**
    * Color code
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetTableColorsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetTableColorsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableColorsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetTableColorsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableColorsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTableColorsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTableColorsSeriesOverrides | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetTableColorsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTableColorsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableColorsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetTableColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#color OneDashboard#color}
    */
    readonly color?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetTableColorsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetTableColorsToTerraform(struct?: OneDashboardPageWidgetTableColors | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableColorsToHclTerraform(struct?: OneDashboardPageWidgetTableColors | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTableColors | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTableColors | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetTableColorsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetTableColorsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetTableColorsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetTableColorsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTableColors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableColorsOutputReference;
}
export interface OneDashboardPageWidgetTableDataFormat {
    /**
    * Defines the format of the mentioned type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#format OneDashboard#format}
    */
    readonly format?: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * The precision of the type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#precision OneDashboard#precision}
    */
    readonly precision?: number;
    /**
    * Defines the type of the mentioned column
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
}
export declare function oneDashboardPageWidgetTableDataFormatToTerraform(struct?: OneDashboardPageWidgetTableDataFormat | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableDataFormatToHclTerraform(struct?: OneDashboardPageWidgetTableDataFormat | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableDataFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTableDataFormat | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTableDataFormat | cdktn.IResolvable | undefined);
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class OneDashboardPageWidgetTableDataFormatList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTableDataFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableDataFormatOutputReference;
}
export interface OneDashboardPageWidgetTableInitialSorting {
    /**
    * Defines the sort order. Either ascending or descending.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#direction OneDashboard#direction}
    */
    readonly direction: string;
    /**
    * The column name to be sorted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
}
export declare function oneDashboardPageWidgetTableInitialSortingToTerraform(struct?: OneDashboardPageWidgetTableInitialSortingOutputReference | OneDashboardPageWidgetTableInitialSorting): any;
export declare function oneDashboardPageWidgetTableInitialSortingToHclTerraform(struct?: OneDashboardPageWidgetTableInitialSortingOutputReference | OneDashboardPageWidgetTableInitialSorting): any;
export declare class OneDashboardPageWidgetTableInitialSortingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardPageWidgetTableInitialSorting | undefined;
    set internalValue(value: OneDashboardPageWidgetTableInitialSorting | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface OneDashboardPageWidgetTableNrqlQuery {
    /**
    * The account ID(s) used for the NRQL query. Can be a single account ID or multiple account IDs in a JSON-encoded array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#account_id OneDashboard#account_id}
    */
    readonly accountId?: string;
    /**
    * The NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardPageWidgetTableNrqlQueryToTerraform(struct?: OneDashboardPageWidgetTableNrqlQuery | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableNrqlQueryToHclTerraform(struct?: OneDashboardPageWidgetTableNrqlQuery | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTableNrqlQuery | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTableNrqlQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class OneDashboardPageWidgetTableNrqlQueryList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTableNrqlQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableNrqlQueryOutputReference;
}
export interface OneDashboardPageWidgetTableNullValuesSeriesOverrides {
    /**
    * Null value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
}
export declare function oneDashboardPageWidgetTableNullValuesSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetTableNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableNullValuesSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetTableNullValuesSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableNullValuesSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTableNullValuesSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTableNullValuesSeriesOverrides | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
}
export declare class OneDashboardPageWidgetTableNullValuesSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTableNullValuesSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableNullValuesSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetTableNullValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_value OneDashboard#null_value}
    */
    readonly nullValue?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetTableNullValuesSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetTableNullValuesToTerraform(struct?: OneDashboardPageWidgetTableNullValues | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableNullValuesToHclTerraform(struct?: OneDashboardPageWidgetTableNullValues | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableNullValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTableNullValues | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTableNullValues | cdktn.IResolvable | undefined);
    private _nullValue?;
    get nullValue(): string;
    set nullValue(value: string);
    resetNullValue(): void;
    get nullValueInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetTableNullValuesSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetTableNullValuesSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetTableNullValuesSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetTableNullValuesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTableNullValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableNullValuesOutputReference;
}
export interface OneDashboardPageWidgetTableThreshold {
    /**
    * Name of the column in the table, to which the threshold would be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#column_name OneDashboard#column_name}
    */
    readonly columnName?: string;
    /**
    * The number from which the range starts in thresholds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#from OneDashboard#from}
    */
    readonly from?: string;
    /**
    * Severity of the threshold, which would reflect in the widget, in the range of the threshold specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#severity OneDashboard#severity}
    */
    readonly severity?: string;
    /**
    * The number at which the range ends in thresholds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#to OneDashboard#to}
    */
    readonly to?: string;
}
export declare function oneDashboardPageWidgetTableThresholdToTerraform(struct?: OneDashboardPageWidgetTableThreshold | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableThresholdToHclTerraform(struct?: OneDashboardPageWidgetTableThreshold | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTableThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTableThreshold | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    resetColumnName(): void;
    get columnNameInput(): string | undefined;
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    private _to?;
    get to(): string;
    set to(value: string);
    resetTo(): void;
    get toInput(): string | undefined;
}
export declare class OneDashboardPageWidgetTableThresholdList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTableThreshold[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableThresholdOutputReference;
}
export interface OneDashboardPageWidgetTableUnitsSeriesOverrides {
    /**
    * Series name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_name OneDashboard#series_name}
    */
    readonly seriesName?: string;
    /**
    * Unit name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
}
export declare function oneDashboardPageWidgetTableUnitsSeriesOverridesToTerraform(struct?: OneDashboardPageWidgetTableUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableUnitsSeriesOverridesToHclTerraform(struct?: OneDashboardPageWidgetTableUnitsSeriesOverrides | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableUnitsSeriesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTableUnitsSeriesOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTableUnitsSeriesOverrides | cdktn.IResolvable | undefined);
    private _seriesName?;
    get seriesName(): string;
    set seriesName(value: string);
    resetSeriesName(): void;
    get seriesNameInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export declare class OneDashboardPageWidgetTableUnitsSeriesOverridesList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTableUnitsSeriesOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableUnitsSeriesOverridesOutputReference;
}
export interface OneDashboardPageWidgetTableUnits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#unit OneDashboard#unit}
    */
    readonly unit?: string;
    /**
    * series_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#series_overrides OneDashboard#series_overrides}
    */
    readonly seriesOverrides?: OneDashboardPageWidgetTableUnitsSeriesOverrides[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetTableUnitsToTerraform(struct?: OneDashboardPageWidgetTableUnits | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableUnitsToHclTerraform(struct?: OneDashboardPageWidgetTableUnits | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableUnitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTableUnits | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTableUnits | cdktn.IResolvable | undefined);
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _seriesOverrides;
    get seriesOverrides(): OneDashboardPageWidgetTableUnitsSeriesOverridesList;
    putSeriesOverrides(value: OneDashboardPageWidgetTableUnitsSeriesOverrides[] | cdktn.IResolvable): void;
    resetSeriesOverrides(): void;
    get seriesOverridesInput(): cdktn.IResolvable | OneDashboardPageWidgetTableUnitsSeriesOverrides[] | undefined;
}
export declare class OneDashboardPageWidgetTableUnitsList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTableUnits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableUnitsOutputReference;
}
export interface OneDashboardPageWidgetTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#column OneDashboard#column}
    */
    readonly column: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#facet_show_other_series OneDashboard#facet_show_other_series}
    */
    readonly facetShowOtherSeries?: boolean | cdktn.IResolvable;
    /**
    * Use this item to filter the current dashboard
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#filter_current_dashboard OneDashboard#filter_current_dashboard}
    */
    readonly filterCurrentDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#height OneDashboard#height}
    */
    readonly height?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#legend_enabled OneDashboard#legend_enabled}
    */
    readonly legendEnabled?: boolean | cdktn.IResolvable;
    /**
    * Related entities. Currently only supports Dashboard entities, but may allow other cases in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#linked_entity_guids OneDashboard#linked_entity_guids}
    */
    readonly linkedEntityGuids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#refresh_rate OneDashboard#refresh_rate}
    */
    readonly refreshRate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#row OneDashboard#row}
    */
    readonly row: number;
    /**
    * A title for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#width OneDashboard#width}
    */
    readonly width?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_max OneDashboard#y_axis_left_max}
    */
    readonly yAxisLeftMax?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#y_axis_left_min OneDashboard#y_axis_left_min}
    */
    readonly yAxisLeftMin?: number;
    /**
    * chart_styles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#chart_styles OneDashboard#chart_styles}
    */
    readonly chartStyles?: OneDashboardPageWidgetTableChartStyles;
    /**
    * colors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#colors OneDashboard#colors}
    */
    readonly colors?: OneDashboardPageWidgetTableColors[] | cdktn.IResolvable;
    /**
    * data_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#data_format OneDashboard#data_format}
    */
    readonly dataFormat?: OneDashboardPageWidgetTableDataFormat[] | cdktn.IResolvable;
    /**
    * initial_sorting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#initial_sorting OneDashboard#initial_sorting}
    */
    readonly initialSorting?: OneDashboardPageWidgetTableInitialSorting;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery: OneDashboardPageWidgetTableNrqlQuery[] | cdktn.IResolvable;
    /**
    * null_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#null_values OneDashboard#null_values}
    */
    readonly nullValues?: OneDashboardPageWidgetTableNullValues[] | cdktn.IResolvable;
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#threshold OneDashboard#threshold}
    */
    readonly threshold?: OneDashboardPageWidgetTableThreshold[] | cdktn.IResolvable;
    /**
    * units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#units OneDashboard#units}
    */
    readonly units?: OneDashboardPageWidgetTableUnits[] | cdktn.IResolvable;
}
export declare function oneDashboardPageWidgetTableToTerraform(struct?: OneDashboardPageWidgetTable | cdktn.IResolvable): any;
export declare function oneDashboardPageWidgetTableToHclTerraform(struct?: OneDashboardPageWidgetTable | cdktn.IResolvable): any;
export declare class OneDashboardPageWidgetTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPageWidgetTable | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPageWidgetTable | cdktn.IResolvable | undefined);
    private _column?;
    get column(): number;
    set column(value: number);
    get columnInput(): number | undefined;
    private _facetShowOtherSeries?;
    get facetShowOtherSeries(): boolean | cdktn.IResolvable;
    set facetShowOtherSeries(value: boolean | cdktn.IResolvable);
    resetFacetShowOtherSeries(): void;
    get facetShowOtherSeriesInput(): boolean | cdktn.IResolvable | undefined;
    private _filterCurrentDashboard?;
    get filterCurrentDashboard(): boolean | cdktn.IResolvable;
    set filterCurrentDashboard(value: boolean | cdktn.IResolvable);
    resetFilterCurrentDashboard(): void;
    get filterCurrentDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    get id(): string;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _legendEnabled?;
    get legendEnabled(): boolean | cdktn.IResolvable;
    set legendEnabled(value: boolean | cdktn.IResolvable);
    resetLegendEnabled(): void;
    get legendEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _linkedEntityGuids?;
    get linkedEntityGuids(): string[];
    set linkedEntityGuids(value: string[]);
    resetLinkedEntityGuids(): void;
    get linkedEntityGuidsInput(): string[] | undefined;
    private _refreshRate?;
    get refreshRate(): string;
    set refreshRate(value: string);
    resetRefreshRate(): void;
    get refreshRateInput(): string | undefined;
    private _row?;
    get row(): number;
    set row(value: number);
    get rowInput(): number | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _yAxisLeftMax?;
    get yAxisLeftMax(): number;
    set yAxisLeftMax(value: number);
    resetYAxisLeftMax(): void;
    get yAxisLeftMaxInput(): number | undefined;
    private _yAxisLeftMin?;
    get yAxisLeftMin(): number;
    set yAxisLeftMin(value: number);
    resetYAxisLeftMin(): void;
    get yAxisLeftMinInput(): number | undefined;
    private _chartStyles;
    get chartStyles(): OneDashboardPageWidgetTableChartStylesOutputReference;
    putChartStyles(value: OneDashboardPageWidgetTableChartStyles): void;
    resetChartStyles(): void;
    get chartStylesInput(): OneDashboardPageWidgetTableChartStyles | undefined;
    private _colors;
    get colors(): OneDashboardPageWidgetTableColorsList;
    putColors(value: OneDashboardPageWidgetTableColors[] | cdktn.IResolvable): void;
    resetColors(): void;
    get colorsInput(): cdktn.IResolvable | OneDashboardPageWidgetTableColors[] | undefined;
    private _dataFormat;
    get dataFormat(): OneDashboardPageWidgetTableDataFormatList;
    putDataFormat(value: OneDashboardPageWidgetTableDataFormat[] | cdktn.IResolvable): void;
    resetDataFormat(): void;
    get dataFormatInput(): cdktn.IResolvable | OneDashboardPageWidgetTableDataFormat[] | undefined;
    private _initialSorting;
    get initialSorting(): OneDashboardPageWidgetTableInitialSortingOutputReference;
    putInitialSorting(value: OneDashboardPageWidgetTableInitialSorting): void;
    resetInitialSorting(): void;
    get initialSortingInput(): OneDashboardPageWidgetTableInitialSorting | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardPageWidgetTableNrqlQueryList;
    putNrqlQuery(value: OneDashboardPageWidgetTableNrqlQuery[] | cdktn.IResolvable): void;
    get nrqlQueryInput(): cdktn.IResolvable | OneDashboardPageWidgetTableNrqlQuery[] | undefined;
    private _nullValues;
    get nullValues(): OneDashboardPageWidgetTableNullValuesList;
    putNullValues(value: OneDashboardPageWidgetTableNullValues[] | cdktn.IResolvable): void;
    resetNullValues(): void;
    get nullValuesInput(): cdktn.IResolvable | OneDashboardPageWidgetTableNullValues[] | undefined;
    private _threshold;
    get threshold(): OneDashboardPageWidgetTableThresholdList;
    putThreshold(value: OneDashboardPageWidgetTableThreshold[] | cdktn.IResolvable): void;
    resetThreshold(): void;
    get thresholdInput(): cdktn.IResolvable | OneDashboardPageWidgetTableThreshold[] | undefined;
    private _units;
    get units(): OneDashboardPageWidgetTableUnitsList;
    putUnits(value: OneDashboardPageWidgetTableUnits[] | cdktn.IResolvable): void;
    resetUnits(): void;
    get unitsInput(): cdktn.IResolvable | OneDashboardPageWidgetTableUnits[] | undefined;
}
export declare class OneDashboardPageWidgetTableList extends cdktn.ComplexList {
    internalValue?: OneDashboardPageWidgetTable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageWidgetTableOutputReference;
}
export interface OneDashboardPage {
    /**
    * The dashboard page's description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#description OneDashboard#description}
    */
    readonly description?: string;
    /**
    * The dashboard page's name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * widget_area block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_area OneDashboard#widget_area}
    */
    readonly widgetArea?: OneDashboardPageWidgetArea[] | cdktn.IResolvable;
    /**
    * widget_bar block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_bar OneDashboard#widget_bar}
    */
    readonly widgetBar?: OneDashboardPageWidgetBar[] | cdktn.IResolvable;
    /**
    * widget_billboard block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_billboard OneDashboard#widget_billboard}
    */
    readonly widgetBillboard?: OneDashboardPageWidgetBillboard[] | cdktn.IResolvable;
    /**
    * widget_bullet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_bullet OneDashboard#widget_bullet}
    */
    readonly widgetBullet?: OneDashboardPageWidgetBullet[] | cdktn.IResolvable;
    /**
    * widget_funnel block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_funnel OneDashboard#widget_funnel}
    */
    readonly widgetFunnel?: OneDashboardPageWidgetFunnel[] | cdktn.IResolvable;
    /**
    * widget_heatmap block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_heatmap OneDashboard#widget_heatmap}
    */
    readonly widgetHeatmap?: OneDashboardPageWidgetHeatmap[] | cdktn.IResolvable;
    /**
    * widget_histogram block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_histogram OneDashboard#widget_histogram}
    */
    readonly widgetHistogram?: OneDashboardPageWidgetHistogram[] | cdktn.IResolvable;
    /**
    * widget_json block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_json OneDashboard#widget_json}
    */
    readonly widgetJson?: OneDashboardPageWidgetJson[] | cdktn.IResolvable;
    /**
    * widget_line block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_line OneDashboard#widget_line}
    */
    readonly widgetLine?: OneDashboardPageWidgetLine[] | cdktn.IResolvable;
    /**
    * widget_log_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_log_table OneDashboard#widget_log_table}
    */
    readonly widgetLogTable?: OneDashboardPageWidgetLogTable[] | cdktn.IResolvable;
    /**
    * widget_markdown block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_markdown OneDashboard#widget_markdown}
    */
    readonly widgetMarkdown?: OneDashboardPageWidgetMarkdown[] | cdktn.IResolvable;
    /**
    * widget_pie block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_pie OneDashboard#widget_pie}
    */
    readonly widgetPie?: OneDashboardPageWidgetPie[] | cdktn.IResolvable;
    /**
    * widget_stacked_bar block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_stacked_bar OneDashboard#widget_stacked_bar}
    */
    readonly widgetStackedBar?: OneDashboardPageWidgetStackedBar[] | cdktn.IResolvable;
    /**
    * widget_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#widget_table OneDashboard#widget_table}
    */
    readonly widgetTable?: OneDashboardPageWidgetTable[] | cdktn.IResolvable;
}
export declare function oneDashboardPageToTerraform(struct?: OneDashboardPage | cdktn.IResolvable): any;
export declare function oneDashboardPageToHclTerraform(struct?: OneDashboardPage | cdktn.IResolvable): any;
export declare class OneDashboardPageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardPage | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardPage | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get guid(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _widgetArea;
    get widgetArea(): OneDashboardPageWidgetAreaList;
    putWidgetArea(value: OneDashboardPageWidgetArea[] | cdktn.IResolvable): void;
    resetWidgetArea(): void;
    get widgetAreaInput(): cdktn.IResolvable | OneDashboardPageWidgetArea[] | undefined;
    private _widgetBar;
    get widgetBar(): OneDashboardPageWidgetBarList;
    putWidgetBar(value: OneDashboardPageWidgetBar[] | cdktn.IResolvable): void;
    resetWidgetBar(): void;
    get widgetBarInput(): cdktn.IResolvable | OneDashboardPageWidgetBar[] | undefined;
    private _widgetBillboard;
    get widgetBillboard(): OneDashboardPageWidgetBillboardList;
    putWidgetBillboard(value: OneDashboardPageWidgetBillboard[] | cdktn.IResolvable): void;
    resetWidgetBillboard(): void;
    get widgetBillboardInput(): cdktn.IResolvable | OneDashboardPageWidgetBillboard[] | undefined;
    private _widgetBullet;
    get widgetBullet(): OneDashboardPageWidgetBulletList;
    putWidgetBullet(value: OneDashboardPageWidgetBullet[] | cdktn.IResolvable): void;
    resetWidgetBullet(): void;
    get widgetBulletInput(): cdktn.IResolvable | OneDashboardPageWidgetBullet[] | undefined;
    private _widgetFunnel;
    get widgetFunnel(): OneDashboardPageWidgetFunnelList;
    putWidgetFunnel(value: OneDashboardPageWidgetFunnel[] | cdktn.IResolvable): void;
    resetWidgetFunnel(): void;
    get widgetFunnelInput(): cdktn.IResolvable | OneDashboardPageWidgetFunnel[] | undefined;
    private _widgetHeatmap;
    get widgetHeatmap(): OneDashboardPageWidgetHeatmapList;
    putWidgetHeatmap(value: OneDashboardPageWidgetHeatmap[] | cdktn.IResolvable): void;
    resetWidgetHeatmap(): void;
    get widgetHeatmapInput(): cdktn.IResolvable | OneDashboardPageWidgetHeatmap[] | undefined;
    private _widgetHistogram;
    get widgetHistogram(): OneDashboardPageWidgetHistogramList;
    putWidgetHistogram(value: OneDashboardPageWidgetHistogram[] | cdktn.IResolvable): void;
    resetWidgetHistogram(): void;
    get widgetHistogramInput(): cdktn.IResolvable | OneDashboardPageWidgetHistogram[] | undefined;
    private _widgetJson;
    get widgetJson(): OneDashboardPageWidgetJsonList;
    putWidgetJson(value: OneDashboardPageWidgetJson[] | cdktn.IResolvable): void;
    resetWidgetJson(): void;
    get widgetJsonInput(): cdktn.IResolvable | OneDashboardPageWidgetJson[] | undefined;
    private _widgetLine;
    get widgetLine(): OneDashboardPageWidgetLineList;
    putWidgetLine(value: OneDashboardPageWidgetLine[] | cdktn.IResolvable): void;
    resetWidgetLine(): void;
    get widgetLineInput(): cdktn.IResolvable | OneDashboardPageWidgetLine[] | undefined;
    private _widgetLogTable;
    get widgetLogTable(): OneDashboardPageWidgetLogTableList;
    putWidgetLogTable(value: OneDashboardPageWidgetLogTable[] | cdktn.IResolvable): void;
    resetWidgetLogTable(): void;
    get widgetLogTableInput(): cdktn.IResolvable | OneDashboardPageWidgetLogTable[] | undefined;
    private _widgetMarkdown;
    get widgetMarkdown(): OneDashboardPageWidgetMarkdownList;
    putWidgetMarkdown(value: OneDashboardPageWidgetMarkdown[] | cdktn.IResolvable): void;
    resetWidgetMarkdown(): void;
    get widgetMarkdownInput(): cdktn.IResolvable | OneDashboardPageWidgetMarkdown[] | undefined;
    private _widgetPie;
    get widgetPie(): OneDashboardPageWidgetPieList;
    putWidgetPie(value: OneDashboardPageWidgetPie[] | cdktn.IResolvable): void;
    resetWidgetPie(): void;
    get widgetPieInput(): cdktn.IResolvable | OneDashboardPageWidgetPie[] | undefined;
    private _widgetStackedBar;
    get widgetStackedBar(): OneDashboardPageWidgetStackedBarList;
    putWidgetStackedBar(value: OneDashboardPageWidgetStackedBar[] | cdktn.IResolvable): void;
    resetWidgetStackedBar(): void;
    get widgetStackedBarInput(): cdktn.IResolvable | OneDashboardPageWidgetStackedBar[] | undefined;
    private _widgetTable;
    get widgetTable(): OneDashboardPageWidgetTableList;
    putWidgetTable(value: OneDashboardPageWidgetTable[] | cdktn.IResolvable): void;
    resetWidgetTable(): void;
    get widgetTableInput(): cdktn.IResolvable | OneDashboardPageWidgetTable[] | undefined;
}
export declare class OneDashboardPageList extends cdktn.ComplexList {
    internalValue?: OneDashboardPage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardPageOutputReference;
}
export interface OneDashboardVariableItem {
    /**
    * A human-friendly display string for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title?: string;
    /**
    * A possible variable value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#value OneDashboard#value}
    */
    readonly value: string;
}
export declare function oneDashboardVariableItemToTerraform(struct?: OneDashboardVariableItem | cdktn.IResolvable): any;
export declare function oneDashboardVariableItemToHclTerraform(struct?: OneDashboardVariableItem | cdktn.IResolvable): any;
export declare class OneDashboardVariableItemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardVariableItem | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardVariableItem | cdktn.IResolvable | undefined);
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class OneDashboardVariableItemList extends cdktn.ComplexList {
    internalValue?: OneDashboardVariableItem[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardVariableItemOutputReference;
}
export interface OneDashboardVariableNrqlQuery {
    /**
    * New Relic account ID(s) to issue the query against. Defaults to the account ID specified in the provider configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#account_ids OneDashboard#account_ids}
    */
    readonly accountIds?: number[];
    /**
    * NRQL formatted query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#query OneDashboard#query}
    */
    readonly query: string;
}
export declare function oneDashboardVariableNrqlQueryToTerraform(struct?: OneDashboardVariableNrqlQueryOutputReference | OneDashboardVariableNrqlQuery): any;
export declare function oneDashboardVariableNrqlQueryToHclTerraform(struct?: OneDashboardVariableNrqlQueryOutputReference | OneDashboardVariableNrqlQuery): any;
export declare class OneDashboardVariableNrqlQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OneDashboardVariableNrqlQuery | undefined;
    set internalValue(value: OneDashboardVariableNrqlQuery | undefined);
    private _accountIds?;
    get accountIds(): number[];
    set accountIds(value: number[]);
    resetAccountIds(): void;
    get accountIdsInput(): number[] | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface OneDashboardVariableOptions {
    /**
    * Only applies to variables of type NRQL. With this turned on, query condition defined with the variable will not be included in the query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#excluded OneDashboard#excluded}
    */
    readonly excluded?: boolean | cdktn.IResolvable;
    /**
    * Only applies to variables of type NRQL. With this turned on, the time range for the NRQL query will override the time picker on dashboards and other pages. Turn this off to use the time picker as normal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#ignore_time_range OneDashboard#ignore_time_range}
    */
    readonly ignoreTimeRange?: boolean | cdktn.IResolvable;
    /**
    * Show apply button when multi-selecting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#show_apply_action OneDashboard#show_apply_action}
    */
    readonly showApplyAction?: boolean | cdktn.IResolvable;
}
export declare function oneDashboardVariableOptionsToTerraform(struct?: OneDashboardVariableOptions | cdktn.IResolvable): any;
export declare function oneDashboardVariableOptionsToHclTerraform(struct?: OneDashboardVariableOptions | cdktn.IResolvable): any;
export declare class OneDashboardVariableOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardVariableOptions | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardVariableOptions | cdktn.IResolvable | undefined);
    private _excluded?;
    get excluded(): boolean | cdktn.IResolvable;
    set excluded(value: boolean | cdktn.IResolvable);
    resetExcluded(): void;
    get excludedInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreTimeRange?;
    get ignoreTimeRange(): boolean | cdktn.IResolvable;
    set ignoreTimeRange(value: boolean | cdktn.IResolvable);
    resetIgnoreTimeRange(): void;
    get ignoreTimeRangeInput(): boolean | cdktn.IResolvable | undefined;
    private _showApplyAction?;
    get showApplyAction(): boolean | cdktn.IResolvable;
    set showApplyAction(value: boolean | cdktn.IResolvable);
    resetShowApplyAction(): void;
    get showApplyActionInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class OneDashboardVariableOptionsList extends cdktn.ComplexList {
    internalValue?: OneDashboardVariableOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardVariableOptionsOutputReference;
}
export interface OneDashboardVariable {
    /**
    * Default values for this variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#default_values OneDashboard#default_values}
    */
    readonly defaultValues?: string[];
    /**
    * Indicates whether this variable supports multiple selection or not. Only applies to variables of type NRQL or ENUM.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#is_multi_selection OneDashboard#is_multi_selection}
    */
    readonly isMultiSelection?: boolean | cdktn.IResolvable;
    /**
    * The variable identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#name OneDashboard#name}
    */
    readonly name: string;
    /**
    * Indicates the strategy to apply when replacing a variable in a NRQL query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#replacement_strategy OneDashboard#replacement_strategy}
    */
    readonly replacementStrategy: string;
    /**
    * Human-friendly display string for this variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#title OneDashboard#title}
    */
    readonly title: string;
    /**
    * Specifies the data type of the variable and where its possible values may come from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#type OneDashboard#type}
    */
    readonly type: string;
    /**
    * item block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#item OneDashboard#item}
    */
    readonly item?: OneDashboardVariableItem[] | cdktn.IResolvable;
    /**
    * nrql_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#nrql_query OneDashboard#nrql_query}
    */
    readonly nrqlQuery?: OneDashboardVariableNrqlQuery;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/one_dashboard#options OneDashboard#options}
    */
    readonly options?: OneDashboardVariableOptions[] | cdktn.IResolvable;
}
export declare function oneDashboardVariableToTerraform(struct?: OneDashboardVariable | cdktn.IResolvable): any;
export declare function oneDashboardVariableToHclTerraform(struct?: OneDashboardVariable | cdktn.IResolvable): any;
export declare class OneDashboardVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OneDashboardVariable | cdktn.IResolvable | undefined;
    set internalValue(value: OneDashboardVariable | cdktn.IResolvable | undefined);
    private _defaultValues?;
    get defaultValues(): string[];
    set defaultValues(value: string[]);
    resetDefaultValues(): void;
    get defaultValuesInput(): string[] | undefined;
    private _isMultiSelection?;
    get isMultiSelection(): boolean | cdktn.IResolvable;
    set isMultiSelection(value: boolean | cdktn.IResolvable);
    resetIsMultiSelection(): void;
    get isMultiSelectionInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _replacementStrategy?;
    get replacementStrategy(): string;
    set replacementStrategy(value: string);
    get replacementStrategyInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _item;
    get item(): OneDashboardVariableItemList;
    putItem(value: OneDashboardVariableItem[] | cdktn.IResolvable): void;
    resetItem(): void;
    get itemInput(): cdktn.IResolvable | OneDashboardVariableItem[] | undefined;
    private _nrqlQuery;
    get nrqlQuery(): OneDashboardVariableNrqlQueryOutputReference;
    putNrqlQuery(value: OneDashboardVariableNrqlQuery): void;
    resetNrqlQuery(): void;
    get nrqlQueryInput(): OneDashboardVariableNrqlQuery | undefined;
    private _options;
    get options(): OneDashboardVariableOptionsList;
    putOptions(value: OneDashboardVariableOptions[] | cdktn.IResolvable): void;
    resetOptions(): void;
    get optionsInput(): cdktn.IResolvable | OneDashboardVariableOptions[] | undefined;
}
export declare class OneDashboardVariableList extends cdktn.ComplexList {
    internalValue?: OneDashboardVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OneDashboardVariableOutputReference;
}
