/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BrowserApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#account_id BrowserApplication#account_id}
    */
    readonly accountId?: number;
    /**
    * Configure cookies. The default is enabled: true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#cookies_enabled BrowserApplication#cookies_enabled}
    */
    readonly cookiesEnabled?: boolean | cdktn.IResolvable;
    /**
    * Configure distributed tracing in browser apps. The default is enabled: true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#distributed_tracing_enabled BrowserApplication#distributed_tracing_enabled}
    */
    readonly distributedTracingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#id BrowserApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Determines which browser loader is configured. The default is "SPA".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#loader_type BrowserApplication#loader_type}
    */
    readonly loaderType?: string;
    /**
    * The name of the application to monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#name BrowserApplication#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#timeouts BrowserApplication#timeouts}
    */
    readonly timeouts?: BrowserApplicationTimeouts;
}
export interface BrowserApplicationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#create BrowserApplication#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#read BrowserApplication#read}
    */
    readonly read?: string;
}
export declare function browserApplicationTimeoutsToTerraform(struct?: BrowserApplicationTimeouts | cdktn.IResolvable): any;
export declare function browserApplicationTimeoutsToHclTerraform(struct?: BrowserApplicationTimeouts | cdktn.IResolvable): any;
export declare class BrowserApplicationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BrowserApplicationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BrowserApplicationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application newrelic_browser_application}
*/
export declare class BrowserApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "newrelic_browser_application";
    /**
    * Generates CDKTN code for importing a BrowserApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BrowserApplication to import
    * @param importFromId The id of the existing BrowserApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BrowserApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/newrelic/newrelic/3.97.5/docs/resources/browser_application newrelic_browser_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BrowserApplicationConfig
    */
    constructor(scope: Construct, id: string, config: BrowserApplicationConfig);
    private _accountId?;
    get accountId(): number;
    set accountId(value: number);
    resetAccountId(): void;
    get accountIdInput(): number | undefined;
    get applicationId(): string;
    private _cookiesEnabled?;
    get cookiesEnabled(): boolean | cdktn.IResolvable;
    set cookiesEnabled(value: boolean | cdktn.IResolvable);
    resetCookiesEnabled(): void;
    get cookiesEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _distributedTracingEnabled?;
    get distributedTracingEnabled(): boolean | cdktn.IResolvable;
    set distributedTracingEnabled(value: boolean | cdktn.IResolvable);
    resetDistributedTracingEnabled(): void;
    get distributedTracingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get guid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get jsConfig(): string;
    private _loaderType?;
    get loaderType(): string;
    set loaderType(value: string);
    resetLoaderType(): void;
    get loaderTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _timeouts;
    get timeouts(): BrowserApplicationTimeoutsOutputReference;
    putTimeouts(value: BrowserApplicationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BrowserApplicationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
